var Io = Object.defineProperty;
var No = (s, e, t) => e in s ? Io(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : s[e] = t;
var N = (s, e, t) => No(s, typeof e != "symbol" ? e + "" : e, t);
import { collectFlowInteractionDoneIds as Oo, enumerateActivities as vo } from "@lxpack/validators";
/*! @license DOMPurify 3.4.5 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.5/LICENSE */
function mi(s, e) {
  (e == null || e > s.length) && (e = s.length);
  for (var t = 0, n = Array(e); t < e; t++) n[t] = s[t];
  return n;
}
function xo(s) {
  if (Array.isArray(s)) return s;
}
function Co(s, e) {
  var t = s == null ? null : typeof Symbol < "u" && s[Symbol.iterator] || s["@@iterator"];
  if (t != null) {
    var n, i, r, o, a = [], c = !0, l = !1;
    try {
      if (r = (t = t.call(s)).next, e !== 0) for (; !(c = (n = r.call(t)).done) && (a.push(n.value), a.length !== e); c = !0) ;
    } catch (u) {
      l = !0, i = u;
    } finally {
      try {
        if (!c && t.return != null && (o = t.return(), Object(o) !== o)) return;
      } finally {
        if (l) throw i;
      }
    }
    return a;
  }
}
function Ro() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function $o(s, e) {
  return xo(s) || Co(s, e) || Po(s, e) || Ro();
}
function Po(s, e) {
  if (s) {
    if (typeof s == "string") return mi(s, e);
    var t = {}.toString.call(s).slice(8, -1);
    return t === "Object" && s.constructor && (t = s.constructor.name), t === "Map" || t === "Set" ? Array.from(s) : t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? mi(s, e) : void 0;
  }
}
const or = Object.entries, gi = Object.setPrototypeOf, Do = Object.isFrozen, Mo = Object.getPrototypeOf, Bo = Object.getOwnPropertyDescriptor;
let re = Object.freeze, pe = Object.seal, rt = Object.create, ar = typeof Reflect < "u" && Reflect, rn = ar.apply, on = ar.construct;
re || (re = function(e) {
  return e;
});
pe || (pe = function(e) {
  return e;
});
rn || (rn = function(e, t) {
  for (var n = arguments.length, i = new Array(n > 2 ? n - 2 : 0), r = 2; r < n; r++)
    i[r - 2] = arguments[r];
  return e.apply(t, i);
});
on || (on = function(e) {
  for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    n[i - 1] = arguments[i];
  return new e(...n);
});
const Ze = W(Array.prototype.forEach), Fo = W(Array.prototype.lastIndexOf), yi = W(Array.prototype.pop), et = W(Array.prototype.push), jo = W(Array.prototype.splice), te = Array.isArray, It = W(String.prototype.toLowerCase), Ks = W(String.prototype.toString), bi = W(String.prototype.match), tt = W(String.prototype.replace), wi = W(String.prototype.indexOf), Uo = W(String.prototype.trim), zo = W(Number.prototype.toString), qo = W(Boolean.prototype.toString), ki = typeof BigInt > "u" ? null : W(BigInt.prototype.toString), Si = typeof Symbol > "u" ? null : W(Symbol.prototype.toString), j = W(Object.prototype.hasOwnProperty), Tt = W(Object.prototype.toString), ee = W(RegExp.prototype.test), Yt = Ko(TypeError);
function W(s) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
      n[i - 1] = arguments[i];
    return rn(s, e, n);
  };
}
function Ko(s) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return on(s, t);
  };
}
function x(s, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : It;
  if (gi && gi(s, null), !te(e))
    return s;
  let n = e.length;
  for (; n--; ) {
    let i = e[n];
    if (typeof i == "string") {
      const r = t(i);
      r !== i && (Do(e) || (e[n] = r), i = r);
    }
    s[i] = !0;
  }
  return s;
}
function Go(s) {
  for (let e = 0; e < s.length; e++)
    j(s, e) || (s[e] = null);
  return s;
}
function ae(s) {
  const e = rt(null);
  for (const n of or(s)) {
    var t = $o(n, 2);
    const i = t[0], r = t[1];
    j(s, i) && (te(r) ? e[i] = Go(r) : r && typeof r == "object" && r.constructor === Object ? e[i] = ae(r) : e[i] = r);
  }
  return e;
}
function Ho(s) {
  switch (typeof s) {
    case "string":
      return s;
    case "number":
      return zo(s);
    case "boolean":
      return qo(s);
    case "bigint":
      return ki ? ki(s) : "0";
    case "symbol":
      return Si ? Si(s) : "Symbol()";
    case "undefined":
      return Tt(s);
    case "function":
    case "object": {
      if (s === null)
        return Tt(s);
      const e = s, t = je(e, "toString");
      if (typeof t == "function") {
        const n = t(e);
        return typeof n == "string" ? n : Tt(n);
      }
      return Tt(s);
    }
    default:
      return Tt(s);
  }
}
function je(s, e) {
  for (; s !== null; ) {
    const n = Bo(s, e);
    if (n) {
      if (n.get)
        return W(n.get);
      if (typeof n.value == "function")
        return W(n.value);
    }
    s = Mo(s);
  }
  function t() {
    return null;
  }
  return t;
}
function Vo(s) {
  try {
    return ee(s, ""), !0;
  } catch {
    return !1;
  }
}
const Ai = re(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Gs = re(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Hs = re(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Wo = re(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Vs = re(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Yo = re(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Ti = re(["#text"]), Ei = re(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "command", "commandfor", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns"]), Ws = re(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), _i = re(["accent", "accentunder", "align", "bevelled", "close", "columnalign", "columnlines", "columnspacing", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lquote", "lspace", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Jt = re(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Jo = pe(/{{[\w\W]*|^[\w\W]*}}/g), Xo = pe(/<%[\w\W]*|^[\w\W]*%>/g), Qo = pe(/\${[\w\W]*/g), Zo = pe(/^data-[\-\w.\u00B7-\uFFFF]+$/), ea = pe(/^aria-[\-\w]+$/), Li = pe(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), ta = pe(/^(?:\w+script|data):/i), sa = pe(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), na = pe(/^html$/i), ia = pe(/^[a-z][.\w]*(-[.\w]+)+$/i), st = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, ra = function() {
  return typeof window > "u" ? null : window;
}, oa = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const i = "data-tt-policy-suffix";
  t && t.hasAttribute(i) && (n = t.getAttribute(i));
  const r = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(r, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + r + " could not be created."), null;
  }
}, Ii = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function lr() {
  let s = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ra();
  const e = (O) => lr(O);
  if (e.version = "3.4.5", e.removed = [], !s || !s.document || s.document.nodeType !== st.document || !s.Element)
    return e.isSupported = !1, e;
  let t = s.document;
  const n = t, i = n.currentScript, r = s.DocumentFragment, o = s.HTMLTemplateElement, a = s.Node, c = s.Element, l = s.NodeFilter, u = s.NamedNodeMap, p = u === void 0 ? s.NamedNodeMap || s.MozNamedAttrMap : u, h = s.HTMLFormElement, d = s.DOMParser, g = s.trustedTypes, m = c.prototype, y = je(m, "cloneNode"), A = je(m, "remove"), k = je(m, "nextSibling"), L = je(m, "childNodes"), I = je(m, "parentNode"), w = a && a.prototype ? je(a.prototype, "nodeType") : null;
  if (typeof o == "function") {
    const O = t.createElement("template");
    O.content && O.content.ownerDocument && (t = O.content.ownerDocument);
  }
  let S, E = "";
  const T = t, C = T.implementation, M = T.createNodeIterator, J = T.createDocumentFragment, B = T.getElementsByTagName, U = n.importNode;
  let F = Ii();
  e.isSupported = typeof or == "function" && typeof I == "function" && C && C.createHTMLDocument !== void 0;
  const le = Jo, Te = Xo, We = Qo, go = Zo, yo = ea, bo = ta, Kn = sa, wo = ia;
  let Gn = Li, X = null;
  const Hn = x({}, [...Ai, ...Gs, ...Hs, ...Vs, ...Ti]);
  let Z = null;
  const Vn = x({}, [...Ei, ...Ws, ..._i, ...Jt]);
  let z = Object.seal(rt(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), wt = null, zt = null;
  const xe = Object.seal(rt(null, {
    tagCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    }
  }));
  let Wn = !0, vs = !0, Yn = !1, Jn = !0, Ce = !1, kt = !0, Be = !1, xs = !1, Cs = !1, Ye = !1, qt = !1, Kt = !1, Xn = !0, Qn = !1;
  const Zn = "user-content-";
  let Rs = !0, St = !1, Je = {}, be = null;
  const $s = x({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let ei = null;
  const ti = x({}, ["audio", "video", "img", "source", "image", "track"]);
  let Ps = null;
  const si = x({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), Gt = "http://www.w3.org/1998/Math/MathML", Ht = "http://www.w3.org/2000/svg", we = "http://www.w3.org/1999/xhtml";
  let Xe = we, Ds = !1, Ms = null;
  const ko = x({}, [Gt, Ht, we], Ks);
  let Bs = x({}, ["mi", "mo", "mn", "ms", "mtext"]), Fs = x({}, ["annotation-xml"]);
  const So = x({}, ["title", "style", "font", "a", "script"]);
  let At = null;
  const Ao = ["application/xhtml+xml", "text/html"], To = "text/html";
  let Y = null, Qe = null;
  const Eo = t.createElement("form"), ni = function(f) {
    return f instanceof RegExp || f instanceof Function;
  }, js = function() {
    let f = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (Qe && Qe === f)
      return;
    (!f || typeof f != "object") && (f = {}), f = ae(f), At = // eslint-disable-next-line unicorn/prefer-includes
    Ao.indexOf(f.PARSER_MEDIA_TYPE) === -1 ? To : f.PARSER_MEDIA_TYPE, Y = At === "application/xhtml+xml" ? Ks : It, X = j(f, "ALLOWED_TAGS") && te(f.ALLOWED_TAGS) ? x({}, f.ALLOWED_TAGS, Y) : Hn, Z = j(f, "ALLOWED_ATTR") && te(f.ALLOWED_ATTR) ? x({}, f.ALLOWED_ATTR, Y) : Vn, Ms = j(f, "ALLOWED_NAMESPACES") && te(f.ALLOWED_NAMESPACES) ? x({}, f.ALLOWED_NAMESPACES, Ks) : ko, Ps = j(f, "ADD_URI_SAFE_ATTR") && te(f.ADD_URI_SAFE_ATTR) ? x(ae(si), f.ADD_URI_SAFE_ATTR, Y) : si, ei = j(f, "ADD_DATA_URI_TAGS") && te(f.ADD_DATA_URI_TAGS) ? x(ae(ti), f.ADD_DATA_URI_TAGS, Y) : ti, be = j(f, "FORBID_CONTENTS") && te(f.FORBID_CONTENTS) ? x({}, f.FORBID_CONTENTS, Y) : $s, wt = j(f, "FORBID_TAGS") && te(f.FORBID_TAGS) ? x({}, f.FORBID_TAGS, Y) : ae({}), zt = j(f, "FORBID_ATTR") && te(f.FORBID_ATTR) ? x({}, f.FORBID_ATTR, Y) : ae({}), Je = j(f, "USE_PROFILES") ? f.USE_PROFILES && typeof f.USE_PROFILES == "object" ? ae(f.USE_PROFILES) : f.USE_PROFILES : !1, Wn = f.ALLOW_ARIA_ATTR !== !1, vs = f.ALLOW_DATA_ATTR !== !1, Yn = f.ALLOW_UNKNOWN_PROTOCOLS || !1, Jn = f.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ce = f.SAFE_FOR_TEMPLATES || !1, kt = f.SAFE_FOR_XML !== !1, Be = f.WHOLE_DOCUMENT || !1, Ye = f.RETURN_DOM || !1, qt = f.RETURN_DOM_FRAGMENT || !1, Kt = f.RETURN_TRUSTED_TYPE || !1, Cs = f.FORCE_BODY || !1, Xn = f.SANITIZE_DOM !== !1, Qn = f.SANITIZE_NAMED_PROPS || !1, Rs = f.KEEP_CONTENT !== !1, St = f.IN_PLACE || !1, Gn = Vo(f.ALLOWED_URI_REGEXP) ? f.ALLOWED_URI_REGEXP : Li, Xe = typeof f.NAMESPACE == "string" ? f.NAMESPACE : we, Bs = j(f, "MATHML_TEXT_INTEGRATION_POINTS") && f.MATHML_TEXT_INTEGRATION_POINTS && typeof f.MATHML_TEXT_INTEGRATION_POINTS == "object" ? ae(f.MATHML_TEXT_INTEGRATION_POINTS) : x({}, ["mi", "mo", "mn", "ms", "mtext"]), Fs = j(f, "HTML_INTEGRATION_POINTS") && f.HTML_INTEGRATION_POINTS && typeof f.HTML_INTEGRATION_POINTS == "object" ? ae(f.HTML_INTEGRATION_POINTS) : x({}, ["annotation-xml"]);
    const b = j(f, "CUSTOM_ELEMENT_HANDLING") && f.CUSTOM_ELEMENT_HANDLING && typeof f.CUSTOM_ELEMENT_HANDLING == "object" ? ae(f.CUSTOM_ELEMENT_HANDLING) : rt(null);
    if (z = rt(null), j(b, "tagNameCheck") && ni(b.tagNameCheck) && (z.tagNameCheck = b.tagNameCheck), j(b, "attributeNameCheck") && ni(b.attributeNameCheck) && (z.attributeNameCheck = b.attributeNameCheck), j(b, "allowCustomizedBuiltInElements") && typeof b.allowCustomizedBuiltInElements == "boolean" && (z.allowCustomizedBuiltInElements = b.allowCustomizedBuiltInElements), Ce && (vs = !1), qt && (Ye = !0), Je && (X = x({}, Ti), Z = rt(null), Je.html === !0 && (x(X, Ai), x(Z, Ei)), Je.svg === !0 && (x(X, Gs), x(Z, Ws), x(Z, Jt)), Je.svgFilters === !0 && (x(X, Hs), x(Z, Ws), x(Z, Jt)), Je.mathMl === !0 && (x(X, Vs), x(Z, _i), x(Z, Jt))), xe.tagCheck = null, xe.attributeCheck = null, j(f, "ADD_TAGS") && (typeof f.ADD_TAGS == "function" ? xe.tagCheck = f.ADD_TAGS : te(f.ADD_TAGS) && (X === Hn && (X = ae(X)), x(X, f.ADD_TAGS, Y))), j(f, "ADD_ATTR") && (typeof f.ADD_ATTR == "function" ? xe.attributeCheck = f.ADD_ATTR : te(f.ADD_ATTR) && (Z === Vn && (Z = ae(Z)), x(Z, f.ADD_ATTR, Y))), j(f, "ADD_URI_SAFE_ATTR") && te(f.ADD_URI_SAFE_ATTR) && x(Ps, f.ADD_URI_SAFE_ATTR, Y), j(f, "FORBID_CONTENTS") && te(f.FORBID_CONTENTS) && (be === $s && (be = ae(be)), x(be, f.FORBID_CONTENTS, Y)), j(f, "ADD_FORBID_CONTENTS") && te(f.ADD_FORBID_CONTENTS) && (be === $s && (be = ae(be)), x(be, f.ADD_FORBID_CONTENTS, Y)), Rs && (X["#text"] = !0), Be && x(X, ["html", "head", "body"]), X.table && (x(X, ["tbody"]), delete wt.tbody), f.TRUSTED_TYPES_POLICY) {
      if (typeof f.TRUSTED_TYPES_POLICY.createHTML != "function")
        throw Yt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
      if (typeof f.TRUSTED_TYPES_POLICY.createScriptURL != "function")
        throw Yt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
      S = f.TRUSTED_TYPES_POLICY, E = S.createHTML("");
    } else
      S === void 0 && (S = oa(g, i)), S !== null && typeof E == "string" && (E = S.createHTML(""));
    re && re(f), Qe = f;
  }, ii = x({}, [...Gs, ...Hs, ...Wo]), ri = x({}, [...Vs, ...Yo]), _o = function(f) {
    let b = I(f);
    (!b || !b.tagName) && (b = {
      namespaceURI: Xe,
      tagName: "template"
    });
    const _ = It(f.tagName), R = It(b.tagName);
    return Ms[f.namespaceURI] ? f.namespaceURI === Ht ? b.namespaceURI === we ? _ === "svg" : b.namespaceURI === Gt ? _ === "svg" && (R === "annotation-xml" || Bs[R]) : !!ii[_] : f.namespaceURI === Gt ? b.namespaceURI === we ? _ === "math" : b.namespaceURI === Ht ? _ === "math" && Fs[R] : !!ri[_] : f.namespaceURI === we ? b.namespaceURI === Ht && !Fs[R] || b.namespaceURI === Gt && !Bs[R] ? !1 : !ri[_] && (So[_] || !ii[_]) : !!(At === "application/xhtml+xml" && Ms[f.namespaceURI]) : !1;
  }, me = function(f) {
    et(e.removed, {
      element: f
    });
    try {
      I(f).removeChild(f);
    } catch {
      A(f);
    }
  }, Fe = function(f, b) {
    try {
      et(e.removed, {
        attribute: b.getAttributeNode(f),
        from: b
      });
    } catch {
      et(e.removed, {
        attribute: null,
        from: b
      });
    }
    if (b.removeAttribute(f), f === "is")
      if (Ye || qt)
        try {
          me(b);
        } catch {
        }
      else
        try {
          b.setAttribute(f, "");
        } catch {
        }
  }, oi = function(f) {
    let b = null, _ = null;
    if (Cs)
      f = "<remove></remove>" + f;
    else {
      const V = bi(f, /^[\r\n\t ]+/);
      _ = V && V[0];
    }
    At === "application/xhtml+xml" && Xe === we && (f = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + f + "</body></html>");
    const R = S ? S.createHTML(f) : f;
    if (Xe === we)
      try {
        b = new d().parseFromString(R, At);
      } catch {
      }
    if (!b || !b.documentElement) {
      b = C.createDocument(Xe, "template", null);
      try {
        b.documentElement.innerHTML = Ds ? E : R;
      } catch {
      }
    }
    const H = b.body || b.documentElement;
    return f && _ && H.insertBefore(t.createTextNode(_), H.childNodes[0] || null), Xe === we ? B.call(b, Be ? "html" : "body")[0] : Be ? b.documentElement : H;
  }, ai = function(f) {
    return M.call(
      f.ownerDocument || f,
      f,
      // eslint-disable-next-line no-bitwise
      l.SHOW_ELEMENT | l.SHOW_COMMENT | l.SHOW_TEXT | l.SHOW_PROCESSING_INSTRUCTION | l.SHOW_CDATA_SECTION,
      null
    );
  }, li = function(f) {
    f.normalize();
    const b = M.call(
      f.ownerDocument || f,
      f,
      // eslint-disable-next-line no-bitwise
      l.SHOW_TEXT | l.SHOW_COMMENT | l.SHOW_CDATA_SECTION | l.SHOW_PROCESSING_INSTRUCTION,
      null
    );
    let _ = b.nextNode();
    for (; _; ) {
      let R = _.data;
      Ze([le, Te, We], (H) => {
        R = tt(R, H, " ");
      }), _.data = R, _ = b.nextNode();
    }
  }, Us = function(f) {
    return f instanceof h && (typeof f.nodeName != "string" || typeof f.textContent != "string" || typeof f.removeChild != "function" || !(f.attributes instanceof p) || typeof f.removeAttribute != "function" || typeof f.setAttribute != "function" || typeof f.namespaceURI != "string" || typeof f.insertBefore != "function" || typeof f.hasChildNodes != "function");
  }, Vt = function(f) {
    if (!w || typeof f != "object" || f === null)
      return !1;
    try {
      return typeof w(f) == "number";
    } catch {
      return !1;
    }
  };
  function Ee(O, f, b) {
    Ze(O, (_) => {
      _.call(e, f, b, Qe);
    });
  }
  const ci = function(f) {
    let b = null;
    if (Ee(F.beforeSanitizeElements, f, null), Us(f))
      return me(f), !0;
    const _ = Y(f.nodeName);
    if (Ee(F.uponSanitizeElement, f, {
      tagName: _,
      allowedTags: X
    }), kt && f.hasChildNodes() && !Vt(f.firstElementChild) && ee(/<[/\w!]/g, f.innerHTML) && ee(/<[/\w!]/g, f.textContent) || kt && f.namespaceURI === we && _ === "style" && Vt(f.firstElementChild) || f.nodeType === st.progressingInstruction || kt && f.nodeType === st.comment && ee(/<[/\w]/g, f.data))
      return me(f), !0;
    if (wt[_] || !(xe.tagCheck instanceof Function && xe.tagCheck(_)) && !X[_]) {
      if (!wt[_] && fi(_) && (z.tagNameCheck instanceof RegExp && ee(z.tagNameCheck, _) || z.tagNameCheck instanceof Function && z.tagNameCheck(_)))
        return !1;
      if (Rs && !be[_]) {
        const R = I(f) || f.parentNode, H = L(f) || f.childNodes;
        if (H && R) {
          const V = H.length;
          for (let oe = V - 1; oe >= 0; --oe) {
            const Re = y(H[oe], !0);
            R.insertBefore(Re, k(f));
          }
        }
      }
      return me(f), !0;
    }
    return f instanceof c && !_o(f) || (_ === "noscript" || _ === "noembed" || _ === "noframes") && ee(/<\/no(script|embed|frames)/i, f.innerHTML) ? (me(f), !0) : (Ce && f.nodeType === st.text && (b = f.textContent, Ze([le, Te, We], (R) => {
      b = tt(b, R, " ");
    }), f.textContent !== b && (et(e.removed, {
      element: f.cloneNode()
    }), f.textContent = b)), Ee(F.afterSanitizeElements, f, null), !1);
  }, ui = function(f, b, _) {
    if (zt[b] || Xn && (b === "id" || b === "name") && (_ in t || _ in Eo))
      return !1;
    const R = Z[b] || xe.attributeCheck instanceof Function && xe.attributeCheck(b, f);
    if (!(vs && !zt[b] && ee(go, b))) {
      if (!(Wn && ee(yo, b))) {
        if (!R || zt[b]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(fi(f) && (z.tagNameCheck instanceof RegExp && ee(z.tagNameCheck, f) || z.tagNameCheck instanceof Function && z.tagNameCheck(f)) && (z.attributeNameCheck instanceof RegExp && ee(z.attributeNameCheck, b) || z.attributeNameCheck instanceof Function && z.attributeNameCheck(b, f)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            b === "is" && z.allowCustomizedBuiltInElements && (z.tagNameCheck instanceof RegExp && ee(z.tagNameCheck, _) || z.tagNameCheck instanceof Function && z.tagNameCheck(_)))
          ) return !1;
        } else if (!Ps[b]) {
          if (!ee(Gn, tt(_, Kn, ""))) {
            if (!((b === "src" || b === "xlink:href" || b === "href") && f !== "script" && wi(_, "data:") === 0 && ei[f])) {
              if (!(Yn && !ee(bo, tt(_, Kn, "")))) {
                if (_)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Lo = x({}, ["annotation-xml", "color-profile", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "missing-glyph"]), fi = function(f) {
    return !Lo[It(f)] && ee(wo, f);
  }, hi = function(f) {
    Ee(F.beforeSanitizeAttributes, f, null);
    const b = f.attributes;
    if (!b || Us(f))
      return;
    const _ = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: Z,
      forceKeepAttr: void 0
    };
    let R = b.length;
    for (; R--; ) {
      const H = b[R], V = H.name, oe = H.namespaceURI, Re = H.value, _e = Y(V), qs = Re;
      let Q = V === "value" ? qs : Uo(qs);
      if (_.attrName = _e, _.attrValue = Q, _.keepAttr = !0, _.forceKeepAttr = void 0, Ee(F.uponSanitizeAttribute, f, _), Q = _.attrValue, Qn && (_e === "id" || _e === "name") && wi(Q, Zn) !== 0 && (Fe(V, f), Q = Zn + Q), kt && ee(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, Q)) {
        Fe(V, f);
        continue;
      }
      if (_e === "attributename" && bi(Q, "href")) {
        Fe(V, f);
        continue;
      }
      if (_.forceKeepAttr)
        continue;
      if (!_.keepAttr) {
        Fe(V, f);
        continue;
      }
      if (!Jn && ee(/\/>/i, Q)) {
        Fe(V, f);
        continue;
      }
      Ce && Ze([le, Te, We], (di) => {
        Q = tt(Q, di, " ");
      });
      const pi = Y(f.nodeName);
      if (!ui(pi, _e, Q)) {
        Fe(V, f);
        continue;
      }
      if (S && typeof g == "object" && typeof g.getAttributeType == "function" && !oe)
        switch (g.getAttributeType(pi, _e)) {
          case "TrustedHTML": {
            Q = S.createHTML(Q);
            break;
          }
          case "TrustedScriptURL": {
            Q = S.createScriptURL(Q);
            break;
          }
        }
      if (Q !== qs)
        try {
          oe ? f.setAttributeNS(oe, V, Q) : f.setAttribute(V, Q), Us(f) ? me(f) : yi(e.removed);
        } catch {
          Fe(V, f);
        }
    }
    Ee(F.afterSanitizeAttributes, f, null);
  }, zs = function(f) {
    let b = null;
    const _ = ai(f);
    for (Ee(F.beforeSanitizeShadowDOM, f, null); b = _.nextNode(); )
      Ee(F.uponSanitizeShadowNode, b, null), ci(b), hi(b), b.content instanceof r && zs(b.content);
    Ee(F.afterSanitizeShadowDOM, f, null);
  }, Wt = function(f) {
    if (f.nodeType === st.element && f.shadowRoot instanceof r) {
      const R = f.shadowRoot;
      Wt(R), zs(R);
    }
    const b = f.childNodes;
    if (!b)
      return;
    const _ = [];
    Ze(b, (R) => {
      et(_, R);
    });
    for (const R of _)
      Wt(R);
  };
  return e.sanitize = function(O) {
    let f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, b = null, _ = null, R = null, H = null;
    if (Ds = !O, Ds && (O = "<!-->"), typeof O != "string" && !Vt(O) && (O = Ho(O), typeof O != "string"))
      throw Yt("dirty is not a string, aborting");
    if (!e.isSupported)
      return O;
    if (xs || js(f), e.removed = [], typeof O == "string" && (St = !1), St) {
      const Re = O.nodeName;
      if (typeof Re == "string") {
        const _e = Y(Re);
        if (!X[_e] || wt[_e])
          throw Yt("root node is forbidden and cannot be sanitized in-place");
      }
      Wt(O);
    } else if (Vt(O))
      b = oi("<!---->"), _ = b.ownerDocument.importNode(O, !0), _.nodeType === st.element && _.nodeName === "BODY" || _.nodeName === "HTML" ? b = _ : b.appendChild(_), Wt(_);
    else {
      if (!Ye && !Ce && !Be && // eslint-disable-next-line unicorn/prefer-includes
      O.indexOf("<") === -1)
        return S && Kt ? S.createHTML(O) : O;
      if (b = oi(O), !b)
        return Ye ? null : Kt ? E : "";
    }
    b && Cs && me(b.firstChild);
    const V = ai(St ? O : b);
    for (; R = V.nextNode(); )
      ci(R), hi(R), R.content instanceof r && zs(R.content);
    if (St)
      return Ce && li(O), O;
    if (Ye) {
      if (Ce && li(b), qt)
        for (H = J.call(b.ownerDocument); b.firstChild; )
          H.appendChild(b.firstChild);
      else
        H = b;
      return (Z.shadowroot || Z.shadowrootmode) && (H = U.call(n, H, !0)), H;
    }
    let oe = Be ? b.outerHTML : b.innerHTML;
    return Be && X["!doctype"] && b.ownerDocument && b.ownerDocument.doctype && b.ownerDocument.doctype.name && ee(na, b.ownerDocument.doctype.name) && (oe = "<!DOCTYPE " + b.ownerDocument.doctype.name + `>
` + oe), Ce && Ze([le, Te, We], (Re) => {
      oe = tt(oe, Re, " ");
    }), S && Kt ? S.createHTML(oe) : oe;
  }, e.setConfig = function() {
    let O = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    js(O), xs = !0;
  }, e.clearConfig = function() {
    Qe = null, xs = !1;
  }, e.isValidAttribute = function(O, f, b) {
    Qe || js({});
    const _ = Y(O), R = Y(f);
    return ui(_, R, b);
  }, e.addHook = function(O, f) {
    typeof f == "function" && et(F[O], f);
  }, e.removeHook = function(O, f) {
    if (f !== void 0) {
      const b = Fo(F[O], f);
      return b === -1 ? void 0 : jo(F[O], b, 1)[0];
    }
    return yi(F[O]);
  }, e.removeHooks = function(O) {
    F[O] = [];
  }, e.removeAllHooks = function() {
    F = Ii();
  }, e;
}
var aa = lr();
function bn(s, e) {
  return `${s.endsWith("/") ? s.slice(0, -1) : s}/${e}`;
}
function De(s) {
  const e = document.createElement("div");
  return e.textContent = s, e.innerHTML;
}
const la = [
  "p",
  "br",
  "strong",
  "em",
  "b",
  "i",
  "u",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "ul",
  "ol",
  "li",
  "blockquote",
  "code",
  "pre",
  "a",
  "hr",
  "table",
  "thead",
  "tbody",
  "tr",
  "th",
  "td",
  "img",
  "span",
  "div"
], ca = [
  "href",
  "title",
  "alt",
  "src",
  "class",
  "id",
  "colspan",
  "rowspan"
], ua = ["javascript:", "vbscript:", "data:text/html"];
function fa(s) {
  const e = s.trim().replace(/\s+/g, "").toLowerCase();
  return ua.some((t) => e.startsWith(t));
}
function ha(s) {
  return aa.sanitize(s, {
    ALLOWED_TAGS: [...la],
    ALLOWED_ATTR: [...ca],
    ALLOWED_URI_REGEXP: /^(?:(?:https?|mailto|tel|ftp):|[^a-z]|[a-z+.-]+(?:[^a-z+.\-:]|$))/i
  }).replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "").replace(
    /\s(href|src)\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/gi,
    (t, n, i, r, o, a) => {
      const c = (r ?? o ?? a ?? "").trim();
      return c && fa(c) ? ` ${n}=""` : t;
    }
  );
}
function pa(s) {
  const e = s.lessons.map((t) => ({
    kind: "lesson",
    id: t.id,
    title: t.title ?? t.id,
    lesson: t
  }));
  for (const t of s.assessments ?? [])
    e.push({
      kind: "assessment",
      id: t.id,
      title: t.id.replace(/_/g, " "),
      file: t.file
    });
  return e;
}
function da(s, e, t, n, i, r, o) {
  s.innerHTML = e.map((a) => {
    const c = a.id === t, l = a.kind === "lesson" ? n.includes(a.id) : i.has(a.id), u = o ? !o(a.id) : !1, p = c ? ' aria-current="page"' : "", h = a.kind === "assessment" ? "lxpack-nav-assessment" : "";
    return `
      <button
        type="button"
        class="lxpack-nav-item ${c ? "active" : ""} ${l ? "completed" : ""} ${h}"
        data-nav-id="${De(a.id)}"
        ${u ? " disabled" : ""}
        ${p}
      >
        ${De(a.title)}${a.kind === "assessment" ? " (Quiz)" : ""}
      </button>
    `;
  }).join(""), s.querySelectorAll(".lxpack-nav-item").forEach((a) => {
    a.addEventListener("click", () => {
      const c = a.dataset.navId;
      c && r(c);
    });
  });
}
function wn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
var He = wn();
function cr(s) {
  He = s;
}
var vt = { exec: () => null };
function P(s, e = "") {
  let t = typeof s == "string" ? s : s.source;
  const n = {
    replace: (i, r) => {
      let o = typeof r == "string" ? r : r.source;
      return o = o.replace(ne.caret, "$1"), t = t.replace(i, o), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
var ne = {
  codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  listReplaceTabs: /^\t+/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\] /,
  listReplaceTask: /^\[[ xX]\] +/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (s) => new RegExp(`^( {0,3}${s})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: (s) => new RegExp(`^ {0,${Math.min(3, s - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
  hrRegex: (s) => new RegExp(`^ {0,${Math.min(3, s - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
  fencesBeginRegex: (s) => new RegExp(`^ {0,${Math.min(3, s - 1)}}(?:\`\`\`|~~~)`),
  headingBeginRegex: (s) => new RegExp(`^ {0,${Math.min(3, s - 1)}}#`),
  htmlBeginRegex: (s) => new RegExp(`^ {0,${Math.min(3, s - 1)}}<(?:[a-z].*>|!--)`, "i")
}, ma = /^(?:[ \t]*(?:\n|$))+/, ga = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, ya = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Dt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, ba = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, kn = /(?:[*+-]|\d{1,9}[.)])/, ur = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, fr = P(ur).replace(/bull/g, kn).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), wa = P(ur).replace(/bull/g, kn).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), Sn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ka = /^[^\n]+/, An = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Sa = P(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", An).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Aa = P(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, kn).getRegex(), gs = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Tn = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ta = P(
  "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
  "i"
).replace("comment", Tn).replace("tag", gs).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), hr = P(Sn).replace("hr", Dt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", gs).getRegex(), Ea = P(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", hr).getRegex(), En = {
  blockquote: Ea,
  code: ga,
  def: Sa,
  fences: ya,
  heading: ba,
  hr: Dt,
  html: Ta,
  lheading: fr,
  list: Aa,
  newline: ma,
  paragraph: hr,
  table: vt,
  text: ka
}, Ni = P(
  "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
).replace("hr", Dt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", gs).getRegex(), _a = {
  ...En,
  lheading: wa,
  table: Ni,
  paragraph: P(Sn).replace("hr", Dt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Ni).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", gs).getRegex()
}, La = {
  ...En,
  html: P(
    `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
  ).replace("comment", Tn).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: vt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: P(Sn).replace("hr", Dt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", fr).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Ia = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Na = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, pr = /^( {2,}|\\)\n(?!\s*$)/, Oa = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, ys = /[\p{P}\p{S}]/u, _n = /[\s\p{P}\p{S}]/u, dr = /[^\s\p{P}\p{S}]/u, va = P(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, _n).getRegex(), mr = /(?!~)[\p{P}\p{S}]/u, xa = /(?!~)[\s\p{P}\p{S}]/u, Ca = /(?:[^\s\p{P}\p{S}]|~)/u, Ra = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g, gr = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, $a = P(gr, "u").replace(/punct/g, ys).getRegex(), Pa = P(gr, "u").replace(/punct/g, mr).getRegex(), yr = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Da = P(yr, "gu").replace(/notPunctSpace/g, dr).replace(/punctSpace/g, _n).replace(/punct/g, ys).getRegex(), Ma = P(yr, "gu").replace(/notPunctSpace/g, Ca).replace(/punctSpace/g, xa).replace(/punct/g, mr).getRegex(), Ba = P(
  "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
  "gu"
).replace(/notPunctSpace/g, dr).replace(/punctSpace/g, _n).replace(/punct/g, ys).getRegex(), Fa = P(/\\(punct)/, "gu").replace(/punct/g, ys).getRegex(), ja = P(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Ua = P(Tn).replace("(?:-->|$)", "-->").getRegex(), za = P(
  "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>"
).replace("comment", Ua).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), as = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, qa = P(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", as).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), br = P(/^!?\[(label)\]\[(ref)\]/).replace("label", as).replace("ref", An).getRegex(), wr = P(/^!?\[(ref)\](?:\[\])?/).replace("ref", An).getRegex(), Ka = P("reflink|nolink(?!\\()", "g").replace("reflink", br).replace("nolink", wr).getRegex(), Ln = {
  _backpedal: vt,
  // only used for GFM url
  anyPunctuation: Fa,
  autolink: ja,
  blockSkip: Ra,
  br: pr,
  code: Na,
  del: vt,
  emStrongLDelim: $a,
  emStrongRDelimAst: Da,
  emStrongRDelimUnd: Ba,
  escape: Ia,
  link: qa,
  nolink: wr,
  punctuation: va,
  reflink: br,
  reflinkSearch: Ka,
  tag: za,
  text: Oa,
  url: vt
}, Ga = {
  ...Ln,
  link: P(/^!?\[(label)\]\((.*?)\)/).replace("label", as).getRegex(),
  reflink: P(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", as).getRegex()
}, an = {
  ...Ln,
  emStrongRDelimAst: Ma,
  emStrongLDelim: Pa,
  url: P(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ha = {
  ...an,
  br: P(pr).replace("{2,}", "*").getRegex(),
  text: P(an.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Xt = {
  normal: En,
  gfm: _a,
  pedantic: La
}, Et = {
  normal: Ln,
  gfm: an,
  breaks: Ha,
  pedantic: Ga
}, Va = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Oi = (s) => Va[s];
function ke(s, e) {
  if (e) {
    if (ne.escapeTest.test(s))
      return s.replace(ne.escapeReplace, Oi);
  } else if (ne.escapeTestNoEncode.test(s))
    return s.replace(ne.escapeReplaceNoEncode, Oi);
  return s;
}
function vi(s) {
  try {
    s = encodeURI(s).replace(ne.percentDecode, "%");
  } catch {
    return null;
  }
  return s;
}
function xi(s, e) {
  var r;
  const t = s.replace(ne.findPipe, (o, a, c) => {
    let l = !1, u = a;
    for (; --u >= 0 && c[u] === "\\"; ) l = !l;
    return l ? "|" : " |";
  }), n = t.split(ne.splitPipe);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !((r = n.at(-1)) != null && r.trim()) && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; ) n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(ne.slashPipe, "|");
  return n;
}
function _t(s, e, t) {
  const n = s.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && s.charAt(n - i - 1) === e; )
    i++;
  return s.slice(0, n - i);
}
function Wa(s, e) {
  if (s.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < s.length; n++)
    if (s[n] === "\\")
      n++;
    else if (s[n] === e[0])
      t++;
    else if (s[n] === e[1] && (t--, t < 0))
      return n;
  return t > 0 ? -2 : -1;
}
function Ci(s, e, t, n, i) {
  const r = e.href, o = e.title || null, a = s[1].replace(i.other.outputLinkReplace, "$1");
  n.state.inLink = !0;
  const c = {
    type: s[0].charAt(0) === "!" ? "image" : "link",
    raw: t,
    href: r,
    title: o,
    text: a,
    tokens: n.inlineTokens(a)
  };
  return n.state.inLink = !1, c;
}
function Ya(s, e, t) {
  const n = s.match(t.other.indentCodeCompensation);
  if (n === null)
    return e;
  const i = n[1];
  return e.split(`
`).map((r) => {
    const o = r.match(t.other.beginningSpace);
    if (o === null)
      return r;
    const [a] = o;
    return a.length >= i.length ? r.slice(i.length) : r;
  }).join(`
`);
}
var ls = class {
  // set by the lexer
  constructor(s) {
    N(this, "options");
    N(this, "rules");
    // set by the lexer
    N(this, "lexer");
    this.options = s || He;
  }
  space(s) {
    const e = this.rules.block.newline.exec(s);
    if (e && e[0].length > 0)
      return {
        type: "space",
        raw: e[0]
      };
  }
  code(s) {
    const e = this.rules.block.code.exec(s);
    if (e) {
      const t = e[0].replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: e[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? t : _t(t, `
`)
      };
    }
  }
  fences(s) {
    const e = this.rules.block.fences.exec(s);
    if (e) {
      const t = e[0], n = Ya(t, e[3] || "", this.rules);
      return {
        type: "code",
        raw: t,
        lang: e[2] ? e[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : e[2],
        text: n
      };
    }
  }
  heading(s) {
    const e = this.rules.block.heading.exec(s);
    if (e) {
      let t = e[2].trim();
      if (this.rules.other.endingHash.test(t)) {
        const n = _t(t, "#");
        (this.options.pedantic || !n || this.rules.other.endingSpaceChar.test(n)) && (t = n.trim());
      }
      return {
        type: "heading",
        raw: e[0],
        depth: e[1].length,
        text: t,
        tokens: this.lexer.inline(t)
      };
    }
  }
  hr(s) {
    const e = this.rules.block.hr.exec(s);
    if (e)
      return {
        type: "hr",
        raw: _t(e[0], `
`)
      };
  }
  blockquote(s) {
    const e = this.rules.block.blockquote.exec(s);
    if (e) {
      let t = _t(e[0], `
`).split(`
`), n = "", i = "";
      const r = [];
      for (; t.length > 0; ) {
        let o = !1;
        const a = [];
        let c;
        for (c = 0; c < t.length; c++)
          if (this.rules.other.blockquoteStart.test(t[c]))
            a.push(t[c]), o = !0;
          else if (!o)
            a.push(t[c]);
          else
            break;
        t = t.slice(c);
        const l = a.join(`
`), u = l.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        n = n ? `${n}
${l}` : l, i = i ? `${i}
${u}` : u;
        const p = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(u, r, !0), this.lexer.state.top = p, t.length === 0)
          break;
        const h = r.at(-1);
        if ((h == null ? void 0 : h.type) === "code")
          break;
        if ((h == null ? void 0 : h.type) === "blockquote") {
          const d = h, g = d.raw + `
` + t.join(`
`), m = this.blockquote(g);
          r[r.length - 1] = m, n = n.substring(0, n.length - d.raw.length) + m.raw, i = i.substring(0, i.length - d.text.length) + m.text;
          break;
        } else if ((h == null ? void 0 : h.type) === "list") {
          const d = h, g = d.raw + `
` + t.join(`
`), m = this.list(g);
          r[r.length - 1] = m, n = n.substring(0, n.length - h.raw.length) + m.raw, i = i.substring(0, i.length - d.raw.length) + m.raw, t = g.substring(r.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return {
        type: "blockquote",
        raw: n,
        tokens: r,
        text: i
      };
    }
  }
  list(s) {
    let e = this.rules.block.list.exec(s);
    if (e) {
      let t = e[1].trim();
      const n = t.length > 1, i = {
        type: "list",
        raw: "",
        ordered: n,
        start: n ? +t.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      t = n ? `\\d{1,9}\\${t.slice(-1)}` : `\\${t}`, this.options.pedantic && (t = n ? t : "[*+-]");
      const r = this.rules.other.listItemRegex(t);
      let o = !1;
      for (; s; ) {
        let c = !1, l = "", u = "";
        if (!(e = r.exec(s)) || this.rules.block.hr.test(s))
          break;
        l = e[0], s = s.substring(l.length);
        let p = e[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (A) => " ".repeat(3 * A.length)), h = s.split(`
`, 1)[0], d = !p.trim(), g = 0;
        if (this.options.pedantic ? (g = 2, u = p.trimStart()) : d ? g = e[1].length + 1 : (g = e[2].search(this.rules.other.nonSpaceChar), g = g > 4 ? 1 : g, u = p.slice(g), g += e[1].length), d && this.rules.other.blankLine.test(h) && (l += h + `
`, s = s.substring(h.length + 1), c = !0), !c) {
          const A = this.rules.other.nextBulletRegex(g), k = this.rules.other.hrRegex(g), L = this.rules.other.fencesBeginRegex(g), I = this.rules.other.headingBeginRegex(g), w = this.rules.other.htmlBeginRegex(g);
          for (; s; ) {
            const S = s.split(`
`, 1)[0];
            let E;
            if (h = S, this.options.pedantic ? (h = h.replace(this.rules.other.listReplaceNesting, "  "), E = h) : E = h.replace(this.rules.other.tabCharGlobal, "    "), L.test(h) || I.test(h) || w.test(h) || A.test(h) || k.test(h))
              break;
            if (E.search(this.rules.other.nonSpaceChar) >= g || !h.trim())
              u += `
` + E.slice(g);
            else {
              if (d || p.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || L.test(p) || I.test(p) || k.test(p))
                break;
              u += `
` + h;
            }
            !d && !h.trim() && (d = !0), l += S + `
`, s = s.substring(S.length + 1), p = E.slice(g);
          }
        }
        i.loose || (o ? i.loose = !0 : this.rules.other.doubleBlankLine.test(l) && (o = !0));
        let m = null, y;
        this.options.gfm && (m = this.rules.other.listIsTask.exec(u), m && (y = m[0] !== "[ ] ", u = u.replace(this.rules.other.listReplaceTask, ""))), i.items.push({
          type: "list_item",
          raw: l,
          task: !!m,
          checked: y,
          loose: !1,
          text: u,
          tokens: []
        }), i.raw += l;
      }
      const a = i.items.at(-1);
      if (a)
        a.raw = a.raw.trimEnd(), a.text = a.text.trimEnd();
      else
        return;
      i.raw = i.raw.trimEnd();
      for (let c = 0; c < i.items.length; c++)
        if (this.lexer.state.top = !1, i.items[c].tokens = this.lexer.blockTokens(i.items[c].text, []), !i.loose) {
          const l = i.items[c].tokens.filter((p) => p.type === "space"), u = l.length > 0 && l.some((p) => this.rules.other.anyLine.test(p.raw));
          i.loose = u;
        }
      if (i.loose)
        for (let c = 0; c < i.items.length; c++)
          i.items[c].loose = !0;
      return i;
    }
  }
  html(s) {
    const e = this.rules.block.html.exec(s);
    if (e)
      return {
        type: "html",
        block: !0,
        raw: e[0],
        pre: e[1] === "pre" || e[1] === "script" || e[1] === "style",
        text: e[0]
      };
  }
  def(s) {
    const e = this.rules.block.def.exec(s);
    if (e) {
      const t = e[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = e[2] ? e[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = e[3] ? e[3].substring(1, e[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : e[3];
      return {
        type: "def",
        tag: t,
        raw: e[0],
        href: n,
        title: i
      };
    }
  }
  table(s) {
    var o;
    const e = this.rules.block.table.exec(s);
    if (!e || !this.rules.other.tableDelimiter.test(e[2]))
      return;
    const t = xi(e[1]), n = e[2].replace(this.rules.other.tableAlignChars, "").split("|"), i = (o = e[3]) != null && o.trim() ? e[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], r = {
      type: "table",
      raw: e[0],
      header: [],
      align: [],
      rows: []
    };
    if (t.length === n.length) {
      for (const a of n)
        this.rules.other.tableAlignRight.test(a) ? r.align.push("right") : this.rules.other.tableAlignCenter.test(a) ? r.align.push("center") : this.rules.other.tableAlignLeft.test(a) ? r.align.push("left") : r.align.push(null);
      for (let a = 0; a < t.length; a++)
        r.header.push({
          text: t[a],
          tokens: this.lexer.inline(t[a]),
          header: !0,
          align: r.align[a]
        });
      for (const a of i)
        r.rows.push(xi(a, r.header.length).map((c, l) => ({
          text: c,
          tokens: this.lexer.inline(c),
          header: !1,
          align: r.align[l]
        })));
      return r;
    }
  }
  lheading(s) {
    const e = this.rules.block.lheading.exec(s);
    if (e)
      return {
        type: "heading",
        raw: e[0],
        depth: e[2].charAt(0) === "=" ? 1 : 2,
        text: e[1],
        tokens: this.lexer.inline(e[1])
      };
  }
  paragraph(s) {
    const e = this.rules.block.paragraph.exec(s);
    if (e) {
      const t = e[1].charAt(e[1].length - 1) === `
` ? e[1].slice(0, -1) : e[1];
      return {
        type: "paragraph",
        raw: e[0],
        text: t,
        tokens: this.lexer.inline(t)
      };
    }
  }
  text(s) {
    const e = this.rules.block.text.exec(s);
    if (e)
      return {
        type: "text",
        raw: e[0],
        text: e[0],
        tokens: this.lexer.inline(e[0])
      };
  }
  escape(s) {
    const e = this.rules.inline.escape.exec(s);
    if (e)
      return {
        type: "escape",
        raw: e[0],
        text: e[1]
      };
  }
  tag(s) {
    const e = this.rules.inline.tag.exec(s);
    if (e)
      return !this.lexer.state.inLink && this.rules.other.startATag.test(e[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(e[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(e[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(e[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: e[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: e[0]
      };
  }
  link(s) {
    const e = this.rules.inline.link.exec(s);
    if (e) {
      const t = e[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(t)) {
        if (!this.rules.other.endAngleBracket.test(t))
          return;
        const r = _t(t.slice(0, -1), "\\");
        if ((t.length - r.length) % 2 === 0)
          return;
      } else {
        const r = Wa(e[2], "()");
        if (r === -2)
          return;
        if (r > -1) {
          const a = (e[0].indexOf("!") === 0 ? 5 : 4) + e[1].length + r;
          e[2] = e[2].substring(0, r), e[0] = e[0].substring(0, a).trim(), e[3] = "";
        }
      }
      let n = e[2], i = "";
      if (this.options.pedantic) {
        const r = this.rules.other.pedanticHrefTitle.exec(n);
        r && (n = r[1], i = r[3]);
      } else
        i = e[3] ? e[3].slice(1, -1) : "";
      return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(t) ? n = n.slice(1) : n = n.slice(1, -1)), Ci(e, {
        href: n && n.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, e[0], this.lexer, this.rules);
    }
  }
  reflink(s, e) {
    let t;
    if ((t = this.rules.inline.reflink.exec(s)) || (t = this.rules.inline.nolink.exec(s))) {
      const n = (t[2] || t[1]).replace(this.rules.other.multipleSpaceGlobal, " "), i = e[n.toLowerCase()];
      if (!i) {
        const r = t[0].charAt(0);
        return {
          type: "text",
          raw: r,
          text: r
        };
      }
      return Ci(t, i, t[0], this.lexer, this.rules);
    }
  }
  emStrong(s, e, t = "") {
    let n = this.rules.inline.emStrongLDelim.exec(s);
    if (!n || n[3] && t.match(this.rules.other.unicodeAlphaNumeric)) return;
    if (!(n[1] || n[2] || "") || !t || this.rules.inline.punctuation.exec(t)) {
      const r = [...n[0]].length - 1;
      let o, a, c = r, l = 0;
      const u = n[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (u.lastIndex = 0, e = e.slice(-1 * s.length + r); (n = u.exec(e)) != null; ) {
        if (o = n[1] || n[2] || n[3] || n[4] || n[5] || n[6], !o) continue;
        if (a = [...o].length, n[3] || n[4]) {
          c += a;
          continue;
        } else if ((n[5] || n[6]) && r % 3 && !((r + a) % 3)) {
          l += a;
          continue;
        }
        if (c -= a, c > 0) continue;
        a = Math.min(a, a + c + l);
        const p = [...n[0]][0].length, h = s.slice(0, r + n.index + p + a);
        if (Math.min(r, a) % 2) {
          const g = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: g,
            tokens: this.lexer.inlineTokens(g)
          };
        }
        const d = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: d,
          tokens: this.lexer.inlineTokens(d)
        };
      }
    }
  }
  codespan(s) {
    const e = this.rules.inline.code.exec(s);
    if (e) {
      let t = e[2].replace(this.rules.other.newLineCharGlobal, " ");
      const n = this.rules.other.nonSpaceChar.test(t), i = this.rules.other.startingSpaceChar.test(t) && this.rules.other.endingSpaceChar.test(t);
      return n && i && (t = t.substring(1, t.length - 1)), {
        type: "codespan",
        raw: e[0],
        text: t
      };
    }
  }
  br(s) {
    const e = this.rules.inline.br.exec(s);
    if (e)
      return {
        type: "br",
        raw: e[0]
      };
  }
  del(s) {
    const e = this.rules.inline.del.exec(s);
    if (e)
      return {
        type: "del",
        raw: e[0],
        text: e[2],
        tokens: this.lexer.inlineTokens(e[2])
      };
  }
  autolink(s) {
    const e = this.rules.inline.autolink.exec(s);
    if (e) {
      let t, n;
      return e[2] === "@" ? (t = e[1], n = "mailto:" + t) : (t = e[1], n = t), {
        type: "link",
        raw: e[0],
        text: t,
        href: n,
        tokens: [
          {
            type: "text",
            raw: t,
            text: t
          }
        ]
      };
    }
  }
  url(s) {
    var t;
    let e;
    if (e = this.rules.inline.url.exec(s)) {
      let n, i;
      if (e[2] === "@")
        n = e[0], i = "mailto:" + n;
      else {
        let r;
        do
          r = e[0], e[0] = ((t = this.rules.inline._backpedal.exec(e[0])) == null ? void 0 : t[0]) ?? "";
        while (r !== e[0]);
        n = e[0], e[1] === "www." ? i = "http://" + e[0] : i = e[0];
      }
      return {
        type: "link",
        raw: e[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  inlineText(s) {
    const e = this.rules.inline.text.exec(s);
    if (e) {
      const t = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: e[0],
        text: e[0],
        escaped: t
      };
    }
  }
}, Le = class ln {
  constructor(e) {
    N(this, "tokens");
    N(this, "options");
    N(this, "state");
    N(this, "tokenizer");
    N(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || He, this.options.tokenizer = this.options.tokenizer || new ls(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      other: ne,
      block: Xt.normal,
      inline: Et.normal
    };
    this.options.pedantic ? (t.block = Xt.pedantic, t.inline = Et.pedantic) : this.options.gfm && (t.block = Xt.gfm, this.options.breaks ? t.inline = Et.breaks : t.inline = Et.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Xt,
      inline: Et
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new ln(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new ln(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(ne.carriageReturn, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = [], n = !1) {
    var i, r, o;
    for (this.options.pedantic && (e = e.replace(ne.tabCharGlobal, "    ").replace(ne.spaceLine, "")); e; ) {
      let a;
      if ((r = (i = this.options.extensions) == null ? void 0 : i.block) != null && r.some((l) => (a = l.call({ lexer: this }, e, t)) ? (e = e.substring(a.raw.length), t.push(a), !0) : !1))
        continue;
      if (a = this.tokenizer.space(e)) {
        e = e.substring(a.raw.length);
        const l = t.at(-1);
        a.raw.length === 1 && l !== void 0 ? l.raw += `
` : t.push(a);
        continue;
      }
      if (a = this.tokenizer.code(e)) {
        e = e.substring(a.raw.length);
        const l = t.at(-1);
        (l == null ? void 0 : l.type) === "paragraph" || (l == null ? void 0 : l.type) === "text" ? (l.raw += `
` + a.raw, l.text += `
` + a.text, this.inlineQueue.at(-1).src = l.text) : t.push(a);
        continue;
      }
      if (a = this.tokenizer.fences(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.heading(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.hr(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.blockquote(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.list(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.html(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.def(e)) {
        e = e.substring(a.raw.length);
        const l = t.at(-1);
        (l == null ? void 0 : l.type) === "paragraph" || (l == null ? void 0 : l.type) === "text" ? (l.raw += `
` + a.raw, l.text += `
` + a.raw, this.inlineQueue.at(-1).src = l.text) : this.tokens.links[a.tag] || (this.tokens.links[a.tag] = {
          href: a.href,
          title: a.title
        });
        continue;
      }
      if (a = this.tokenizer.table(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.lheading(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      let c = e;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let l = 1 / 0;
        const u = e.slice(1);
        let p;
        this.options.extensions.startBlock.forEach((h) => {
          p = h.call({ lexer: this }, u), typeof p == "number" && p >= 0 && (l = Math.min(l, p));
        }), l < 1 / 0 && l >= 0 && (c = e.substring(0, l + 1));
      }
      if (this.state.top && (a = this.tokenizer.paragraph(c))) {
        const l = t.at(-1);
        n && (l == null ? void 0 : l.type) === "paragraph" ? (l.raw += `
` + a.raw, l.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = l.text) : t.push(a), n = c.length !== e.length, e = e.substring(a.raw.length);
        continue;
      }
      if (a = this.tokenizer.text(e)) {
        e = e.substring(a.raw.length);
        const l = t.at(-1);
        (l == null ? void 0 : l.type) === "text" ? (l.raw += `
` + a.raw, l.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = l.text) : t.push(a);
        continue;
      }
      if (e) {
        const l = "Infinite loop on byte: " + e.charCodeAt(0);
        if (this.options.silent) {
          console.error(l);
          break;
        } else
          throw new Error(l);
      }
    }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    var a, c, l;
    let n = e, i = null;
    if (this.tokens.links) {
      const u = Object.keys(this.tokens.links);
      if (u.length > 0)
        for (; (i = this.tokenizer.rules.inline.reflinkSearch.exec(n)) != null; )
          u.includes(i[0].slice(i[0].lastIndexOf("[") + 1, -1)) && (n = n.slice(0, i.index) + "[" + "a".repeat(i[0].length - 2) + "]" + n.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (i = this.tokenizer.rules.inline.anyPunctuation.exec(n)) != null; )
      n = n.slice(0, i.index) + "++" + n.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; (i = this.tokenizer.rules.inline.blockSkip.exec(n)) != null; )
      n = n.slice(0, i.index) + "[" + "a".repeat(i[0].length - 2) + "]" + n.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    let r = !1, o = "";
    for (; e; ) {
      r || (o = ""), r = !1;
      let u;
      if ((c = (a = this.options.extensions) == null ? void 0 : a.inline) != null && c.some((h) => (u = h.call({ lexer: this }, e, t)) ? (e = e.substring(u.raw.length), t.push(u), !0) : !1))
        continue;
      if (u = this.tokenizer.escape(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.tag(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.link(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.reflink(e, this.tokens.links)) {
        e = e.substring(u.raw.length);
        const h = t.at(-1);
        u.type === "text" && (h == null ? void 0 : h.type) === "text" ? (h.raw += u.raw, h.text += u.text) : t.push(u);
        continue;
      }
      if (u = this.tokenizer.emStrong(e, n, o)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.codespan(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.br(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.del(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (u = this.tokenizer.autolink(e)) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      if (!this.state.inLink && (u = this.tokenizer.url(e))) {
        e = e.substring(u.raw.length), t.push(u);
        continue;
      }
      let p = e;
      if ((l = this.options.extensions) != null && l.startInline) {
        let h = 1 / 0;
        const d = e.slice(1);
        let g;
        this.options.extensions.startInline.forEach((m) => {
          g = m.call({ lexer: this }, d), typeof g == "number" && g >= 0 && (h = Math.min(h, g));
        }), h < 1 / 0 && h >= 0 && (p = e.substring(0, h + 1));
      }
      if (u = this.tokenizer.inlineText(p)) {
        e = e.substring(u.raw.length), u.raw.slice(-1) !== "_" && (o = u.raw.slice(-1)), r = !0;
        const h = t.at(-1);
        (h == null ? void 0 : h.type) === "text" ? (h.raw += u.raw, h.text += u.text) : t.push(u);
        continue;
      }
      if (e) {
        const h = "Infinite loop on byte: " + e.charCodeAt(0);
        if (this.options.silent) {
          console.error(h);
          break;
        } else
          throw new Error(h);
      }
    }
    return t;
  }
}, cs = class {
  // set by the parser
  constructor(s) {
    N(this, "options");
    N(this, "parser");
    this.options = s || He;
  }
  space(s) {
    return "";
  }
  code({ text: s, lang: e, escaped: t }) {
    var r;
    const n = (r = (e || "").match(ne.notSpaceStart)) == null ? void 0 : r[0], i = s.replace(ne.endingNewline, "") + `
`;
    return n ? '<pre><code class="language-' + ke(n) + '">' + (t ? i : ke(i, !0)) + `</code></pre>
` : "<pre><code>" + (t ? i : ke(i, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: s }) {
    return `<blockquote>
${this.parser.parse(s)}</blockquote>
`;
  }
  html({ text: s }) {
    return s;
  }
  heading({ tokens: s, depth: e }) {
    return `<h${e}>${this.parser.parseInline(s)}</h${e}>
`;
  }
  hr(s) {
    return `<hr>
`;
  }
  list(s) {
    const e = s.ordered, t = s.start;
    let n = "";
    for (let o = 0; o < s.items.length; o++) {
      const a = s.items[o];
      n += this.listitem(a);
    }
    const i = e ? "ol" : "ul", r = e && t !== 1 ? ' start="' + t + '"' : "";
    return "<" + i + r + `>
` + n + "</" + i + `>
`;
  }
  listitem(s) {
    var t;
    let e = "";
    if (s.task) {
      const n = this.checkbox({ checked: !!s.checked });
      s.loose ? ((t = s.tokens[0]) == null ? void 0 : t.type) === "paragraph" ? (s.tokens[0].text = n + " " + s.tokens[0].text, s.tokens[0].tokens && s.tokens[0].tokens.length > 0 && s.tokens[0].tokens[0].type === "text" && (s.tokens[0].tokens[0].text = n + " " + ke(s.tokens[0].tokens[0].text), s.tokens[0].tokens[0].escaped = !0)) : s.tokens.unshift({
        type: "text",
        raw: n + " ",
        text: n + " ",
        escaped: !0
      }) : e += n + " ";
    }
    return e += this.parser.parse(s.tokens, !!s.loose), `<li>${e}</li>
`;
  }
  checkbox({ checked: s }) {
    return "<input " + (s ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: s }) {
    return `<p>${this.parser.parseInline(s)}</p>
`;
  }
  table(s) {
    let e = "", t = "";
    for (let i = 0; i < s.header.length; i++)
      t += this.tablecell(s.header[i]);
    e += this.tablerow({ text: t });
    let n = "";
    for (let i = 0; i < s.rows.length; i++) {
      const r = s.rows[i];
      t = "";
      for (let o = 0; o < r.length; o++)
        t += this.tablecell(r[o]);
      n += this.tablerow({ text: t });
    }
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + n + `</table>
`;
  }
  tablerow({ text: s }) {
    return `<tr>
${s}</tr>
`;
  }
  tablecell(s) {
    const e = this.parser.parseInline(s.tokens), t = s.header ? "th" : "td";
    return (s.align ? `<${t} align="${s.align}">` : `<${t}>`) + e + `</${t}>
`;
  }
  /**
   * span level renderer
   */
  strong({ tokens: s }) {
    return `<strong>${this.parser.parseInline(s)}</strong>`;
  }
  em({ tokens: s }) {
    return `<em>${this.parser.parseInline(s)}</em>`;
  }
  codespan({ text: s }) {
    return `<code>${ke(s, !0)}</code>`;
  }
  br(s) {
    return "<br>";
  }
  del({ tokens: s }) {
    return `<del>${this.parser.parseInline(s)}</del>`;
  }
  link({ href: s, title: e, tokens: t }) {
    const n = this.parser.parseInline(t), i = vi(s);
    if (i === null)
      return n;
    s = i;
    let r = '<a href="' + s + '"';
    return e && (r += ' title="' + ke(e) + '"'), r += ">" + n + "</a>", r;
  }
  image({ href: s, title: e, text: t, tokens: n }) {
    n && (t = this.parser.parseInline(n, this.parser.textRenderer));
    const i = vi(s);
    if (i === null)
      return ke(t);
    s = i;
    let r = `<img src="${s}" alt="${t}"`;
    return e && (r += ` title="${ke(e)}"`), r += ">", r;
  }
  text(s) {
    return "tokens" in s && s.tokens ? this.parser.parseInline(s.tokens) : "escaped" in s && s.escaped ? s.text : ke(s.text);
  }
}, In = class {
  // no need for block level renderers
  strong({ text: s }) {
    return s;
  }
  em({ text: s }) {
    return s;
  }
  codespan({ text: s }) {
    return s;
  }
  del({ text: s }) {
    return s;
  }
  html({ text: s }) {
    return s;
  }
  text({ text: s }) {
    return s;
  }
  link({ text: s }) {
    return "" + s;
  }
  image({ text: s }) {
    return "" + s;
  }
  br() {
    return "";
  }
}, Ie = class cn {
  constructor(e) {
    N(this, "options");
    N(this, "renderer");
    N(this, "textRenderer");
    this.options = e || He, this.options.renderer = this.options.renderer || new cs(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new In();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new cn(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new cn(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    var i, r;
    let n = "";
    for (let o = 0; o < e.length; o++) {
      const a = e[o];
      if ((r = (i = this.options.extensions) == null ? void 0 : i.renderers) != null && r[a.type]) {
        const l = a, u = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (u !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += u || "";
          continue;
        }
      }
      const c = a;
      switch (c.type) {
        case "space": {
          n += this.renderer.space(c);
          continue;
        }
        case "hr": {
          n += this.renderer.hr(c);
          continue;
        }
        case "heading": {
          n += this.renderer.heading(c);
          continue;
        }
        case "code": {
          n += this.renderer.code(c);
          continue;
        }
        case "table": {
          n += this.renderer.table(c);
          continue;
        }
        case "blockquote": {
          n += this.renderer.blockquote(c);
          continue;
        }
        case "list": {
          n += this.renderer.list(c);
          continue;
        }
        case "html": {
          n += this.renderer.html(c);
          continue;
        }
        case "paragraph": {
          n += this.renderer.paragraph(c);
          continue;
        }
        case "text": {
          let l = c, u = this.renderer.text(l);
          for (; o + 1 < e.length && e[o + 1].type === "text"; )
            l = e[++o], u += `
` + this.renderer.text(l);
          t ? n += this.renderer.paragraph({
            type: "paragraph",
            raw: u,
            text: u,
            tokens: [{ type: "text", raw: u, text: u, escaped: !0 }]
          }) : n += u;
          continue;
        }
        default: {
          const l = 'Token with "' + c.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t = this.renderer) {
    var i, r;
    let n = "";
    for (let o = 0; o < e.length; o++) {
      const a = e[o];
      if ((r = (i = this.options.extensions) == null ? void 0 : i.renderers) != null && r[a.type]) {
        const l = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += l || "";
          continue;
        }
      }
      const c = a;
      switch (c.type) {
        case "escape": {
          n += t.text(c);
          break;
        }
        case "html": {
          n += t.html(c);
          break;
        }
        case "link": {
          n += t.link(c);
          break;
        }
        case "image": {
          n += t.image(c);
          break;
        }
        case "strong": {
          n += t.strong(c);
          break;
        }
        case "em": {
          n += t.em(c);
          break;
        }
        case "codespan": {
          n += t.codespan(c);
          break;
        }
        case "br": {
          n += t.br(c);
          break;
        }
        case "del": {
          n += t.del(c);
          break;
        }
        case "text": {
          n += t.text(c);
          break;
        }
        default: {
          const l = 'Token with "' + c.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}, nn, ns = (nn = class {
  constructor(s) {
    N(this, "options");
    N(this, "block");
    this.options = s || He;
  }
  /**
   * Process markdown before marked
   */
  preprocess(s) {
    return s;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(s) {
    return s;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(s) {
    return s;
  }
  /**
   * Provide function to tokenize markdown
   */
  provideLexer() {
    return this.block ? Le.lex : Le.lexInline;
  }
  /**
   * Provide function to parse tokens
   */
  provideParser() {
    return this.block ? Ie.parse : Ie.parseInline;
  }
}, N(nn, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
])), nn), Ja = class {
  constructor(...s) {
    N(this, "defaults", wn());
    N(this, "options", this.setOptions);
    N(this, "parse", this.parseMarkdown(!0));
    N(this, "parseInline", this.parseMarkdown(!1));
    N(this, "Parser", Ie);
    N(this, "Renderer", cs);
    N(this, "TextRenderer", In);
    N(this, "Lexer", Le);
    N(this, "Tokenizer", ls);
    N(this, "Hooks", ns);
    this.use(...s);
  }
  /**
   * Run callback for every token
   */
  walkTokens(s, e) {
    var n, i;
    let t = [];
    for (const r of s)
      switch (t = t.concat(e.call(this, r)), r.type) {
        case "table": {
          const o = r;
          for (const a of o.header)
            t = t.concat(this.walkTokens(a.tokens, e));
          for (const a of o.rows)
            for (const c of a)
              t = t.concat(this.walkTokens(c.tokens, e));
          break;
        }
        case "list": {
          const o = r;
          t = t.concat(this.walkTokens(o.items, e));
          break;
        }
        default: {
          const o = r;
          (i = (n = this.defaults.extensions) == null ? void 0 : n.childTokens) != null && i[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((a) => {
            const c = o[a].flat(1 / 0);
            t = t.concat(this.walkTokens(c, e));
          }) : o.tokens && (t = t.concat(this.walkTokens(o.tokens, e)));
        }
      }
    return t;
  }
  use(...s) {
    const e = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return s.forEach((t) => {
      const n = { ...t };
      if (n.async = this.defaults.async || n.async || !1, t.extensions && (t.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const r = e.renderers[i.name];
          r ? e.renderers[i.name] = function(...o) {
            let a = i.renderer.apply(this, o);
            return a === !1 && (a = r.apply(this, o)), a;
          } : e.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const r = e[i.level];
          r ? r.unshift(i.tokenizer) : e[i.level] = [i.tokenizer], i.start && (i.level === "block" ? e.startBlock ? e.startBlock.push(i.start) : e.startBlock = [i.start] : i.level === "inline" && (e.startInline ? e.startInline.push(i.start) : e.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (e.childTokens[i.name] = i.childTokens);
      }), n.extensions = e), t.renderer) {
        const i = this.defaults.renderer || new cs(this.defaults);
        for (const r in t.renderer) {
          if (!(r in i))
            throw new Error(`renderer '${r}' does not exist`);
          if (["options", "parser"].includes(r))
            continue;
          const o = r, a = t.renderer[o], c = i[o];
          i[o] = (...l) => {
            let u = a.apply(i, l);
            return u === !1 && (u = c.apply(i, l)), u || "";
          };
        }
        n.renderer = i;
      }
      if (t.tokenizer) {
        const i = this.defaults.tokenizer || new ls(this.defaults);
        for (const r in t.tokenizer) {
          if (!(r in i))
            throw new Error(`tokenizer '${r}' does not exist`);
          if (["options", "rules", "lexer"].includes(r))
            continue;
          const o = r, a = t.tokenizer[o], c = i[o];
          i[o] = (...l) => {
            let u = a.apply(i, l);
            return u === !1 && (u = c.apply(i, l)), u;
          };
        }
        n.tokenizer = i;
      }
      if (t.hooks) {
        const i = this.defaults.hooks || new ns();
        for (const r in t.hooks) {
          if (!(r in i))
            throw new Error(`hook '${r}' does not exist`);
          if (["options", "block"].includes(r))
            continue;
          const o = r, a = t.hooks[o], c = i[o];
          ns.passThroughHooks.has(r) ? i[o] = (l) => {
            if (this.defaults.async)
              return Promise.resolve(a.call(i, l)).then((p) => c.call(i, p));
            const u = a.call(i, l);
            return c.call(i, u);
          } : i[o] = (...l) => {
            let u = a.apply(i, l);
            return u === !1 && (u = c.apply(i, l)), u;
          };
        }
        n.hooks = i;
      }
      if (t.walkTokens) {
        const i = this.defaults.walkTokens, r = t.walkTokens;
        n.walkTokens = function(o) {
          let a = [];
          return a.push(r.call(this, o)), i && (a = a.concat(i.call(this, o))), a;
        };
      }
      this.defaults = { ...this.defaults, ...n };
    }), this;
  }
  setOptions(s) {
    return this.defaults = { ...this.defaults, ...s }, this;
  }
  lexer(s, e) {
    return Le.lex(s, e ?? this.defaults);
  }
  parser(s, e) {
    return Ie.parse(s, e ?? this.defaults);
  }
  parseMarkdown(s) {
    return (t, n) => {
      const i = { ...n }, r = { ...this.defaults, ...i }, o = this.onError(!!r.silent, !!r.async);
      if (this.defaults.async === !0 && i.async === !1)
        return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof t > "u" || t === null)
        return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof t != "string")
        return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(t) + ", string expected"));
      r.hooks && (r.hooks.options = r, r.hooks.block = s);
      const a = r.hooks ? r.hooks.provideLexer() : s ? Le.lex : Le.lexInline, c = r.hooks ? r.hooks.provideParser() : s ? Ie.parse : Ie.parseInline;
      if (r.async)
        return Promise.resolve(r.hooks ? r.hooks.preprocess(t) : t).then((l) => a(l, r)).then((l) => r.hooks ? r.hooks.processAllTokens(l) : l).then((l) => r.walkTokens ? Promise.all(this.walkTokens(l, r.walkTokens)).then(() => l) : l).then((l) => c(l, r)).then((l) => r.hooks ? r.hooks.postprocess(l) : l).catch(o);
      try {
        r.hooks && (t = r.hooks.preprocess(t));
        let l = a(t, r);
        r.hooks && (l = r.hooks.processAllTokens(l)), r.walkTokens && this.walkTokens(l, r.walkTokens);
        let u = c(l, r);
        return r.hooks && (u = r.hooks.postprocess(u)), u;
      } catch (l) {
        return o(l);
      }
    };
  }
  onError(s, e) {
    return (t) => {
      if (t.message += `
Please report this to https://github.com/markedjs/marked.`, s) {
        const n = "<p>An error occurred:</p><pre>" + ke(t.message + "", !0) + "</pre>";
        return e ? Promise.resolve(n) : n;
      }
      if (e)
        return Promise.reject(t);
      throw t;
    };
  }
}, Ke = new Ja();
function $(s, e) {
  return Ke.parse(s, e);
}
$.options = $.setOptions = function(s) {
  return Ke.setOptions(s), $.defaults = Ke.defaults, cr($.defaults), $;
};
$.getDefaults = wn;
$.defaults = He;
$.use = function(...s) {
  return Ke.use(...s), $.defaults = Ke.defaults, cr($.defaults), $;
};
$.walkTokens = function(s, e) {
  return Ke.walkTokens(s, e);
};
$.parseInline = Ke.parseInline;
$.Parser = Ie;
$.parser = Ie.parse;
$.Renderer = cs;
$.TextRenderer = In;
$.Lexer = Le;
$.lexer = Le.lex;
$.Tokenizer = ls;
$.Hooks = ns;
$.parse = $;
$.options;
$.setOptions;
$.use;
$.walkTokens;
$.parseInline;
Ie.parse;
Le.lex;
$.setOptions({ gfm: !0, breaks: !0 });
async function Xa(s, e, t) {
  const n = await fetch(bn(e, t));
  if (!n.ok) throw new Error(`Failed to load lesson: ${t}`);
  const i = await n.text(), r = await $.parse(i);
  s.innerHTML = `<article class="lxpack-markdown">${ha(String(r))}</article>`;
}
function Qa(s, e, t) {
  const n = De(bn(e, `${t}/index.html`));
  s.innerHTML = `
    <iframe
      class="lxpack-interaction-frame"
      src="${n}"
      title="Interaction"
      sandbox="allow-scripts allow-same-origin allow-forms"
    ></iframe>
  `;
}
const Nn = Symbol.for("yaml.alias"), un = Symbol.for("yaml.document"), Me = Symbol.for("yaml.map"), kr = Symbol.for("yaml.pair"), Ae = Symbol.for("yaml.scalar"), pt = Symbol.for("yaml.seq"), de = Symbol.for("yaml.node.type"), dt = (s) => !!s && typeof s == "object" && s[de] === Nn, bs = (s) => !!s && typeof s == "object" && s[de] === un, Mt = (s) => !!s && typeof s == "object" && s[de] === Me, G = (s) => !!s && typeof s == "object" && s[de] === kr, D = (s) => !!s && typeof s == "object" && s[de] === Ae, Bt = (s) => !!s && typeof s == "object" && s[de] === pt;
function q(s) {
  if (s && typeof s == "object")
    switch (s[de]) {
      case Me:
      case pt:
        return !0;
    }
  return !1;
}
function K(s) {
  if (s && typeof s == "object")
    switch (s[de]) {
      case Nn:
      case Me:
      case Ae:
      case pt:
        return !0;
    }
  return !1;
}
const Sr = (s) => (D(s) || q(s)) && !!s.anchor, Ue = Symbol("break visit"), Za = Symbol("skip children"), xt = Symbol("remove node");
function mt(s, e) {
  const t = el(e);
  bs(s) ? ot(null, s.contents, t, Object.freeze([s])) === xt && (s.contents = null) : ot(null, s, t, Object.freeze([]));
}
mt.BREAK = Ue;
mt.SKIP = Za;
mt.REMOVE = xt;
function ot(s, e, t, n) {
  const i = tl(s, e, t, n);
  if (K(i) || G(i))
    return sl(s, n, i), ot(s, i, t, n);
  if (typeof i != "symbol") {
    if (q(e)) {
      n = Object.freeze(n.concat(e));
      for (let r = 0; r < e.items.length; ++r) {
        const o = ot(r, e.items[r], t, n);
        if (typeof o == "number")
          r = o - 1;
        else {
          if (o === Ue)
            return Ue;
          o === xt && (e.items.splice(r, 1), r -= 1);
        }
      }
    } else if (G(e)) {
      n = Object.freeze(n.concat(e));
      const r = ot("key", e.key, t, n);
      if (r === Ue)
        return Ue;
      r === xt && (e.key = null);
      const o = ot("value", e.value, t, n);
      if (o === Ue)
        return Ue;
      o === xt && (e.value = null);
    }
  }
  return i;
}
function el(s) {
  return typeof s == "object" && (s.Collection || s.Node || s.Value) ? Object.assign({
    Alias: s.Node,
    Map: s.Node,
    Scalar: s.Node,
    Seq: s.Node
  }, s.Value && {
    Map: s.Value,
    Scalar: s.Value,
    Seq: s.Value
  }, s.Collection && {
    Map: s.Collection,
    Seq: s.Collection
  }, s) : s;
}
function tl(s, e, t, n) {
  var i, r, o, a, c;
  if (typeof t == "function")
    return t(s, e, n);
  if (Mt(e))
    return (i = t.Map) == null ? void 0 : i.call(t, s, e, n);
  if (Bt(e))
    return (r = t.Seq) == null ? void 0 : r.call(t, s, e, n);
  if (G(e))
    return (o = t.Pair) == null ? void 0 : o.call(t, s, e, n);
  if (D(e))
    return (a = t.Scalar) == null ? void 0 : a.call(t, s, e, n);
  if (dt(e))
    return (c = t.Alias) == null ? void 0 : c.call(t, s, e, n);
}
function sl(s, e, t) {
  const n = e[e.length - 1];
  if (q(n))
    n.items[s] = t;
  else if (G(n))
    s === "key" ? n.key = t : n.value = t;
  else if (bs(n))
    n.contents = t;
  else {
    const i = dt(n) ? "alias" : "scalar";
    throw new Error(`Cannot replace node with ${i} parent`);
  }
}
const nl = {
  "!": "%21",
  ",": "%2C",
  "[": "%5B",
  "]": "%5D",
  "{": "%7B",
  "}": "%7D"
}, il = (s) => s.replace(/[!,[\]{}]/g, (e) => nl[e]);
class se {
  constructor(e, t) {
    this.docStart = null, this.docEnd = !1, this.yaml = Object.assign({}, se.defaultYaml, e), this.tags = Object.assign({}, se.defaultTags, t);
  }
  clone() {
    const e = new se(this.yaml, this.tags);
    return e.docStart = this.docStart, e;
  }
  /**
   * During parsing, get a Directives instance for the current document and
   * update the stream state according to the current version's spec.
   */
  atDocument() {
    const e = new se(this.yaml, this.tags);
    switch (this.yaml.version) {
      case "1.1":
        this.atNextDocument = !0;
        break;
      case "1.2":
        this.atNextDocument = !1, this.yaml = {
          explicit: se.defaultYaml.explicit,
          version: "1.2"
        }, this.tags = Object.assign({}, se.defaultTags);
        break;
    }
    return e;
  }
  /**
   * @param onError - May be called even if the action was successful
   * @returns `true` on success
   */
  add(e, t) {
    this.atNextDocument && (this.yaml = { explicit: se.defaultYaml.explicit, version: "1.1" }, this.tags = Object.assign({}, se.defaultTags), this.atNextDocument = !1);
    const n = e.trim().split(/[ \t]+/), i = n.shift();
    switch (i) {
      case "%TAG": {
        if (n.length !== 2 && (t(0, "%TAG directive should contain exactly two parts"), n.length < 2))
          return !1;
        const [r, o] = n;
        return this.tags[r] = o, !0;
      }
      case "%YAML": {
        if (this.yaml.explicit = !0, n.length !== 1)
          return t(0, "%YAML directive should contain exactly one part"), !1;
        const [r] = n;
        if (r === "1.1" || r === "1.2")
          return this.yaml.version = r, !0;
        {
          const o = /^\d+\.\d+$/.test(r);
          return t(6, `Unsupported YAML version ${r}`, o), !1;
        }
      }
      default:
        return t(0, `Unknown directive ${i}`, !0), !1;
    }
  }
  /**
   * Resolves a tag, matching handles to those defined in %TAG directives.
   *
   * @returns Resolved tag, which may also be the non-specific tag `'!'` or a
   *   `'!local'` tag, or `null` if unresolvable.
   */
  tagName(e, t) {
    if (e === "!")
      return "!";
    if (e[0] !== "!")
      return t(`Not a valid tag: ${e}`), null;
    if (e[1] === "<") {
      const o = e.slice(2, -1);
      return o === "!" || o === "!!" ? (t(`Verbatim tags aren't resolved, so ${e} is invalid.`), null) : (e[e.length - 1] !== ">" && t("Verbatim tags must end with a >"), o);
    }
    const [, n, i] = e.match(/^(.*!)([^!]*)$/s);
    i || t(`The ${e} tag has no suffix`);
    const r = this.tags[n];
    if (r)
      try {
        return r + decodeURIComponent(i);
      } catch (o) {
        return t(String(o)), null;
      }
    return n === "!" ? e : (t(`Could not resolve tag: ${e}`), null);
  }
  /**
   * Given a fully resolved tag, returns its printable string form,
   * taking into account current tag prefixes and defaults.
   */
  tagString(e) {
    for (const [t, n] of Object.entries(this.tags))
      if (e.startsWith(n))
        return t + il(e.substring(n.length));
    return e[0] === "!" ? e : `!<${e}>`;
  }
  toString(e) {
    const t = this.yaml.explicit ? [`%YAML ${this.yaml.version || "1.2"}`] : [], n = Object.entries(this.tags);
    let i;
    if (e && n.length > 0 && K(e.contents)) {
      const r = {};
      mt(e.contents, (o, a) => {
        K(a) && a.tag && (r[a.tag] = !0);
      }), i = Object.keys(r);
    } else
      i = [];
    for (const [r, o] of n)
      r === "!!" && o === "tag:yaml.org,2002:" || (!e || i.some((a) => a.startsWith(o))) && t.push(`%TAG ${r} ${o}`);
    return t.join(`
`);
  }
}
se.defaultYaml = { explicit: !1, version: "1.2" };
se.defaultTags = { "!!": "tag:yaml.org,2002:" };
function Ar(s) {
  if (/[\x00-\x19\s,[\]{}]/.test(s)) {
    const t = `Anchor must not contain whitespace or control characters: ${JSON.stringify(s)}`;
    throw new Error(t);
  }
  return !0;
}
function Tr(s) {
  const e = /* @__PURE__ */ new Set();
  return mt(s, {
    Value(t, n) {
      n.anchor && e.add(n.anchor);
    }
  }), e;
}
function Er(s, e) {
  for (let t = 1; ; ++t) {
    const n = `${s}${t}`;
    if (!e.has(n))
      return n;
  }
}
function rl(s, e) {
  const t = [], n = /* @__PURE__ */ new Map();
  let i = null;
  return {
    onAnchor: (r) => {
      t.push(r), i ?? (i = Tr(s));
      const o = Er(e, i);
      return i.add(o), o;
    },
    /**
     * With circular references, the source node is only resolved after all
     * of its child nodes are. This is why anchors are set only after all of
     * the nodes have been created.
     */
    setAnchors: () => {
      for (const r of t) {
        const o = n.get(r);
        if (typeof o == "object" && o.anchor && (D(o.node) || q(o.node)))
          o.node.anchor = o.anchor;
        else {
          const a = new Error("Failed to resolve repeated object (this should not happen)");
          throw a.source = r, a;
        }
      }
    },
    sourceObjects: n
  };
}
function at(s, e, t, n) {
  if (n && typeof n == "object")
    if (Array.isArray(n))
      for (let i = 0, r = n.length; i < r; ++i) {
        const o = n[i], a = at(s, n, String(i), o);
        a === void 0 ? delete n[i] : a !== o && (n[i] = a);
      }
    else if (n instanceof Map)
      for (const i of Array.from(n.keys())) {
        const r = n.get(i), o = at(s, n, i, r);
        o === void 0 ? n.delete(i) : o !== r && n.set(i, o);
      }
    else if (n instanceof Set)
      for (const i of Array.from(n)) {
        const r = at(s, n, i, i);
        r === void 0 ? n.delete(i) : r !== i && (n.delete(i), n.add(r));
      }
    else
      for (const [i, r] of Object.entries(n)) {
        const o = at(s, n, i, r);
        o === void 0 ? delete n[i] : o !== r && (n[i] = o);
      }
  return s.call(e, t, n);
}
function he(s, e, t) {
  if (Array.isArray(s))
    return s.map((n, i) => he(n, String(i), t));
  if (s && typeof s.toJSON == "function") {
    if (!t || !Sr(s))
      return s.toJSON(e, t);
    const n = { aliasCount: 0, count: 1, res: void 0 };
    t.anchors.set(s, n), t.onCreate = (r) => {
      n.res = r, delete t.onCreate;
    };
    const i = s.toJSON(e, t);
    return t.onCreate && t.onCreate(i), i;
  }
  return typeof s == "bigint" && !(t != null && t.keep) ? Number(s) : s;
}
class On {
  constructor(e) {
    Object.defineProperty(this, de, { value: e });
  }
  /** Create a copy of this node.  */
  clone() {
    const e = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
    return this.range && (e.range = this.range.slice()), e;
  }
  /** A plain JavaScript representation of this node. */
  toJS(e, { mapAsMap: t, maxAliasCount: n, onAnchor: i, reviver: r } = {}) {
    if (!bs(e))
      throw new TypeError("A document argument is required");
    const o = {
      anchors: /* @__PURE__ */ new Map(),
      doc: e,
      keep: !0,
      mapAsMap: t === !0,
      mapKeyWarned: !1,
      maxAliasCount: typeof n == "number" ? n : 100
    }, a = he(this, "", o);
    if (typeof i == "function")
      for (const { count: c, res: l } of o.anchors.values())
        i(l, c);
    return typeof r == "function" ? at(r, { "": a }, "", a) : a;
  }
}
class vn extends On {
  constructor(e) {
    super(Nn), this.source = e, Object.defineProperty(this, "tag", {
      set() {
        throw new Error("Alias nodes cannot have tags");
      }
    });
  }
  /**
   * Resolve the value of this alias within `doc`, finding the last
   * instance of the `source` anchor before this node.
   */
  resolve(e, t) {
    if ((t == null ? void 0 : t.maxAliasCount) === 0)
      throw new ReferenceError("Alias resolution is disabled");
    let n;
    t != null && t.aliasResolveCache ? n = t.aliasResolveCache : (n = [], mt(e, {
      Node: (r, o) => {
        (dt(o) || Sr(o)) && n.push(o);
      }
    }), t && (t.aliasResolveCache = n));
    let i;
    for (const r of n) {
      if (r === this)
        break;
      r.anchor === this.source && (i = r);
    }
    return i;
  }
  toJSON(e, t) {
    if (!t)
      return { source: this.source };
    const { anchors: n, doc: i, maxAliasCount: r } = t, o = this.resolve(i, t);
    if (!o) {
      const c = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
      throw new ReferenceError(c);
    }
    let a = n.get(o);
    if (a || (he(o, null, t), a = n.get(o)), (a == null ? void 0 : a.res) === void 0) {
      const c = "This should not happen: Alias anchor was not resolved?";
      throw new ReferenceError(c);
    }
    if (r >= 0 && (a.count += 1, a.aliasCount === 0 && (a.aliasCount = is(i, o, n)), a.count * a.aliasCount > r)) {
      const c = "Excessive alias count indicates a resource exhaustion attack";
      throw new ReferenceError(c);
    }
    return a.res;
  }
  toString(e, t, n) {
    const i = `*${this.source}`;
    if (e) {
      if (Ar(this.source), e.options.verifyAliasOrder && !e.anchors.has(this.source)) {
        const r = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
        throw new Error(r);
      }
      if (e.implicitKey)
        return `${i} `;
    }
    return i;
  }
}
function is(s, e, t) {
  if (dt(e)) {
    const n = e.resolve(s), i = t && n && t.get(n);
    return i ? i.count * i.aliasCount : 0;
  } else if (q(e)) {
    let n = 0;
    for (const i of e.items) {
      const r = is(s, i, t);
      r > n && (n = r);
    }
    return n;
  } else if (G(e)) {
    const n = is(s, e.key, t), i = is(s, e.value, t);
    return Math.max(n, i);
  }
  return 1;
}
const _r = (s) => !s || typeof s != "function" && typeof s != "object";
class v extends On {
  constructor(e) {
    super(Ae), this.value = e;
  }
  toJSON(e, t) {
    return t != null && t.keep ? this.value : he(this.value, e, t);
  }
  toString() {
    return String(this.value);
  }
}
v.BLOCK_FOLDED = "BLOCK_FOLDED";
v.BLOCK_LITERAL = "BLOCK_LITERAL";
v.PLAIN = "PLAIN";
v.QUOTE_DOUBLE = "QUOTE_DOUBLE";
v.QUOTE_SINGLE = "QUOTE_SINGLE";
const ol = "tag:yaml.org,2002:";
function al(s, e, t) {
  if (e) {
    const n = t.filter((r) => r.tag === e), i = n.find((r) => !r.format) ?? n[0];
    if (!i)
      throw new Error(`Tag ${e} not found`);
    return i;
  }
  return t.find((n) => {
    var i;
    return ((i = n.identify) == null ? void 0 : i.call(n, s)) && !n.format;
  });
}
function Rt(s, e, t) {
  var p, h, d;
  if (bs(s) && (s = s.contents), K(s))
    return s;
  if (G(s)) {
    const g = (h = (p = t.schema[Me]).createNode) == null ? void 0 : h.call(p, t.schema, null, t);
    return g.items.push(s), g;
  }
  (s instanceof String || s instanceof Number || s instanceof Boolean || typeof BigInt < "u" && s instanceof BigInt) && (s = s.valueOf());
  const { aliasDuplicateObjects: n, onAnchor: i, onTagObj: r, schema: o, sourceObjects: a } = t;
  let c;
  if (n && s && typeof s == "object") {
    if (c = a.get(s), c)
      return c.anchor ?? (c.anchor = i(s)), new vn(c.anchor);
    c = { anchor: null, node: null }, a.set(s, c);
  }
  e != null && e.startsWith("!!") && (e = ol + e.slice(2));
  let l = al(s, e, o.tags);
  if (!l) {
    if (s && typeof s.toJSON == "function" && (s = s.toJSON()), !s || typeof s != "object") {
      const g = new v(s);
      return c && (c.node = g), g;
    }
    l = s instanceof Map ? o[Me] : Symbol.iterator in Object(s) ? o[pt] : o[Me];
  }
  r && (r(l), delete t.onTagObj);
  const u = l != null && l.createNode ? l.createNode(t.schema, s, t) : typeof ((d = l == null ? void 0 : l.nodeClass) == null ? void 0 : d.from) == "function" ? l.nodeClass.from(t.schema, s, t) : new v(s);
  return e ? u.tag = e : l.default || (u.tag = l.tag), c && (c.node = u), u;
}
function us(s, e, t) {
  let n = t;
  for (let i = e.length - 1; i >= 0; --i) {
    const r = e[i];
    if (typeof r == "number" && Number.isInteger(r) && r >= 0) {
      const o = [];
      o[r] = n, n = o;
    } else
      n = /* @__PURE__ */ new Map([[r, n]]);
  }
  return Rt(n, void 0, {
    aliasDuplicateObjects: !1,
    keepUndefined: !1,
    onAnchor: () => {
      throw new Error("This should not happen, please report a bug.");
    },
    schema: s,
    sourceObjects: /* @__PURE__ */ new Map()
  });
}
const Nt = (s) => s == null || typeof s == "object" && !!s[Symbol.iterator]().next().done;
class Lr extends On {
  constructor(e, t) {
    super(e), Object.defineProperty(this, "schema", {
      value: t,
      configurable: !0,
      enumerable: !1,
      writable: !0
    });
  }
  /**
   * Create a copy of this collection.
   *
   * @param schema - If defined, overwrites the original's schema
   */
  clone(e) {
    const t = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
    return e && (t.schema = e), t.items = t.items.map((n) => K(n) || G(n) ? n.clone(e) : n), this.range && (t.range = this.range.slice()), t;
  }
  /**
   * Adds a value to the collection. For `!!map` and `!!omap` the value must
   * be a Pair instance or a `{ key, value }` object, which may not have a key
   * that already exists in the map.
   */
  addIn(e, t) {
    if (Nt(e))
      this.add(t);
    else {
      const [n, ...i] = e, r = this.get(n, !0);
      if (q(r))
        r.addIn(i, t);
      else if (r === void 0 && this.schema)
        this.set(n, us(this.schema, i, t));
      else
        throw new Error(`Expected YAML collection at ${n}. Remaining path: ${i}`);
    }
  }
  /**
   * Removes a value from the collection.
   * @returns `true` if the item was found and removed.
   */
  deleteIn(e) {
    const [t, ...n] = e;
    if (n.length === 0)
      return this.delete(t);
    const i = this.get(t, !0);
    if (q(i))
      return i.deleteIn(n);
    throw new Error(`Expected YAML collection at ${t}. Remaining path: ${n}`);
  }
  /**
   * Returns item at `key`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  getIn(e, t) {
    const [n, ...i] = e, r = this.get(n, !0);
    return i.length === 0 ? !t && D(r) ? r.value : r : q(r) ? r.getIn(i, t) : void 0;
  }
  hasAllNullValues(e) {
    return this.items.every((t) => {
      if (!G(t))
        return !1;
      const n = t.value;
      return n == null || e && D(n) && n.value == null && !n.commentBefore && !n.comment && !n.tag;
    });
  }
  /**
   * Checks if the collection includes a value with the key `key`.
   */
  hasIn(e) {
    const [t, ...n] = e;
    if (n.length === 0)
      return this.has(t);
    const i = this.get(t, !0);
    return q(i) ? i.hasIn(n) : !1;
  }
  /**
   * Sets a value in this collection. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  setIn(e, t) {
    const [n, ...i] = e;
    if (i.length === 0)
      this.set(n, t);
    else {
      const r = this.get(n, !0);
      if (q(r))
        r.setIn(i, t);
      else if (r === void 0 && this.schema)
        this.set(n, us(this.schema, i, t));
      else
        throw new Error(`Expected YAML collection at ${n}. Remaining path: ${i}`);
    }
  }
}
const ll = (s) => s.replace(/^(?!$)(?: $)?/gm, "#");
function Ne(s, e) {
  return /^\n+$/.test(s) ? s.substring(1) : e ? s.replace(/^(?! *$)/gm, e) : s;
}
const ze = (s, e, t) => s.endsWith(`
`) ? Ne(t, e) : t.includes(`
`) ? `
` + Ne(t, e) : (s.endsWith(" ") ? "" : " ") + t, Ir = "flow", fn = "block", rs = "quoted";
function ws(s, e, t = "flow", { indentAtStart: n, lineWidth: i = 80, minContentWidth: r = 20, onFold: o, onOverflow: a } = {}) {
  if (!i || i < 0)
    return s;
  i < r && (r = 0);
  const c = Math.max(1 + r, 1 + i - e.length);
  if (s.length <= c)
    return s;
  const l = [], u = {};
  let p = i - e.length;
  typeof n == "number" && (n > i - Math.max(2, r) ? l.push(0) : p = i - n);
  let h, d, g = !1, m = -1, y = -1, A = -1;
  t === fn && (m = Ri(s, m, e.length), m !== -1 && (p = m + c));
  for (let L; L = s[m += 1]; ) {
    if (t === rs && L === "\\") {
      switch (y = m, s[m + 1]) {
        case "x":
          m += 3;
          break;
        case "u":
          m += 5;
          break;
        case "U":
          m += 9;
          break;
        default:
          m += 1;
      }
      A = m;
    }
    if (L === `
`)
      t === fn && (m = Ri(s, m, e.length)), p = m + e.length + c, h = void 0;
    else {
      if (L === " " && d && d !== " " && d !== `
` && d !== "	") {
        const I = s[m + 1];
        I && I !== " " && I !== `
` && I !== "	" && (h = m);
      }
      if (m >= p)
        if (h)
          l.push(h), p = h + c, h = void 0;
        else if (t === rs) {
          for (; d === " " || d === "	"; )
            d = L, L = s[m += 1], g = !0;
          const I = m > A + 1 ? m - 2 : y - 1;
          if (u[I])
            return s;
          l.push(I), u[I] = !0, p = I + c, h = void 0;
        } else
          g = !0;
    }
    d = L;
  }
  if (g && a && a(), l.length === 0)
    return s;
  o && o();
  let k = s.slice(0, l[0]);
  for (let L = 0; L < l.length; ++L) {
    const I = l[L], w = l[L + 1] || s.length;
    I === 0 ? k = `
${e}${s.slice(0, w)}` : (t === rs && u[I] && (k += `${s[I]}\\`), k += `
${e}${s.slice(I + 1, w)}`);
  }
  return k;
}
function Ri(s, e, t) {
  let n = e, i = e + 1, r = s[i];
  for (; r === " " || r === "	"; )
    if (e < i + t)
      r = s[++e];
    else {
      do
        r = s[++e];
      while (r && r !== `
`);
      n = e, i = e + 1, r = s[i];
    }
  return n;
}
const ks = (s, e) => ({
  indentAtStart: e ? s.indent.length : s.indentAtStart,
  lineWidth: s.options.lineWidth,
  minContentWidth: s.options.minContentWidth
}), Ss = (s) => /^(%|---|\.\.\.)/m.test(s);
function cl(s, e, t) {
  if (!e || e < 0)
    return !1;
  const n = e - t, i = s.length;
  if (i <= n)
    return !1;
  for (let r = 0, o = 0; r < i; ++r)
    if (s[r] === `
`) {
      if (r - o > n)
        return !0;
      if (o = r + 1, i - o <= n)
        return !1;
    }
  return !0;
}
function Ct(s, e) {
  const t = JSON.stringify(s);
  if (e.options.doubleQuotedAsJSON)
    return t;
  const { implicitKey: n } = e, i = e.options.doubleQuotedMinMultiLineLength, r = e.indent || (Ss(s) ? "  " : "");
  let o = "", a = 0;
  for (let c = 0, l = t[c]; l; l = t[++c])
    if (l === " " && t[c + 1] === "\\" && t[c + 2] === "n" && (o += t.slice(a, c) + "\\ ", c += 1, a = c, l = "\\"), l === "\\")
      switch (t[c + 1]) {
        case "u":
          {
            o += t.slice(a, c);
            const u = t.substr(c + 2, 4);
            switch (u) {
              case "0000":
                o += "\\0";
                break;
              case "0007":
                o += "\\a";
                break;
              case "000b":
                o += "\\v";
                break;
              case "001b":
                o += "\\e";
                break;
              case "0085":
                o += "\\N";
                break;
              case "00a0":
                o += "\\_";
                break;
              case "2028":
                o += "\\L";
                break;
              case "2029":
                o += "\\P";
                break;
              default:
                u.substr(0, 2) === "00" ? o += "\\x" + u.substr(2) : o += t.substr(c, 6);
            }
            c += 5, a = c + 1;
          }
          break;
        case "n":
          if (n || t[c + 2] === '"' || t.length < i)
            c += 1;
          else {
            for (o += t.slice(a, c) + `

`; t[c + 2] === "\\" && t[c + 3] === "n" && t[c + 4] !== '"'; )
              o += `
`, c += 2;
            o += r, t[c + 2] === " " && (o += "\\"), c += 1, a = c + 1;
          }
          break;
        default:
          c += 1;
      }
  return o = a ? o + t.slice(a) : t, n ? o : ws(o, r, rs, ks(e, !1));
}
function hn(s, e) {
  if (e.options.singleQuote === !1 || e.implicitKey && s.includes(`
`) || /[ \t]\n|\n[ \t]/.test(s))
    return Ct(s, e);
  const t = e.indent || (Ss(s) ? "  " : ""), n = "'" + s.replace(/'/g, "''").replace(/\n+/g, `$&
${t}`) + "'";
  return e.implicitKey ? n : ws(n, t, Ir, ks(e, !1));
}
function lt(s, e) {
  const { singleQuote: t } = e.options;
  let n;
  if (t === !1)
    n = Ct;
  else {
    const i = s.includes('"'), r = s.includes("'");
    i && !r ? n = hn : r && !i ? n = Ct : n = t ? hn : Ct;
  }
  return n(s, e);
}
let pn;
try {
  pn = new RegExp(`(^|(?<!
))
+(?!
|$)`, "g");
} catch {
  pn = /\n+(?!\n|$)/g;
}
function os({ comment: s, type: e, value: t }, n, i, r) {
  const { blockQuote: o, commentString: a, lineWidth: c } = n.options;
  if (!o || /\n[\t ]+$/.test(t))
    return lt(t, n);
  const l = n.indent || (n.forceBlockIndent || Ss(t) ? "  " : ""), u = o === "literal" ? !0 : o === "folded" || e === v.BLOCK_FOLDED ? !1 : e === v.BLOCK_LITERAL ? !0 : !cl(t, c, l.length);
  if (!t)
    return u ? `|
` : `>
`;
  let p, h;
  for (h = t.length; h > 0; --h) {
    const w = t[h - 1];
    if (w !== `
` && w !== "	" && w !== " ")
      break;
  }
  let d = t.substring(h);
  const g = d.indexOf(`
`);
  g === -1 ? p = "-" : t === d || g !== d.length - 1 ? (p = "+", r && r()) : p = "", d && (t = t.slice(0, -d.length), d[d.length - 1] === `
` && (d = d.slice(0, -1)), d = d.replace(pn, `$&${l}`));
  let m = !1, y, A = -1;
  for (y = 0; y < t.length; ++y) {
    const w = t[y];
    if (w === " ")
      m = !0;
    else if (w === `
`)
      A = y;
    else
      break;
  }
  let k = t.substring(0, A < y ? A + 1 : y);
  k && (t = t.substring(k.length), k = k.replace(/\n+/g, `$&${l}`));
  let I = (m ? l ? "2" : "1" : "") + p;
  if (s && (I += " " + a(s.replace(/ ?[\r\n]+/g, " ")), i && i()), !u) {
    const w = t.replace(/\n+/g, `
$&`).replace(/(?:^|\n)([\t ].*)(?:([\n\t ]*)\n(?![\n\t ]))?/g, "$1$2").replace(/\n+/g, `$&${l}`);
    let S = !1;
    const E = ks(n, !0);
    o !== "folded" && e !== v.BLOCK_FOLDED && (E.onOverflow = () => {
      S = !0;
    });
    const T = ws(`${k}${w}${d}`, l, fn, E);
    if (!S)
      return `>${I}
${l}${T}`;
  }
  return t = t.replace(/\n+/g, `$&${l}`), `|${I}
${l}${k}${t}${d}`;
}
function ul(s, e, t, n) {
  const { type: i, value: r } = s, { actualString: o, implicitKey: a, indent: c, indentStep: l, inFlow: u } = e;
  if (a && r.includes(`
`) || u && /[[\]{},]/.test(r))
    return lt(r, e);
  if (/^[\n\t ,[\]{}#&*!|>'"%@`]|^[?-]$|^[?-][ \t]|[\n:][ \t]|[ \t]\n|[\n\t ]#|[\n\t :]$/.test(r))
    return a || u || !r.includes(`
`) ? lt(r, e) : os(s, e, t, n);
  if (!a && !u && i !== v.PLAIN && r.includes(`
`))
    return os(s, e, t, n);
  if (Ss(r)) {
    if (c === "")
      return e.forceBlockIndent = !0, os(s, e, t, n);
    if (a && c === l)
      return lt(r, e);
  }
  const p = r.replace(/\n+/g, `$&
${c}`);
  if (o) {
    const h = (m) => {
      var y;
      return m.default && m.tag !== "tag:yaml.org,2002:str" && ((y = m.test) == null ? void 0 : y.test(p));
    }, { compat: d, tags: g } = e.doc.schema;
    if (g.some(h) || d != null && d.some(h))
      return lt(r, e);
  }
  return a ? p : ws(p, c, Ir, ks(e, !1));
}
function xn(s, e, t, n) {
  const { implicitKey: i, inFlow: r } = e, o = typeof s.value == "string" ? s : Object.assign({}, s, { value: String(s.value) });
  let { type: a } = s;
  a !== v.QUOTE_DOUBLE && /[\x00-\x08\x0b-\x1f\x7f-\x9f\u{D800}-\u{DFFF}]/u.test(o.value) && (a = v.QUOTE_DOUBLE);
  const c = (u) => {
    switch (u) {
      case v.BLOCK_FOLDED:
      case v.BLOCK_LITERAL:
        return i || r ? lt(o.value, e) : os(o, e, t, n);
      case v.QUOTE_DOUBLE:
        return Ct(o.value, e);
      case v.QUOTE_SINGLE:
        return hn(o.value, e);
      case v.PLAIN:
        return ul(o, e, t, n);
      default:
        return null;
    }
  };
  let l = c(a);
  if (l === null) {
    const { defaultKeyType: u, defaultStringType: p } = e.options, h = i && u || p;
    if (l = c(h), l === null)
      throw new Error(`Unsupported default string type ${h}`);
  }
  return l;
}
function Nr(s, e) {
  const t = Object.assign({
    blockQuote: !0,
    commentString: ll,
    defaultKeyType: null,
    defaultStringType: "PLAIN",
    directives: null,
    doubleQuotedAsJSON: !1,
    doubleQuotedMinMultiLineLength: 40,
    falseStr: "false",
    flowCollectionPadding: !0,
    indentSeq: !0,
    lineWidth: 80,
    minContentWidth: 20,
    nullStr: "null",
    simpleKeys: !1,
    singleQuote: null,
    trailingComma: !1,
    trueStr: "true",
    verifyAliasOrder: !0
  }, s.schema.toStringOptions, e);
  let n;
  switch (t.collectionStyle) {
    case "block":
      n = !1;
      break;
    case "flow":
      n = !0;
      break;
    default:
      n = null;
  }
  return {
    anchors: /* @__PURE__ */ new Set(),
    doc: s,
    flowCollectionPadding: t.flowCollectionPadding ? " " : "",
    indent: "",
    indentStep: typeof t.indent == "number" ? " ".repeat(t.indent) : "  ",
    inFlow: n,
    options: t
  };
}
function fl(s, e) {
  var i;
  if (e.tag) {
    const r = s.filter((o) => o.tag === e.tag);
    if (r.length > 0)
      return r.find((o) => o.format === e.format) ?? r[0];
  }
  let t, n;
  if (D(e)) {
    n = e.value;
    let r = s.filter((o) => {
      var a;
      return (a = o.identify) == null ? void 0 : a.call(o, n);
    });
    if (r.length > 1) {
      const o = r.filter((a) => a.test);
      o.length > 0 && (r = o);
    }
    t = r.find((o) => o.format === e.format) ?? r.find((o) => !o.format);
  } else
    n = e, t = s.find((r) => r.nodeClass && n instanceof r.nodeClass);
  if (!t) {
    const r = ((i = n == null ? void 0 : n.constructor) == null ? void 0 : i.name) ?? (n === null ? "null" : typeof n);
    throw new Error(`Tag not resolved for ${r} value`);
  }
  return t;
}
function hl(s, e, { anchors: t, doc: n }) {
  if (!n.directives)
    return "";
  const i = [], r = (D(s) || q(s)) && s.anchor;
  r && Ar(r) && (t.add(r), i.push(`&${r}`));
  const o = s.tag ?? (e.default ? null : e.tag);
  return o && i.push(n.directives.tagString(o)), i.join(" ");
}
function ft(s, e, t, n) {
  var c;
  if (G(s))
    return s.toString(e, t, n);
  if (dt(s)) {
    if (e.doc.directives)
      return s.toString(e);
    if ((c = e.resolvedAliases) != null && c.has(s))
      throw new TypeError("Cannot stringify circular structure without alias nodes");
    e.resolvedAliases ? e.resolvedAliases.add(s) : e.resolvedAliases = /* @__PURE__ */ new Set([s]), s = s.resolve(e.doc);
  }
  let i;
  const r = K(s) ? s : e.doc.createNode(s, { onTagObj: (l) => i = l });
  i ?? (i = fl(e.doc.schema.tags, r));
  const o = hl(r, i, e);
  o.length > 0 && (e.indentAtStart = (e.indentAtStart ?? 0) + o.length + 1);
  const a = typeof i.stringify == "function" ? i.stringify(r, e, t, n) : D(r) ? xn(r, e, t, n) : r.toString(e, t, n);
  return o ? D(r) || a[0] === "{" || a[0] === "[" ? `${o} ${a}` : `${o}
${e.indent}${a}` : a;
}
function pl({ key: s, value: e }, t, n, i) {
  const { allNullValues: r, doc: o, indent: a, indentStep: c, options: { commentString: l, indentSeq: u, simpleKeys: p } } = t;
  let h = K(s) && s.comment || null;
  if (p) {
    if (h)
      throw new Error("With simple keys, key nodes cannot have comments");
    if (q(s) || !K(s) && typeof s == "object") {
      const E = "With simple keys, collection cannot be used as a key value";
      throw new Error(E);
    }
  }
  let d = !p && (!s || h && e == null && !t.inFlow || q(s) || (D(s) ? s.type === v.BLOCK_FOLDED || s.type === v.BLOCK_LITERAL : typeof s == "object"));
  t = Object.assign({}, t, {
    allNullValues: !1,
    implicitKey: !d && (p || !r),
    indent: a + c
  });
  let g = !1, m = !1, y = ft(s, t, () => g = !0, () => m = !0);
  if (!d && !t.inFlow && y.length > 1024) {
    if (p)
      throw new Error("With simple keys, single line scalar must not span more than 1024 characters");
    d = !0;
  }
  if (t.inFlow) {
    if (r || e == null)
      return g && n && n(), y === "" ? "?" : d ? `? ${y}` : y;
  } else if (r && !p || e == null && d)
    return y = `? ${y}`, h && !g ? y += ze(y, t.indent, l(h)) : m && i && i(), y;
  g && (h = null), d ? (h && (y += ze(y, t.indent, l(h))), y = `? ${y}
${a}:`) : (y = `${y}:`, h && (y += ze(y, t.indent, l(h))));
  let A, k, L;
  K(e) ? (A = !!e.spaceBefore, k = e.commentBefore, L = e.comment) : (A = !1, k = null, L = null, e && typeof e == "object" && (e = o.createNode(e))), t.implicitKey = !1, !d && !h && D(e) && (t.indentAtStart = y.length + 1), m = !1, !u && c.length >= 2 && !t.inFlow && !d && Bt(e) && !e.flow && !e.tag && !e.anchor && (t.indent = t.indent.substring(2));
  let I = !1;
  const w = ft(e, t, () => I = !0, () => m = !0);
  let S = " ";
  if (h || A || k) {
    if (S = A ? `
` : "", k) {
      const E = l(k);
      S += `
${Ne(E, t.indent)}`;
    }
    w === "" && !t.inFlow ? S === `
` && L && (S = `

`) : S += `
${t.indent}`;
  } else if (!d && q(e)) {
    const E = w[0], T = w.indexOf(`
`), C = T !== -1, M = t.inFlow ?? e.flow ?? e.items.length === 0;
    if (C || !M) {
      let J = !1;
      if (C && (E === "&" || E === "!")) {
        let B = w.indexOf(" ");
        E === "&" && B !== -1 && B < T && w[B + 1] === "!" && (B = w.indexOf(" ", B + 1)), (B === -1 || T < B) && (J = !0);
      }
      J || (S = `
${t.indent}`);
    }
  } else (w === "" || w[0] === `
`) && (S = "");
  return y += S + w, t.inFlow ? I && n && n() : L && !I ? y += ze(y, t.indent, l(L)) : m && i && i(), y;
}
function Or(s, e) {
  (s === "debug" || s === "warn") && console.warn(e);
}
const Qt = "<<", Oe = {
  identify: (s) => s === Qt || typeof s == "symbol" && s.description === Qt,
  default: "key",
  tag: "tag:yaml.org,2002:merge",
  test: /^<<$/,
  resolve: () => Object.assign(new v(Symbol(Qt)), {
    addToJSMap: vr
  }),
  stringify: () => Qt
}, dl = (s, e) => (Oe.identify(e) || D(e) && (!e.type || e.type === v.PLAIN) && Oe.identify(e.value)) && (s == null ? void 0 : s.doc.schema.tags.some((t) => t.tag === Oe.tag && t.default));
function vr(s, e, t) {
  const n = xr(s, t);
  if (Bt(n))
    for (const i of n.items)
      Ys(s, e, i);
  else if (Array.isArray(n))
    for (const i of n)
      Ys(s, e, i);
  else
    Ys(s, e, n);
}
function Ys(s, e, t) {
  const n = xr(s, t);
  if (!Mt(n))
    throw new Error("Merge sources must be maps or map aliases");
  const i = n.toJSON(null, s, Map);
  for (const [r, o] of i)
    e instanceof Map ? e.has(r) || e.set(r, o) : e instanceof Set ? e.add(r) : Object.prototype.hasOwnProperty.call(e, r) || Object.defineProperty(e, r, {
      value: o,
      writable: !0,
      enumerable: !0,
      configurable: !0
    });
  return e;
}
function xr(s, e) {
  return s && dt(e) ? e.resolve(s.doc, s) : e;
}
function Cr(s, e, { key: t, value: n }) {
  if (K(t) && t.addToJSMap)
    t.addToJSMap(s, e, n);
  else if (dl(s, t))
    vr(s, e, n);
  else {
    const i = he(t, "", s);
    if (e instanceof Map)
      e.set(i, he(n, i, s));
    else if (e instanceof Set)
      e.add(i);
    else {
      const r = ml(t, i, s), o = he(n, r, s);
      r in e ? Object.defineProperty(e, r, {
        value: o,
        writable: !0,
        enumerable: !0,
        configurable: !0
      }) : e[r] = o;
    }
  }
  return e;
}
function ml(s, e, t) {
  if (e === null)
    return "";
  if (typeof e != "object")
    return String(e);
  if (K(s) && (t != null && t.doc)) {
    const n = Nr(t.doc, {});
    n.anchors = /* @__PURE__ */ new Set();
    for (const r of t.anchors.keys())
      n.anchors.add(r.anchor);
    n.inFlow = !0, n.inStringifyKey = !0;
    const i = s.toString(n);
    if (!t.mapKeyWarned) {
      let r = JSON.stringify(i);
      r.length > 40 && (r = r.substring(0, 36) + '..."'), Or(t.doc.options.logLevel, `Keys with collection values will be stringified due to JS Object restrictions: ${r}. Set mapAsMap: true to use object keys.`), t.mapKeyWarned = !0;
    }
    return i;
  }
  return JSON.stringify(e);
}
function Cn(s, e, t) {
  const n = Rt(s, void 0, t), i = Rt(e, void 0, t);
  return new ie(n, i);
}
class ie {
  constructor(e, t = null) {
    Object.defineProperty(this, de, { value: kr }), this.key = e, this.value = t;
  }
  clone(e) {
    let { key: t, value: n } = this;
    return K(t) && (t = t.clone(e)), K(n) && (n = n.clone(e)), new ie(t, n);
  }
  toJSON(e, t) {
    const n = t != null && t.mapAsMap ? /* @__PURE__ */ new Map() : {};
    return Cr(t, n, this);
  }
  toString(e, t, n) {
    return e != null && e.doc ? pl(this, e, t, n) : JSON.stringify(this);
  }
}
function Rr(s, e, t) {
  return (e.inFlow ?? s.flow ? yl : gl)(s, e, t);
}
function gl({ comment: s, items: e }, t, { blockItemPrefix: n, flowChars: i, itemIndent: r, onChompKeep: o, onComment: a }) {
  const { indent: c, options: { commentString: l } } = t, u = Object.assign({}, t, { indent: r, type: null });
  let p = !1;
  const h = [];
  for (let g = 0; g < e.length; ++g) {
    const m = e[g];
    let y = null;
    if (K(m))
      !p && m.spaceBefore && h.push(""), fs(t, h, m.commentBefore, p), m.comment && (y = m.comment);
    else if (G(m)) {
      const k = K(m.key) ? m.key : null;
      k && (!p && k.spaceBefore && h.push(""), fs(t, h, k.commentBefore, p));
    }
    p = !1;
    let A = ft(m, u, () => y = null, () => p = !0);
    y && (A += ze(A, r, l(y))), p && y && (p = !1), h.push(n + A);
  }
  let d;
  if (h.length === 0)
    d = i.start + i.end;
  else {
    d = h[0];
    for (let g = 1; g < h.length; ++g) {
      const m = h[g];
      d += m ? `
${c}${m}` : `
`;
    }
  }
  return s ? (d += `
` + Ne(l(s), c), a && a()) : p && o && o(), d;
}
function yl({ items: s }, e, { flowChars: t, itemIndent: n }) {
  const { indent: i, indentStep: r, flowCollectionPadding: o, options: { commentString: a } } = e;
  n += r;
  const c = Object.assign({}, e, {
    indent: n,
    inFlow: !0,
    type: null
  });
  let l = !1, u = 0;
  const p = [];
  for (let g = 0; g < s.length; ++g) {
    const m = s[g];
    let y = null;
    if (K(m))
      m.spaceBefore && p.push(""), fs(e, p, m.commentBefore, !1), m.comment && (y = m.comment);
    else if (G(m)) {
      const k = K(m.key) ? m.key : null;
      k && (k.spaceBefore && p.push(""), fs(e, p, k.commentBefore, !1), k.comment && (l = !0));
      const L = K(m.value) ? m.value : null;
      L ? (L.comment && (y = L.comment), L.commentBefore && (l = !0)) : m.value == null && (k != null && k.comment) && (y = k.comment);
    }
    y && (l = !0);
    let A = ft(m, c, () => y = null);
    l || (l = p.length > u || A.includes(`
`)), g < s.length - 1 ? A += "," : e.options.trailingComma && (e.options.lineWidth > 0 && (l || (l = p.reduce((k, L) => k + L.length + 2, 2) + (A.length + 2) > e.options.lineWidth)), l && (A += ",")), y && (A += ze(A, n, a(y))), p.push(A), u = p.length;
  }
  const { start: h, end: d } = t;
  if (p.length === 0)
    return h + d;
  if (!l) {
    const g = p.reduce((m, y) => m + y.length + 2, 2);
    l = e.options.lineWidth > 0 && g > e.options.lineWidth;
  }
  if (l) {
    let g = h;
    for (const m of p)
      g += m ? `
${r}${i}${m}` : `
`;
    return `${g}
${i}${d}`;
  } else
    return `${h}${o}${p.join(" ")}${o}${d}`;
}
function fs({ indent: s, options: { commentString: e } }, t, n, i) {
  if (n && i && (n = n.replace(/^\n+/, "")), n) {
    const r = Ne(e(n), s);
    t.push(r.trimStart());
  }
}
function qe(s, e) {
  const t = D(e) ? e.value : e;
  for (const n of s)
    if (G(n) && (n.key === e || n.key === t || D(n.key) && n.key.value === t))
      return n;
}
class fe extends Lr {
  static get tagName() {
    return "tag:yaml.org,2002:map";
  }
  constructor(e) {
    super(Me, e), this.items = [];
  }
  /**
   * A generic collection parsing method that can be extended
   * to other node classes that inherit from YAMLMap
   */
  static from(e, t, n) {
    const { keepUndefined: i, replacer: r } = n, o = new this(e), a = (c, l) => {
      if (typeof r == "function")
        l = r.call(t, c, l);
      else if (Array.isArray(r) && !r.includes(c))
        return;
      (l !== void 0 || i) && o.items.push(Cn(c, l, n));
    };
    if (t instanceof Map)
      for (const [c, l] of t)
        a(c, l);
    else if (t && typeof t == "object")
      for (const c of Object.keys(t))
        a(c, t[c]);
    return typeof e.sortMapEntries == "function" && o.items.sort(e.sortMapEntries), o;
  }
  /**
   * Adds a value to the collection.
   *
   * @param overwrite - If not set `true`, using a key that is already in the
   *   collection will throw. Otherwise, overwrites the previous value.
   */
  add(e, t) {
    var o;
    let n;
    G(e) ? n = e : !e || typeof e != "object" || !("key" in e) ? n = new ie(e, e == null ? void 0 : e.value) : n = new ie(e.key, e.value);
    const i = qe(this.items, n.key), r = (o = this.schema) == null ? void 0 : o.sortMapEntries;
    if (i) {
      if (!t)
        throw new Error(`Key ${n.key} already set`);
      D(i.value) && _r(n.value) ? i.value.value = n.value : i.value = n.value;
    } else if (r) {
      const a = this.items.findIndex((c) => r(n, c) < 0);
      a === -1 ? this.items.push(n) : this.items.splice(a, 0, n);
    } else
      this.items.push(n);
  }
  delete(e) {
    const t = qe(this.items, e);
    return t ? this.items.splice(this.items.indexOf(t), 1).length > 0 : !1;
  }
  get(e, t) {
    const n = qe(this.items, e), i = n == null ? void 0 : n.value;
    return (!t && D(i) ? i.value : i) ?? void 0;
  }
  has(e) {
    return !!qe(this.items, e);
  }
  set(e, t) {
    this.add(new ie(e, t), !0);
  }
  /**
   * @param ctx - Conversion context, originally set in Document#toJS()
   * @param {Class} Type - If set, forces the returned collection type
   * @returns Instance of Type, Map, or Object
   */
  toJSON(e, t, n) {
    const i = n ? new n() : t != null && t.mapAsMap ? /* @__PURE__ */ new Map() : {};
    t != null && t.onCreate && t.onCreate(i);
    for (const r of this.items)
      Cr(t, i, r);
    return i;
  }
  toString(e, t, n) {
    if (!e)
      return JSON.stringify(this);
    for (const i of this.items)
      if (!G(i))
        throw new Error(`Map items must all be pairs; found ${JSON.stringify(i)} instead`);
    return !e.allNullValues && this.hasAllNullValues(!1) && (e = Object.assign({}, e, { allNullValues: !0 })), Rr(this, e, {
      blockItemPrefix: "",
      flowChars: { start: "{", end: "}" },
      itemIndent: e.indent || "",
      onChompKeep: n,
      onComment: t
    });
  }
}
const gt = {
  collection: "map",
  default: !0,
  nodeClass: fe,
  tag: "tag:yaml.org,2002:map",
  resolve(s, e) {
    return Mt(s) || e("Expected a mapping for this tag"), s;
  },
  createNode: (s, e, t) => fe.from(s, e, t)
};
class Ge extends Lr {
  static get tagName() {
    return "tag:yaml.org,2002:seq";
  }
  constructor(e) {
    super(pt, e), this.items = [];
  }
  add(e) {
    this.items.push(e);
  }
  /**
   * Removes a value from the collection.
   *
   * `key` must contain a representation of an integer for this to succeed.
   * It may be wrapped in a `Scalar`.
   *
   * @returns `true` if the item was found and removed.
   */
  delete(e) {
    const t = Zt(e);
    return typeof t != "number" ? !1 : this.items.splice(t, 1).length > 0;
  }
  get(e, t) {
    const n = Zt(e);
    if (typeof n != "number")
      return;
    const i = this.items[n];
    return !t && D(i) ? i.value : i;
  }
  /**
   * Checks if the collection includes a value with the key `key`.
   *
   * `key` must contain a representation of an integer for this to succeed.
   * It may be wrapped in a `Scalar`.
   */
  has(e) {
    const t = Zt(e);
    return typeof t == "number" && t < this.items.length;
  }
  /**
   * Sets a value in this collection. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   *
   * If `key` does not contain a representation of an integer, this will throw.
   * It may be wrapped in a `Scalar`.
   */
  set(e, t) {
    const n = Zt(e);
    if (typeof n != "number")
      throw new Error(`Expected a valid index, not ${e}.`);
    const i = this.items[n];
    D(i) && _r(t) ? i.value = t : this.items[n] = t;
  }
  toJSON(e, t) {
    const n = [];
    t != null && t.onCreate && t.onCreate(n);
    let i = 0;
    for (const r of this.items)
      n.push(he(r, String(i++), t));
    return n;
  }
  toString(e, t, n) {
    return e ? Rr(this, e, {
      blockItemPrefix: "- ",
      flowChars: { start: "[", end: "]" },
      itemIndent: (e.indent || "") + "  ",
      onChompKeep: n,
      onComment: t
    }) : JSON.stringify(this);
  }
  static from(e, t, n) {
    const { replacer: i } = n, r = new this(e);
    if (t && Symbol.iterator in Object(t)) {
      let o = 0;
      for (let a of t) {
        if (typeof i == "function") {
          const c = t instanceof Set ? a : String(o++);
          a = i.call(t, c, a);
        }
        r.items.push(Rt(a, void 0, n));
      }
    }
    return r;
  }
}
function Zt(s) {
  let e = D(s) ? s.value : s;
  return e && typeof e == "string" && (e = Number(e)), typeof e == "number" && Number.isInteger(e) && e >= 0 ? e : null;
}
const yt = {
  collection: "seq",
  default: !0,
  nodeClass: Ge,
  tag: "tag:yaml.org,2002:seq",
  resolve(s, e) {
    return Bt(s) || e("Expected a sequence for this tag"), s;
  },
  createNode: (s, e, t) => Ge.from(s, e, t)
}, As = {
  identify: (s) => typeof s == "string",
  default: !0,
  tag: "tag:yaml.org,2002:str",
  resolve: (s) => s,
  stringify(s, e, t, n) {
    return e = Object.assign({ actualString: !0 }, e), xn(s, e, t, n);
  }
}, Ts = {
  identify: (s) => s == null,
  createNode: () => new v(null),
  default: !0,
  tag: "tag:yaml.org,2002:null",
  test: /^(?:~|[Nn]ull|NULL)?$/,
  resolve: () => new v(null),
  stringify: ({ source: s }, e) => typeof s == "string" && Ts.test.test(s) ? s : e.options.nullStr
}, Rn = {
  identify: (s) => typeof s == "boolean",
  default: !0,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:[Tt]rue|TRUE|[Ff]alse|FALSE)$/,
  resolve: (s) => new v(s[0] === "t" || s[0] === "T"),
  stringify({ source: s, value: e }, t) {
    if (s && Rn.test.test(s)) {
      const n = s[0] === "t" || s[0] === "T";
      if (e === n)
        return s;
    }
    return e ? t.options.trueStr : t.options.falseStr;
  }
};
function ye({ format: s, minFractionDigits: e, tag: t, value: n }) {
  if (typeof n == "bigint")
    return String(n);
  const i = typeof n == "number" ? n : Number(n);
  if (!isFinite(i))
    return isNaN(i) ? ".nan" : i < 0 ? "-.inf" : ".inf";
  let r = Object.is(n, -0) ? "-0" : JSON.stringify(n);
  if (!s && e && (!t || t === "tag:yaml.org,2002:float") && /^-?\d/.test(r) && !r.includes("e")) {
    let o = r.indexOf(".");
    o < 0 && (o = r.length, r += ".");
    let a = e - (r.length - o - 1);
    for (; a-- > 0; )
      r += "0";
  }
  return r;
}
const $r = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
  resolve: (s) => s.slice(-3).toLowerCase() === "nan" ? NaN : s[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
  stringify: ye
}, Pr = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  format: "EXP",
  test: /^[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)[eE][-+]?[0-9]+$/,
  resolve: (s) => parseFloat(s),
  stringify(s) {
    const e = Number(s.value);
    return isFinite(e) ? e.toExponential() : ye(s);
  }
}, Dr = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  test: /^[-+]?(?:\.[0-9]+|[0-9]+\.[0-9]*)$/,
  resolve(s) {
    const e = new v(parseFloat(s)), t = s.indexOf(".");
    return t !== -1 && s[s.length - 1] === "0" && (e.minFractionDigits = s.length - t - 1), e;
  },
  stringify: ye
}, Es = (s) => typeof s == "bigint" || Number.isInteger(s), $n = (s, e, t, { intAsBigInt: n }) => n ? BigInt(s) : parseInt(s.substring(e), t);
function Mr(s, e, t) {
  const { value: n } = s;
  return Es(n) && n >= 0 ? t + n.toString(e) : ye(s);
}
const Br = {
  identify: (s) => Es(s) && s >= 0,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  format: "OCT",
  test: /^0o[0-7]+$/,
  resolve: (s, e, t) => $n(s, 2, 8, t),
  stringify: (s) => Mr(s, 8, "0o")
}, Fr = {
  identify: Es,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  test: /^[-+]?[0-9]+$/,
  resolve: (s, e, t) => $n(s, 0, 10, t),
  stringify: ye
}, jr = {
  identify: (s) => Es(s) && s >= 0,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  format: "HEX",
  test: /^0x[0-9a-fA-F]+$/,
  resolve: (s, e, t) => $n(s, 2, 16, t),
  stringify: (s) => Mr(s, 16, "0x")
}, bl = [
  gt,
  yt,
  As,
  Ts,
  Rn,
  Br,
  Fr,
  jr,
  $r,
  Pr,
  Dr
];
function $i(s) {
  return typeof s == "bigint" || Number.isInteger(s);
}
const es = ({ value: s }) => JSON.stringify(s), wl = [
  {
    identify: (s) => typeof s == "string",
    default: !0,
    tag: "tag:yaml.org,2002:str",
    resolve: (s) => s,
    stringify: es
  },
  {
    identify: (s) => s == null,
    createNode: () => new v(null),
    default: !0,
    tag: "tag:yaml.org,2002:null",
    test: /^null$/,
    resolve: () => null,
    stringify: es
  },
  {
    identify: (s) => typeof s == "boolean",
    default: !0,
    tag: "tag:yaml.org,2002:bool",
    test: /^true$|^false$/,
    resolve: (s) => s === "true",
    stringify: es
  },
  {
    identify: $i,
    default: !0,
    tag: "tag:yaml.org,2002:int",
    test: /^-?(?:0|[1-9][0-9]*)$/,
    resolve: (s, e, { intAsBigInt: t }) => t ? BigInt(s) : parseInt(s, 10),
    stringify: ({ value: s }) => $i(s) ? s.toString() : JSON.stringify(s)
  },
  {
    identify: (s) => typeof s == "number",
    default: !0,
    tag: "tag:yaml.org,2002:float",
    test: /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$/,
    resolve: (s) => parseFloat(s),
    stringify: es
  }
], kl = {
  default: !0,
  tag: "",
  test: /^/,
  resolve(s, e) {
    return e(`Unresolved plain scalar ${JSON.stringify(s)}`), s;
  }
}, Sl = [gt, yt].concat(wl, kl), Pn = {
  identify: (s) => s instanceof Uint8Array,
  // Buffer inherits from Uint8Array
  default: !1,
  tag: "tag:yaml.org,2002:binary",
  /**
   * Returns a Buffer in node and an Uint8Array in browsers
   *
   * To use the resulting buffer as an image, you'll want to do something like:
   *
   *   const blob = new Blob([buffer], { type: 'image/jpeg' })
   *   document.querySelector('#photo').src = URL.createObjectURL(blob)
   */
  resolve(s, e) {
    if (typeof atob == "function") {
      const t = atob(s.replace(/[\n\r]/g, "")), n = new Uint8Array(t.length);
      for (let i = 0; i < t.length; ++i)
        n[i] = t.charCodeAt(i);
      return n;
    } else
      return e("This environment does not support reading binary tags; either Buffer or atob is required"), s;
  },
  stringify({ comment: s, type: e, value: t }, n, i, r) {
    if (!t)
      return "";
    const o = t;
    let a;
    if (typeof btoa == "function") {
      let c = "";
      for (let l = 0; l < o.length; ++l)
        c += String.fromCharCode(o[l]);
      a = btoa(c);
    } else
      throw new Error("This environment does not support writing binary tags; either Buffer or btoa is required");
    if (e ?? (e = v.BLOCK_LITERAL), e !== v.QUOTE_DOUBLE) {
      const c = Math.max(n.options.lineWidth - n.indent.length, n.options.minContentWidth), l = Math.ceil(a.length / c), u = new Array(l);
      for (let p = 0, h = 0; p < l; ++p, h += c)
        u[p] = a.substr(h, c);
      a = u.join(e === v.BLOCK_LITERAL ? `
` : " ");
    }
    return xn({ comment: s, type: e, value: a }, n, i, r);
  }
};
function Ur(s, e) {
  if (Bt(s))
    for (let t = 0; t < s.items.length; ++t) {
      let n = s.items[t];
      if (!G(n)) {
        if (Mt(n)) {
          n.items.length > 1 && e("Each pair must have its own sequence indicator");
          const i = n.items[0] || new ie(new v(null));
          if (n.commentBefore && (i.key.commentBefore = i.key.commentBefore ? `${n.commentBefore}
${i.key.commentBefore}` : n.commentBefore), n.comment) {
            const r = i.value ?? i.key;
            r.comment = r.comment ? `${n.comment}
${r.comment}` : n.comment;
          }
          n = i;
        }
        s.items[t] = G(n) ? n : new ie(n);
      }
    }
  else
    e("Expected a sequence for this tag");
  return s;
}
function zr(s, e, t) {
  const { replacer: n } = t, i = new Ge(s);
  i.tag = "tag:yaml.org,2002:pairs";
  let r = 0;
  if (e && Symbol.iterator in Object(e))
    for (let o of e) {
      typeof n == "function" && (o = n.call(e, String(r++), o));
      let a, c;
      if (Array.isArray(o))
        if (o.length === 2)
          a = o[0], c = o[1];
        else
          throw new TypeError(`Expected [key, value] tuple: ${o}`);
      else if (o && o instanceof Object) {
        const l = Object.keys(o);
        if (l.length === 1)
          a = l[0], c = o[a];
        else
          throw new TypeError(`Expected tuple with one key, not ${l.length} keys`);
      } else
        a = o;
      i.items.push(Cn(a, c, t));
    }
  return i;
}
const Dn = {
  collection: "seq",
  default: !1,
  tag: "tag:yaml.org,2002:pairs",
  resolve: Ur,
  createNode: zr
};
class ct extends Ge {
  constructor() {
    super(), this.add = fe.prototype.add.bind(this), this.delete = fe.prototype.delete.bind(this), this.get = fe.prototype.get.bind(this), this.has = fe.prototype.has.bind(this), this.set = fe.prototype.set.bind(this), this.tag = ct.tag;
  }
  /**
   * If `ctx` is given, the return type is actually `Map<unknown, unknown>`,
   * but TypeScript won't allow widening the signature of a child method.
   */
  toJSON(e, t) {
    if (!t)
      return super.toJSON(e);
    const n = /* @__PURE__ */ new Map();
    t != null && t.onCreate && t.onCreate(n);
    for (const i of this.items) {
      let r, o;
      if (G(i) ? (r = he(i.key, "", t), o = he(i.value, r, t)) : r = he(i, "", t), n.has(r))
        throw new Error("Ordered maps must not include duplicate keys");
      n.set(r, o);
    }
    return n;
  }
  static from(e, t, n) {
    const i = zr(e, t, n), r = new this();
    return r.items = i.items, r;
  }
}
ct.tag = "tag:yaml.org,2002:omap";
const Mn = {
  collection: "seq",
  identify: (s) => s instanceof Map,
  nodeClass: ct,
  default: !1,
  tag: "tag:yaml.org,2002:omap",
  resolve(s, e) {
    const t = Ur(s, e), n = [];
    for (const { key: i } of t.items)
      D(i) && (n.includes(i.value) ? e(`Ordered maps must not include duplicate keys: ${i.value}`) : n.push(i.value));
    return Object.assign(new ct(), t);
  },
  createNode: (s, e, t) => ct.from(s, e, t)
};
function qr({ value: s, source: e }, t) {
  return e && (s ? Kr : Gr).test.test(e) ? e : s ? t.options.trueStr : t.options.falseStr;
}
const Kr = {
  identify: (s) => s === !0,
  default: !0,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:Y|y|[Yy]es|YES|[Tt]rue|TRUE|[Oo]n|ON)$/,
  resolve: () => new v(!0),
  stringify: qr
}, Gr = {
  identify: (s) => s === !1,
  default: !0,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:N|n|[Nn]o|NO|[Ff]alse|FALSE|[Oo]ff|OFF)$/,
  resolve: () => new v(!1),
  stringify: qr
}, Al = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
  resolve: (s) => s.slice(-3).toLowerCase() === "nan" ? NaN : s[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
  stringify: ye
}, Tl = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  format: "EXP",
  test: /^[-+]?(?:[0-9][0-9_]*)?(?:\.[0-9_]*)?[eE][-+]?[0-9]+$/,
  resolve: (s) => parseFloat(s.replace(/_/g, "")),
  stringify(s) {
    const e = Number(s.value);
    return isFinite(e) ? e.toExponential() : ye(s);
  }
}, El = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  test: /^[-+]?(?:[0-9][0-9_]*)?\.[0-9_]*$/,
  resolve(s) {
    const e = new v(parseFloat(s.replace(/_/g, ""))), t = s.indexOf(".");
    if (t !== -1) {
      const n = s.substring(t + 1).replace(/_/g, "");
      n[n.length - 1] === "0" && (e.minFractionDigits = n.length);
    }
    return e;
  },
  stringify: ye
}, Ft = (s) => typeof s == "bigint" || Number.isInteger(s);
function _s(s, e, t, { intAsBigInt: n }) {
  const i = s[0];
  if ((i === "-" || i === "+") && (e += 1), s = s.substring(e).replace(/_/g, ""), n) {
    switch (t) {
      case 2:
        s = `0b${s}`;
        break;
      case 8:
        s = `0o${s}`;
        break;
      case 16:
        s = `0x${s}`;
        break;
    }
    const o = BigInt(s);
    return i === "-" ? BigInt(-1) * o : o;
  }
  const r = parseInt(s, t);
  return i === "-" ? -1 * r : r;
}
function Bn(s, e, t) {
  const { value: n } = s;
  if (Ft(n)) {
    const i = n.toString(e);
    return n < 0 ? "-" + t + i.substr(1) : t + i;
  }
  return ye(s);
}
const _l = {
  identify: Ft,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  format: "BIN",
  test: /^[-+]?0b[0-1_]+$/,
  resolve: (s, e, t) => _s(s, 2, 2, t),
  stringify: (s) => Bn(s, 2, "0b")
}, Ll = {
  identify: Ft,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  format: "OCT",
  test: /^[-+]?0[0-7_]+$/,
  resolve: (s, e, t) => _s(s, 1, 8, t),
  stringify: (s) => Bn(s, 8, "0")
}, Il = {
  identify: Ft,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  test: /^[-+]?[0-9][0-9_]*$/,
  resolve: (s, e, t) => _s(s, 0, 10, t),
  stringify: ye
}, Nl = {
  identify: Ft,
  default: !0,
  tag: "tag:yaml.org,2002:int",
  format: "HEX",
  test: /^[-+]?0x[0-9a-fA-F_]+$/,
  resolve: (s, e, t) => _s(s, 2, 16, t),
  stringify: (s) => Bn(s, 16, "0x")
};
class ut extends fe {
  constructor(e) {
    super(e), this.tag = ut.tag;
  }
  add(e) {
    let t;
    G(e) ? t = e : e && typeof e == "object" && "key" in e && "value" in e && e.value === null ? t = new ie(e.key, null) : t = new ie(e, null), qe(this.items, t.key) || this.items.push(t);
  }
  /**
   * If `keepPair` is `true`, returns the Pair matching `key`.
   * Otherwise, returns the value of that Pair's key.
   */
  get(e, t) {
    const n = qe(this.items, e);
    return !t && G(n) ? D(n.key) ? n.key.value : n.key : n;
  }
  set(e, t) {
    if (typeof t != "boolean")
      throw new Error(`Expected boolean value for set(key, value) in a YAML set, not ${typeof t}`);
    const n = qe(this.items, e);
    n && !t ? this.items.splice(this.items.indexOf(n), 1) : !n && t && this.items.push(new ie(e));
  }
  toJSON(e, t) {
    return super.toJSON(e, t, Set);
  }
  toString(e, t, n) {
    if (!e)
      return JSON.stringify(this);
    if (this.hasAllNullValues(!0))
      return super.toString(Object.assign({}, e, { allNullValues: !0 }), t, n);
    throw new Error("Set items must all have null values");
  }
  static from(e, t, n) {
    const { replacer: i } = n, r = new this(e);
    if (t && Symbol.iterator in Object(t))
      for (let o of t)
        typeof i == "function" && (o = i.call(t, o, o)), r.items.push(Cn(o, null, n));
    return r;
  }
}
ut.tag = "tag:yaml.org,2002:set";
const Fn = {
  collection: "map",
  identify: (s) => s instanceof Set,
  nodeClass: ut,
  default: !1,
  tag: "tag:yaml.org,2002:set",
  createNode: (s, e, t) => ut.from(s, e, t),
  resolve(s, e) {
    if (Mt(s)) {
      if (s.hasAllNullValues(!0))
        return Object.assign(new ut(), s);
      e("Set items must all have null values");
    } else
      e("Expected a mapping for this tag");
    return s;
  }
};
function jn(s, e) {
  const t = s[0], n = t === "-" || t === "+" ? s.substring(1) : s, i = (o) => e ? BigInt(o) : Number(o), r = n.replace(/_/g, "").split(":").reduce((o, a) => o * i(60) + i(a), i(0));
  return t === "-" ? i(-1) * r : r;
}
function Hr(s) {
  let { value: e } = s, t = (o) => o;
  if (typeof e == "bigint")
    t = (o) => BigInt(o);
  else if (isNaN(e) || !isFinite(e))
    return ye(s);
  let n = "";
  e < 0 && (n = "-", e *= t(-1));
  const i = t(60), r = [e % i];
  return e < 60 ? r.unshift(0) : (e = (e - r[0]) / i, r.unshift(e % i), e >= 60 && (e = (e - r[0]) / i, r.unshift(e))), n + r.map((o) => String(o).padStart(2, "0")).join(":").replace(/000000\d*$/, "");
}
const Vr = {
  identify: (s) => typeof s == "bigint" || Number.isInteger(s),
  default: !0,
  tag: "tag:yaml.org,2002:int",
  format: "TIME",
  test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+$/,
  resolve: (s, e, { intAsBigInt: t }) => jn(s, t),
  stringify: Hr
}, Wr = {
  identify: (s) => typeof s == "number",
  default: !0,
  tag: "tag:yaml.org,2002:float",
  format: "TIME",
  test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\.[0-9_]*$/,
  resolve: (s) => jn(s, !1),
  stringify: Hr
}, Ls = {
  identify: (s) => s instanceof Date,
  default: !0,
  tag: "tag:yaml.org,2002:timestamp",
  // If the time zone is omitted, the timestamp is assumed to be specified in UTC. The time part
  // may be omitted altogether, resulting in a date format. In such a case, the time part is
  // assumed to be 00:00:00Z (start of day, UTC).
  test: RegExp("^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?:(?:t|T|[ \\t]+)([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}(\\.[0-9]+)?)(?:[ \\t]*(Z|[-+][012]?[0-9](?::[0-9]{2})?))?)?$"),
  resolve(s) {
    const e = s.match(Ls.test);
    if (!e)
      throw new Error("!!timestamp expects a date, starting with yyyy-mm-dd");
    const [, t, n, i, r, o, a] = e.map(Number), c = e[7] ? Number((e[7] + "00").substr(1, 3)) : 0;
    let l = Date.UTC(t, n - 1, i, r || 0, o || 0, a || 0, c);
    const u = e[8];
    if (u && u !== "Z") {
      let p = jn(u, !1);
      Math.abs(p) < 30 && (p *= 60), l -= 6e4 * p;
    }
    return new Date(l);
  },
  stringify: ({ value: s }) => (s == null ? void 0 : s.toISOString().replace(/(T00:00:00)?\.000Z$/, "")) ?? ""
}, Pi = [
  gt,
  yt,
  As,
  Ts,
  Kr,
  Gr,
  _l,
  Ll,
  Il,
  Nl,
  Al,
  Tl,
  El,
  Pn,
  Oe,
  Mn,
  Dn,
  Fn,
  Vr,
  Wr,
  Ls
], Di = /* @__PURE__ */ new Map([
  ["core", bl],
  ["failsafe", [gt, yt, As]],
  ["json", Sl],
  ["yaml11", Pi],
  ["yaml-1.1", Pi]
]), Mi = {
  binary: Pn,
  bool: Rn,
  float: Dr,
  floatExp: Pr,
  floatNaN: $r,
  floatTime: Wr,
  int: Fr,
  intHex: jr,
  intOct: Br,
  intTime: Vr,
  map: gt,
  merge: Oe,
  null: Ts,
  omap: Mn,
  pairs: Dn,
  seq: yt,
  set: Fn,
  timestamp: Ls
}, Ol = {
  "tag:yaml.org,2002:binary": Pn,
  "tag:yaml.org,2002:merge": Oe,
  "tag:yaml.org,2002:omap": Mn,
  "tag:yaml.org,2002:pairs": Dn,
  "tag:yaml.org,2002:set": Fn,
  "tag:yaml.org,2002:timestamp": Ls
};
function Js(s, e, t) {
  const n = Di.get(e);
  if (n && !s)
    return t && !n.includes(Oe) ? n.concat(Oe) : n.slice();
  let i = n;
  if (!i)
    if (Array.isArray(s))
      i = [];
    else {
      const r = Array.from(Di.keys()).filter((o) => o !== "yaml11").map((o) => JSON.stringify(o)).join(", ");
      throw new Error(`Unknown schema "${e}"; use one of ${r} or define customTags array`);
    }
  if (Array.isArray(s))
    for (const r of s)
      i = i.concat(r);
  else typeof s == "function" && (i = s(i.slice()));
  return t && (i = i.concat(Oe)), i.reduce((r, o) => {
    const a = typeof o == "string" ? Mi[o] : o;
    if (!a) {
      const c = JSON.stringify(o), l = Object.keys(Mi).map((u) => JSON.stringify(u)).join(", ");
      throw new Error(`Unknown custom tag ${c}; use one of ${l}`);
    }
    return r.includes(a) || r.push(a), r;
  }, []);
}
const vl = (s, e) => s.key < e.key ? -1 : s.key > e.key ? 1 : 0;
class Un {
  constructor({ compat: e, customTags: t, merge: n, resolveKnownTags: i, schema: r, sortMapEntries: o, toStringDefaults: a }) {
    this.compat = Array.isArray(e) ? Js(e, "compat") : e ? Js(null, e) : null, this.name = typeof r == "string" && r || "core", this.knownTags = i ? Ol : {}, this.tags = Js(t, this.name, n), this.toStringOptions = a ?? null, Object.defineProperty(this, Me, { value: gt }), Object.defineProperty(this, Ae, { value: As }), Object.defineProperty(this, pt, { value: yt }), this.sortMapEntries = typeof o == "function" ? o : o === !0 ? vl : null;
  }
  clone() {
    const e = Object.create(Un.prototype, Object.getOwnPropertyDescriptors(this));
    return e.tags = this.tags.slice(), e;
  }
}
function xl(s, e) {
  var c;
  const t = [];
  let n = e.directives === !0;
  if (e.directives !== !1 && s.directives) {
    const l = s.directives.toString(s);
    l ? (t.push(l), n = !0) : s.directives.docStart && (n = !0);
  }
  n && t.push("---");
  const i = Nr(s, e), { commentString: r } = i.options;
  if (s.commentBefore) {
    t.length !== 1 && t.unshift("");
    const l = r(s.commentBefore);
    t.unshift(Ne(l, ""));
  }
  let o = !1, a = null;
  if (s.contents) {
    if (K(s.contents)) {
      if (s.contents.spaceBefore && n && t.push(""), s.contents.commentBefore) {
        const p = r(s.contents.commentBefore);
        t.push(Ne(p, ""));
      }
      i.forceBlockIndent = !!s.comment, a = s.contents.comment;
    }
    const l = a ? void 0 : () => o = !0;
    let u = ft(s.contents, i, () => a = null, l);
    a && (u += ze(u, "", r(a))), (u[0] === "|" || u[0] === ">") && t[t.length - 1] === "---" ? t[t.length - 1] = `--- ${u}` : t.push(u);
  } else
    t.push(ft(s.contents, i));
  if ((c = s.directives) != null && c.docEnd)
    if (s.comment) {
      const l = r(s.comment);
      l.includes(`
`) ? (t.push("..."), t.push(Ne(l, ""))) : t.push(`... ${l}`);
    } else
      t.push("...");
  else {
    let l = s.comment;
    l && o && (l = l.replace(/^\n+/, "")), l && ((!o || a) && t[t.length - 1] !== "" && t.push(""), t.push(Ne(r(l), "")));
  }
  return t.join(`
`) + `
`;
}
class Is {
  constructor(e, t, n) {
    this.commentBefore = null, this.comment = null, this.errors = [], this.warnings = [], Object.defineProperty(this, de, { value: un });
    let i = null;
    typeof t == "function" || Array.isArray(t) ? i = t : n === void 0 && t && (n = t, t = void 0);
    const r = Object.assign({
      intAsBigInt: !1,
      keepSourceTokens: !1,
      logLevel: "warn",
      prettyErrors: !0,
      strict: !0,
      stringKeys: !1,
      uniqueKeys: !0,
      version: "1.2"
    }, n);
    this.options = r;
    let { version: o } = r;
    n != null && n._directives ? (this.directives = n._directives.atDocument(), this.directives.yaml.explicit && (o = this.directives.yaml.version)) : this.directives = new se({ version: o }), this.setSchema(o, n), this.contents = e === void 0 ? null : this.createNode(e, i, n);
  }
  /**
   * Create a deep copy of this Document and its contents.
   *
   * Custom Node values that inherit from `Object` still refer to their original instances.
   */
  clone() {
    const e = Object.create(Is.prototype, {
      [de]: { value: un }
    });
    return e.commentBefore = this.commentBefore, e.comment = this.comment, e.errors = this.errors.slice(), e.warnings = this.warnings.slice(), e.options = Object.assign({}, this.options), this.directives && (e.directives = this.directives.clone()), e.schema = this.schema.clone(), e.contents = K(this.contents) ? this.contents.clone(e.schema) : this.contents, this.range && (e.range = this.range.slice()), e;
  }
  /** Adds a value to the document. */
  add(e) {
    nt(this.contents) && this.contents.add(e);
  }
  /** Adds a value to the document. */
  addIn(e, t) {
    nt(this.contents) && this.contents.addIn(e, t);
  }
  /**
   * Create a new `Alias` node, ensuring that the target `node` has the required anchor.
   *
   * If `node` already has an anchor, `name` is ignored.
   * Otherwise, the `node.anchor` value will be set to `name`,
   * or if an anchor with that name is already present in the document,
   * `name` will be used as a prefix for a new unique anchor.
   * If `name` is undefined, the generated anchor will use 'a' as a prefix.
   */
  createAlias(e, t) {
    if (!e.anchor) {
      const n = Tr(this);
      e.anchor = // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      !t || n.has(t) ? Er(t || "a", n) : t;
    }
    return new vn(e.anchor);
  }
  createNode(e, t, n) {
    let i;
    if (typeof t == "function")
      e = t.call({ "": e }, "", e), i = t;
    else if (Array.isArray(t)) {
      const y = (k) => typeof k == "number" || k instanceof String || k instanceof Number, A = t.filter(y).map(String);
      A.length > 0 && (t = t.concat(A)), i = t;
    } else n === void 0 && t && (n = t, t = void 0);
    const { aliasDuplicateObjects: r, anchorPrefix: o, flow: a, keepUndefined: c, onTagObj: l, tag: u } = n ?? {}, { onAnchor: p, setAnchors: h, sourceObjects: d } = rl(
      this,
      // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      o || "a"
    ), g = {
      aliasDuplicateObjects: r ?? !0,
      keepUndefined: c ?? !1,
      onAnchor: p,
      onTagObj: l,
      replacer: i,
      schema: this.schema,
      sourceObjects: d
    }, m = Rt(e, u, g);
    return a && q(m) && (m.flow = !0), h(), m;
  }
  /**
   * Convert a key and a value into a `Pair` using the current schema,
   * recursively wrapping all values as `Scalar` or `Collection` nodes.
   */
  createPair(e, t, n = {}) {
    const i = this.createNode(e, null, n), r = this.createNode(t, null, n);
    return new ie(i, r);
  }
  /**
   * Removes a value from the document.
   * @returns `true` if the item was found and removed.
   */
  delete(e) {
    return nt(this.contents) ? this.contents.delete(e) : !1;
  }
  /**
   * Removes a value from the document.
   * @returns `true` if the item was found and removed.
   */
  deleteIn(e) {
    return Nt(e) ? this.contents == null ? !1 : (this.contents = null, !0) : nt(this.contents) ? this.contents.deleteIn(e) : !1;
  }
  /**
   * Returns item at `key`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  get(e, t) {
    return q(this.contents) ? this.contents.get(e, t) : void 0;
  }
  /**
   * Returns item at `path`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  getIn(e, t) {
    return Nt(e) ? !t && D(this.contents) ? this.contents.value : this.contents : q(this.contents) ? this.contents.getIn(e, t) : void 0;
  }
  /**
   * Checks if the document includes a value with the key `key`.
   */
  has(e) {
    return q(this.contents) ? this.contents.has(e) : !1;
  }
  /**
   * Checks if the document includes a value at `path`.
   */
  hasIn(e) {
    return Nt(e) ? this.contents !== void 0 : q(this.contents) ? this.contents.hasIn(e) : !1;
  }
  /**
   * Sets a value in this document. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  set(e, t) {
    this.contents == null ? this.contents = us(this.schema, [e], t) : nt(this.contents) && this.contents.set(e, t);
  }
  /**
   * Sets a value in this document. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  setIn(e, t) {
    Nt(e) ? this.contents = t : this.contents == null ? this.contents = us(this.schema, Array.from(e), t) : nt(this.contents) && this.contents.setIn(e, t);
  }
  /**
   * Change the YAML version and schema used by the document.
   * A `null` version disables support for directives, explicit tags, anchors, and aliases.
   * It also requires the `schema` option to be given as a `Schema` instance value.
   *
   * Overrides all previously set schema options.
   */
  setSchema(e, t = {}) {
    typeof e == "number" && (e = String(e));
    let n;
    switch (e) {
      case "1.1":
        this.directives ? this.directives.yaml.version = "1.1" : this.directives = new se({ version: "1.1" }), n = { resolveKnownTags: !1, schema: "yaml-1.1" };
        break;
      case "1.2":
      case "next":
        this.directives ? this.directives.yaml.version = e : this.directives = new se({ version: e }), n = { resolveKnownTags: !0, schema: "core" };
        break;
      case null:
        this.directives && delete this.directives, n = null;
        break;
      default: {
        const i = JSON.stringify(e);
        throw new Error(`Expected '1.1', '1.2' or null as first argument, but found: ${i}`);
      }
    }
    if (t.schema instanceof Object)
      this.schema = t.schema;
    else if (n)
      this.schema = new Un(Object.assign(n, t));
    else
      throw new Error("With a null YAML version, the { schema: Schema } option is required");
  }
  // json & jsonArg are only used from toJSON()
  toJS({ json: e, jsonArg: t, mapAsMap: n, maxAliasCount: i, onAnchor: r, reviver: o } = {}) {
    const a = {
      anchors: /* @__PURE__ */ new Map(),
      doc: this,
      keep: !e,
      mapAsMap: n === !0,
      mapKeyWarned: !1,
      maxAliasCount: typeof i == "number" ? i : 100
    }, c = he(this.contents, t ?? "", a);
    if (typeof r == "function")
      for (const { count: l, res: u } of a.anchors.values())
        r(u, l);
    return typeof o == "function" ? at(o, { "": c }, "", c) : c;
  }
  /**
   * A JSON representation of the document `contents`.
   *
   * @param jsonArg Used by `JSON.stringify` to indicate the array index or
   *   property name.
   */
  toJSON(e, t) {
    return this.toJS({ json: !0, jsonArg: e, mapAsMap: !1, onAnchor: t });
  }
  /** A YAML representation of the document. */
  toString(e = {}) {
    if (this.errors.length > 0)
      throw new Error("Document with errors cannot be stringified");
    if ("indent" in e && (!Number.isInteger(e.indent) || Number(e.indent) <= 0)) {
      const t = JSON.stringify(e.indent);
      throw new Error(`"indent" option must be a positive integer, not ${t}`);
    }
    return xl(this, e);
  }
}
function nt(s) {
  if (q(s))
    return !0;
  throw new Error("Expected a YAML collection as document contents");
}
class Yr extends Error {
  constructor(e, t, n, i) {
    super(), this.name = e, this.code = n, this.message = i, this.pos = t;
  }
}
class Ot extends Yr {
  constructor(e, t, n) {
    super("YAMLParseError", e, t, n);
  }
}
class Cl extends Yr {
  constructor(e, t, n) {
    super("YAMLWarning", e, t, n);
  }
}
const Bi = (s, e) => (t) => {
  if (t.pos[0] === -1)
    return;
  t.linePos = t.pos.map((a) => e.linePos(a));
  const { line: n, col: i } = t.linePos[0];
  t.message += ` at line ${n}, column ${i}`;
  let r = i - 1, o = s.substring(e.lineStarts[n - 1], e.lineStarts[n]).replace(/[\n\r]+$/, "");
  if (r >= 60 && o.length > 80) {
    const a = Math.min(r - 39, o.length - 79);
    o = "…" + o.substring(a), r -= a - 1;
  }
  if (o.length > 80 && (o = o.substring(0, 79) + "…"), n > 1 && /^ *$/.test(o.substring(0, r))) {
    let a = s.substring(e.lineStarts[n - 2], e.lineStarts[n - 1]);
    a.length > 80 && (a = a.substring(0, 79) + `…
`), o = a + o;
  }
  if (/[^ ]/.test(o)) {
    let a = 1;
    const c = t.linePos[1];
    (c == null ? void 0 : c.line) === n && c.col > i && (a = Math.max(1, Math.min(c.col - i, 80 - r)));
    const l = " ".repeat(r) + "^".repeat(a);
    t.message += `:

${o}
${l}
`;
  }
};
function ht(s, { flow: e, indicator: t, next: n, offset: i, onError: r, parentIndent: o, startOnNewline: a }) {
  let c = !1, l = a, u = a, p = "", h = "", d = !1, g = !1, m = null, y = null, A = null, k = null, L = null, I = null, w = null;
  for (const T of s)
    switch (g && (T.type !== "space" && T.type !== "newline" && T.type !== "comma" && r(T.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space"), g = !1), m && (l && T.type !== "comment" && T.type !== "newline" && r(m, "TAB_AS_INDENT", "Tabs are not allowed as indentation"), m = null), T.type) {
      case "space":
        !e && (t !== "doc-start" || (n == null ? void 0 : n.type) !== "flow-collection") && T.source.includes("	") && (m = T), u = !0;
        break;
      case "comment": {
        u || r(T, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
        const C = T.source.substring(1) || " ";
        p ? p += h + C : p = C, h = "", l = !1;
        break;
      }
      case "newline":
        l ? p ? p += T.source : (!I || t !== "seq-item-ind") && (c = !0) : h += T.source, l = !0, d = !0, (y || A) && (k = T), u = !0;
        break;
      case "anchor":
        y && r(T, "MULTIPLE_ANCHORS", "A node can have at most one anchor"), T.source.endsWith(":") && r(T.offset + T.source.length - 1, "BAD_ALIAS", "Anchor ending in : is ambiguous", !0), y = T, w ?? (w = T.offset), l = !1, u = !1, g = !0;
        break;
      case "tag": {
        A && r(T, "MULTIPLE_TAGS", "A node can have at most one tag"), A = T, w ?? (w = T.offset), l = !1, u = !1, g = !0;
        break;
      }
      case t:
        (y || A) && r(T, "BAD_PROP_ORDER", `Anchors and tags must be after the ${T.source} indicator`), I && r(T, "UNEXPECTED_TOKEN", `Unexpected ${T.source} in ${e ?? "collection"}`), I = T, l = t === "seq-item-ind" || t === "explicit-key-ind", u = !1;
        break;
      case "comma":
        if (e) {
          L && r(T, "UNEXPECTED_TOKEN", `Unexpected , in ${e}`), L = T, l = !1, u = !1;
          break;
        }
      // else fallthrough
      default:
        r(T, "UNEXPECTED_TOKEN", `Unexpected ${T.type} token`), l = !1, u = !1;
    }
  const S = s[s.length - 1], E = S ? S.offset + S.source.length : i;
  return g && n && n.type !== "space" && n.type !== "newline" && n.type !== "comma" && (n.type !== "scalar" || n.source !== "") && r(n.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space"), m && (l && m.indent <= o || (n == null ? void 0 : n.type) === "block-map" || (n == null ? void 0 : n.type) === "block-seq") && r(m, "TAB_AS_INDENT", "Tabs are not allowed as indentation"), {
    comma: L,
    found: I,
    spaceBefore: c,
    comment: p,
    hasNewline: d,
    anchor: y,
    tag: A,
    newlineAfterProp: k,
    end: E,
    start: w ?? E
  };
}
function $t(s) {
  if (!s)
    return null;
  switch (s.type) {
    case "alias":
    case "scalar":
    case "double-quoted-scalar":
    case "single-quoted-scalar":
      if (s.source.includes(`
`))
        return !0;
      if (s.end) {
        for (const e of s.end)
          if (e.type === "newline")
            return !0;
      }
      return !1;
    case "flow-collection":
      for (const e of s.items) {
        for (const t of e.start)
          if (t.type === "newline")
            return !0;
        if (e.sep) {
          for (const t of e.sep)
            if (t.type === "newline")
              return !0;
        }
        if ($t(e.key) || $t(e.value))
          return !0;
      }
      return !1;
    default:
      return !0;
  }
}
function dn(s, e, t) {
  if ((e == null ? void 0 : e.type) === "flow-collection") {
    const n = e.end[0];
    n.indent === s && (n.source === "]" || n.source === "}") && $t(e) && t(n, "BAD_INDENT", "Flow end indicator should be more indented than parent", !0);
  }
}
function Jr(s, e, t) {
  const { uniqueKeys: n } = s.options;
  if (n === !1)
    return !1;
  const i = typeof n == "function" ? n : (r, o) => r === o || D(r) && D(o) && r.value === o.value;
  return e.some((r) => i(r.key, t));
}
const Fi = "All mapping items must start at the same column";
function Rl({ composeNode: s, composeEmptyNode: e }, t, n, i, r) {
  var u;
  const o = (r == null ? void 0 : r.nodeClass) ?? fe, a = new o(t.schema);
  t.atRoot && (t.atRoot = !1);
  let c = n.offset, l = null;
  for (const p of n.items) {
    const { start: h, key: d, sep: g, value: m } = p, y = ht(h, {
      indicator: "explicit-key-ind",
      next: d ?? (g == null ? void 0 : g[0]),
      offset: c,
      onError: i,
      parentIndent: n.indent,
      startOnNewline: !0
    }), A = !y.found;
    if (A) {
      if (d && (d.type === "block-seq" ? i(c, "BLOCK_AS_IMPLICIT_KEY", "A block sequence may not be used as an implicit map key") : "indent" in d && d.indent !== n.indent && i(c, "BAD_INDENT", Fi)), !y.anchor && !y.tag && !g) {
        l = y.end, y.comment && (a.comment ? a.comment += `
` + y.comment : a.comment = y.comment);
        continue;
      }
      (y.newlineAfterProp || $t(d)) && i(d ?? h[h.length - 1], "MULTILINE_IMPLICIT_KEY", "Implicit keys need to be on a single line");
    } else ((u = y.found) == null ? void 0 : u.indent) !== n.indent && i(c, "BAD_INDENT", Fi);
    t.atKey = !0;
    const k = y.end, L = d ? s(t, d, y, i) : e(t, k, h, null, y, i);
    t.schema.compat && dn(n.indent, d, i), t.atKey = !1, Jr(t, a.items, L) && i(k, "DUPLICATE_KEY", "Map keys must be unique");
    const I = ht(g ?? [], {
      indicator: "map-value-ind",
      next: m,
      offset: L.range[2],
      onError: i,
      parentIndent: n.indent,
      startOnNewline: !d || d.type === "block-scalar"
    });
    if (c = I.end, I.found) {
      A && ((m == null ? void 0 : m.type) === "block-map" && !I.hasNewline && i(c, "BLOCK_AS_IMPLICIT_KEY", "Nested mappings are not allowed in compact mappings"), t.options.strict && y.start < I.found.offset - 1024 && i(L.range, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit block mapping key"));
      const w = m ? s(t, m, I, i) : e(t, c, g, null, I, i);
      t.schema.compat && dn(n.indent, m, i), c = w.range[2];
      const S = new ie(L, w);
      t.options.keepSourceTokens && (S.srcToken = p), a.items.push(S);
    } else {
      A && i(L.range, "MISSING_CHAR", "Implicit map keys need to be followed by map values"), I.comment && (L.comment ? L.comment += `
` + I.comment : L.comment = I.comment);
      const w = new ie(L);
      t.options.keepSourceTokens && (w.srcToken = p), a.items.push(w);
    }
  }
  return l && l < c && i(l, "IMPOSSIBLE", "Map comment with trailing content"), a.range = [n.offset, c, l ?? c], a;
}
function $l({ composeNode: s, composeEmptyNode: e }, t, n, i, r) {
  const o = (r == null ? void 0 : r.nodeClass) ?? Ge, a = new o(t.schema);
  t.atRoot && (t.atRoot = !1), t.atKey && (t.atKey = !1);
  let c = n.offset, l = null;
  for (const { start: u, value: p } of n.items) {
    const h = ht(u, {
      indicator: "seq-item-ind",
      next: p,
      offset: c,
      onError: i,
      parentIndent: n.indent,
      startOnNewline: !0
    });
    if (!h.found)
      if (h.anchor || h.tag || p)
        (p == null ? void 0 : p.type) === "block-seq" ? i(h.end, "BAD_INDENT", "All sequence items must start at the same column") : i(c, "MISSING_CHAR", "Sequence item without - indicator");
      else {
        l = h.end, h.comment && (a.comment = h.comment);
        continue;
      }
    const d = p ? s(t, p, h, i) : e(t, h.end, u, null, h, i);
    t.schema.compat && dn(n.indent, p, i), c = d.range[2], a.items.push(d);
  }
  return a.range = [n.offset, c, l ?? c], a;
}
function jt(s, e, t, n) {
  let i = "";
  if (s) {
    let r = !1, o = "";
    for (const a of s) {
      const { source: c, type: l } = a;
      switch (l) {
        case "space":
          r = !0;
          break;
        case "comment": {
          t && !r && n(a, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
          const u = c.substring(1) || " ";
          i ? i += o + u : i = u, o = "";
          break;
        }
        case "newline":
          i && (o += c), r = !0;
          break;
        default:
          n(a, "UNEXPECTED_TOKEN", `Unexpected ${l} at node end`);
      }
      e += c.length;
    }
  }
  return { comment: i, offset: e };
}
const Xs = "Block collections are not allowed within flow collections", Qs = (s) => s && (s.type === "block-map" || s.type === "block-seq");
function Pl({ composeNode: s, composeEmptyNode: e }, t, n, i, r) {
  var y;
  const o = n.start.source === "{", a = o ? "flow map" : "flow sequence", c = (r == null ? void 0 : r.nodeClass) ?? (o ? fe : Ge), l = new c(t.schema);
  l.flow = !0;
  const u = t.atRoot;
  u && (t.atRoot = !1), t.atKey && (t.atKey = !1);
  let p = n.offset + n.start.source.length;
  for (let A = 0; A < n.items.length; ++A) {
    const k = n.items[A], { start: L, key: I, sep: w, value: S } = k, E = ht(L, {
      flow: a,
      indicator: "explicit-key-ind",
      next: I ?? (w == null ? void 0 : w[0]),
      offset: p,
      onError: i,
      parentIndent: n.indent,
      startOnNewline: !1
    });
    if (!E.found) {
      if (!E.anchor && !E.tag && !w && !S) {
        A === 0 && E.comma ? i(E.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${a}`) : A < n.items.length - 1 && i(E.start, "UNEXPECTED_TOKEN", `Unexpected empty item in ${a}`), E.comment && (l.comment ? l.comment += `
` + E.comment : l.comment = E.comment), p = E.end;
        continue;
      }
      !o && t.options.strict && $t(I) && i(
        I,
        // checked by containsNewline()
        "MULTILINE_IMPLICIT_KEY",
        "Implicit keys of flow sequence pairs need to be on a single line"
      );
    }
    if (A === 0)
      E.comma && i(E.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${a}`);
    else if (E.comma || i(E.start, "MISSING_CHAR", `Missing , between ${a} items`), E.comment) {
      let T = "";
      e: for (const C of L)
        switch (C.type) {
          case "comma":
          case "space":
            break;
          case "comment":
            T = C.source.substring(1);
            break e;
          default:
            break e;
        }
      if (T) {
        let C = l.items[l.items.length - 1];
        G(C) && (C = C.value ?? C.key), C.comment ? C.comment += `
` + T : C.comment = T, E.comment = E.comment.substring(T.length + 1);
      }
    }
    if (!o && !w && !E.found) {
      const T = S ? s(t, S, E, i) : e(t, E.end, w, null, E, i);
      l.items.push(T), p = T.range[2], Qs(S) && i(T.range, "BLOCK_IN_FLOW", Xs);
    } else {
      t.atKey = !0;
      const T = E.end, C = I ? s(t, I, E, i) : e(t, T, L, null, E, i);
      Qs(I) && i(C.range, "BLOCK_IN_FLOW", Xs), t.atKey = !1;
      const M = ht(w ?? [], {
        flow: a,
        indicator: "map-value-ind",
        next: S,
        offset: C.range[2],
        onError: i,
        parentIndent: n.indent,
        startOnNewline: !1
      });
      if (M.found) {
        if (!o && !E.found && t.options.strict) {
          if (w)
            for (const U of w) {
              if (U === M.found)
                break;
              if (U.type === "newline") {
                i(U, "MULTILINE_IMPLICIT_KEY", "Implicit keys of flow sequence pairs need to be on a single line");
                break;
              }
            }
          E.start < M.found.offset - 1024 && i(M.found, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit flow sequence key");
        }
      } else S && ("source" in S && ((y = S.source) == null ? void 0 : y[0]) === ":" ? i(S, "MISSING_CHAR", `Missing space after : in ${a}`) : i(M.start, "MISSING_CHAR", `Missing , or : between ${a} items`));
      const J = S ? s(t, S, M, i) : M.found ? e(t, M.end, w, null, M, i) : null;
      J ? Qs(S) && i(J.range, "BLOCK_IN_FLOW", Xs) : M.comment && (C.comment ? C.comment += `
` + M.comment : C.comment = M.comment);
      const B = new ie(C, J);
      if (t.options.keepSourceTokens && (B.srcToken = k), o) {
        const U = l;
        Jr(t, U.items, C) && i(T, "DUPLICATE_KEY", "Map keys must be unique"), U.items.push(B);
      } else {
        const U = new fe(t.schema);
        U.flow = !0, U.items.push(B);
        const F = (J ?? C).range;
        U.range = [C.range[0], F[1], F[2]], l.items.push(U);
      }
      p = J ? J.range[2] : M.end;
    }
  }
  const h = o ? "}" : "]", [d, ...g] = n.end;
  let m = p;
  if ((d == null ? void 0 : d.source) === h)
    m = d.offset + d.source.length;
  else {
    const A = a[0].toUpperCase() + a.substring(1), k = u ? `${A} must end with a ${h}` : `${A} in block collection must be sufficiently indented and end with a ${h}`;
    i(p, u ? "MISSING_CHAR" : "BAD_INDENT", k), d && d.source.length !== 1 && g.unshift(d);
  }
  if (g.length > 0) {
    const A = jt(g, m, t.options.strict, i);
    A.comment && (l.comment ? l.comment += `
` + A.comment : l.comment = A.comment), l.range = [n.offset, m, A.offset];
  } else
    l.range = [n.offset, m, m];
  return l;
}
function Zs(s, e, t, n, i, r) {
  const o = t.type === "block-map" ? Rl(s, e, t, n, r) : t.type === "block-seq" ? $l(s, e, t, n, r) : Pl(s, e, t, n, r), a = o.constructor;
  return i === "!" || i === a.tagName ? (o.tag = a.tagName, o) : (i && (o.tag = i), o);
}
function Dl(s, e, t, n, i) {
  var h;
  const r = n.tag, o = r ? e.directives.tagName(r.source, (d) => i(r, "TAG_RESOLVE_FAILED", d)) : null;
  if (t.type === "block-seq") {
    const { anchor: d, newlineAfterProp: g } = n, m = d && r ? d.offset > r.offset ? d : r : d ?? r;
    m && (!g || g.offset < m.offset) && i(m, "MISSING_CHAR", "Missing newline after block sequence props");
  }
  const a = t.type === "block-map" ? "map" : t.type === "block-seq" ? "seq" : t.start.source === "{" ? "map" : "seq";
  if (!r || !o || o === "!" || o === fe.tagName && a === "map" || o === Ge.tagName && a === "seq")
    return Zs(s, e, t, i, o);
  let c = e.schema.tags.find((d) => d.tag === o && d.collection === a);
  if (!c) {
    const d = e.schema.knownTags[o];
    if ((d == null ? void 0 : d.collection) === a)
      e.schema.tags.push(Object.assign({}, d, { default: !1 })), c = d;
    else
      return d ? i(r, "BAD_COLLECTION_TYPE", `${d.tag} used for ${a} collection, but expects ${d.collection ?? "scalar"}`, !0) : i(r, "TAG_RESOLVE_FAILED", `Unresolved tag: ${o}`, !0), Zs(s, e, t, i, o);
  }
  const l = Zs(s, e, t, i, o, c), u = ((h = c.resolve) == null ? void 0 : h.call(c, l, (d) => i(r, "TAG_RESOLVE_FAILED", d), e.options)) ?? l, p = K(u) ? u : new v(u);
  return p.range = l.range, p.tag = o, c != null && c.format && (p.format = c.format), p;
}
function Ml(s, e, t) {
  const n = e.offset, i = Bl(e, s.options.strict, t);
  if (!i)
    return { value: "", type: null, comment: "", range: [n, n, n] };
  const r = i.mode === ">" ? v.BLOCK_FOLDED : v.BLOCK_LITERAL, o = e.source ? Fl(e.source) : [];
  let a = o.length;
  for (let m = o.length - 1; m >= 0; --m) {
    const y = o[m][1];
    if (y === "" || y === "\r")
      a = m;
    else
      break;
  }
  if (a === 0) {
    const m = i.chomp === "+" && o.length > 0 ? `
`.repeat(Math.max(1, o.length - 1)) : "";
    let y = n + i.length;
    return e.source && (y += e.source.length), { value: m, type: r, comment: i.comment, range: [n, y, y] };
  }
  let c = e.indent + i.indent, l = e.offset + i.length, u = 0;
  for (let m = 0; m < a; ++m) {
    const [y, A] = o[m];
    if (A === "" || A === "\r")
      i.indent === 0 && y.length > c && (c = y.length);
    else {
      y.length < c && t(l + y.length, "MISSING_CHAR", "Block scalars with more-indented leading empty lines must use an explicit indentation indicator"), i.indent === 0 && (c = y.length), u = m, c === 0 && !s.atRoot && t(l, "BAD_INDENT", "Block scalar values in collections must be indented");
      break;
    }
    l += y.length + A.length + 1;
  }
  for (let m = o.length - 1; m >= a; --m)
    o[m][0].length > c && (a = m + 1);
  let p = "", h = "", d = !1;
  for (let m = 0; m < u; ++m)
    p += o[m][0].slice(c) + `
`;
  for (let m = u; m < a; ++m) {
    let [y, A] = o[m];
    l += y.length + A.length + 1;
    const k = A[A.length - 1] === "\r";
    if (k && (A = A.slice(0, -1)), A && y.length < c) {
      const I = `Block scalar lines must not be less indented than their ${i.indent ? "explicit indentation indicator" : "first line"}`;
      t(l - A.length - (k ? 2 : 1), "BAD_INDENT", I), y = "";
    }
    r === v.BLOCK_LITERAL ? (p += h + y.slice(c) + A, h = `
`) : y.length > c || A[0] === "	" ? (h === " " ? h = `
` : !d && h === `
` && (h = `

`), p += h + y.slice(c) + A, h = `
`, d = !0) : A === "" ? h === `
` ? p += `
` : h = `
` : (p += h + A, h = " ", d = !1);
  }
  switch (i.chomp) {
    case "-":
      break;
    case "+":
      for (let m = a; m < o.length; ++m)
        p += `
` + o[m][0].slice(c);
      p[p.length - 1] !== `
` && (p += `
`);
      break;
    default:
      p += `
`;
  }
  const g = n + i.length + e.source.length;
  return { value: p, type: r, comment: i.comment, range: [n, g, g] };
}
function Bl({ offset: s, props: e }, t, n) {
  if (e[0].type !== "block-scalar-header")
    return n(e[0], "IMPOSSIBLE", "Block scalar header not found"), null;
  const { source: i } = e[0], r = i[0];
  let o = 0, a = "", c = -1;
  for (let h = 1; h < i.length; ++h) {
    const d = i[h];
    if (!a && (d === "-" || d === "+"))
      a = d;
    else {
      const g = Number(d);
      !o && g ? o = g : c === -1 && (c = s + h);
    }
  }
  c !== -1 && n(c, "UNEXPECTED_TOKEN", `Block scalar header includes extra characters: ${i}`);
  let l = !1, u = "", p = i.length;
  for (let h = 1; h < e.length; ++h) {
    const d = e[h];
    switch (d.type) {
      case "space":
        l = !0;
      // fallthrough
      case "newline":
        p += d.source.length;
        break;
      case "comment":
        t && !l && n(d, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters"), p += d.source.length, u = d.source.substring(1);
        break;
      case "error":
        n(d, "UNEXPECTED_TOKEN", d.message), p += d.source.length;
        break;
      /* istanbul ignore next should not happen */
      default: {
        const g = `Unexpected token in block scalar header: ${d.type}`;
        n(d, "UNEXPECTED_TOKEN", g);
        const m = d.source;
        m && typeof m == "string" && (p += m.length);
      }
    }
  }
  return { mode: r, indent: o, chomp: a, comment: u, length: p };
}
function Fl(s) {
  const e = s.split(/\n( *)/), t = e[0], n = t.match(/^( *)/), r = [n != null && n[1] ? [n[1], t.slice(n[1].length)] : ["", t]];
  for (let o = 1; o < e.length; o += 2)
    r.push([e[o], e[o + 1]]);
  return r;
}
function jl(s, e, t) {
  const { offset: n, type: i, source: r, end: o } = s;
  let a, c;
  const l = (h, d, g) => t(n + h, d, g);
  switch (i) {
    case "scalar":
      a = v.PLAIN, c = Ul(r, l);
      break;
    case "single-quoted-scalar":
      a = v.QUOTE_SINGLE, c = zl(r, l);
      break;
    case "double-quoted-scalar":
      a = v.QUOTE_DOUBLE, c = ql(r, l);
      break;
    /* istanbul ignore next should not happen */
    default:
      return t(s, "UNEXPECTED_TOKEN", `Expected a flow scalar value, but found: ${i}`), {
        value: "",
        type: null,
        comment: "",
        range: [n, n + r.length, n + r.length]
      };
  }
  const u = n + r.length, p = jt(o, u, e, t);
  return {
    value: c,
    type: a,
    comment: p.comment,
    range: [n, u, p.offset]
  };
}
function Ul(s, e) {
  let t = "";
  switch (s[0]) {
    /* istanbul ignore next should not happen */
    case "	":
      t = "a tab character";
      break;
    case ",":
      t = "flow indicator character ,";
      break;
    case "%":
      t = "directive indicator character %";
      break;
    case "|":
    case ">": {
      t = `block scalar indicator ${s[0]}`;
      break;
    }
    case "@":
    case "`": {
      t = `reserved character ${s[0]}`;
      break;
    }
  }
  return t && e(0, "BAD_SCALAR_START", `Plain value cannot start with ${t}`), Xr(s);
}
function zl(s, e) {
  return (s[s.length - 1] !== "'" || s.length === 1) && e(s.length, "MISSING_CHAR", "Missing closing 'quote"), Xr(s.slice(1, -1)).replace(/''/g, "'");
}
function Xr(s) {
  let e, t;
  try {
    e = new RegExp(`(.*?)(?<![ 	])[ 	]*\r?
`, "sy"), t = new RegExp(`[ 	]*(.*?)(?:(?<![ 	])[ 	]*)?\r?
`, "sy");
  } catch {
    e = /(.*?)[ \t]*\r?\n/sy, t = /[ \t]*(.*?)[ \t]*\r?\n/sy;
  }
  let n = e.exec(s);
  if (!n)
    return s;
  let i = n[1], r = " ", o = e.lastIndex;
  for (t.lastIndex = o; n = t.exec(s); )
    n[1] === "" ? r === `
` ? i += r : r = `
` : (i += r + n[1], r = " "), o = t.lastIndex;
  const a = /[ \t]*(.*)/sy;
  return a.lastIndex = o, n = a.exec(s), i + r + ((n == null ? void 0 : n[1]) ?? "");
}
function ql(s, e) {
  let t = "";
  for (let n = 1; n < s.length - 1; ++n) {
    const i = s[n];
    if (!(i === "\r" && s[n + 1] === `
`))
      if (i === `
`) {
        const { fold: r, offset: o } = Kl(s, n);
        t += r, n = o;
      } else if (i === "\\") {
        let r = s[++n];
        const o = Gl[r];
        if (o)
          t += o;
        else if (r === `
`)
          for (r = s[n + 1]; r === " " || r === "	"; )
            r = s[++n + 1];
        else if (r === "\r" && s[n + 1] === `
`)
          for (r = s[++n + 1]; r === " " || r === "	"; )
            r = s[++n + 1];
        else if (r === "x" || r === "u" || r === "U") {
          const a = r === "x" ? 2 : r === "u" ? 4 : 8;
          t += Hl(s, n + 1, a, e), n += a;
        } else {
          const a = s.substr(n - 1, 2);
          e(n - 1, "BAD_DQ_ESCAPE", `Invalid escape sequence ${a}`), t += a;
        }
      } else if (i === " " || i === "	") {
        const r = n;
        let o = s[n + 1];
        for (; o === " " || o === "	"; )
          o = s[++n + 1];
        o !== `
` && !(o === "\r" && s[n + 2] === `
`) && (t += n > r ? s.slice(r, n + 1) : i);
      } else
        t += i;
  }
  return (s[s.length - 1] !== '"' || s.length === 1) && e(s.length, "MISSING_CHAR", 'Missing closing "quote'), t;
}
function Kl(s, e) {
  let t = "", n = s[e + 1];
  for (; (n === " " || n === "	" || n === `
` || n === "\r") && !(n === "\r" && s[e + 2] !== `
`); )
    n === `
` && (t += `
`), e += 1, n = s[e + 1];
  return t || (t = " "), { fold: t, offset: e };
}
const Gl = {
  0: "\0",
  // null character
  a: "\x07",
  // bell character
  b: "\b",
  // backspace
  e: "\x1B",
  // escape character
  f: "\f",
  // form feed
  n: `
`,
  // line feed
  r: "\r",
  // carriage return
  t: "	",
  // horizontal tab
  v: "\v",
  // vertical tab
  N: "",
  // Unicode next line
  _: " ",
  // Unicode non-breaking space
  L: "\u2028",
  // Unicode line separator
  P: "\u2029",
  // Unicode paragraph separator
  " ": " ",
  '"': '"',
  "/": "/",
  "\\": "\\",
  "	": "	"
};
function Hl(s, e, t, n) {
  const i = s.substr(e, t), o = i.length === t && /^[0-9a-fA-F]+$/.test(i) ? parseInt(i, 16) : NaN;
  try {
    return String.fromCodePoint(o);
  } catch {
    const a = s.substr(e - 2, t + 2);
    return n(e - 2, "BAD_DQ_ESCAPE", `Invalid escape sequence ${a}`), a;
  }
}
function Qr(s, e, t, n) {
  const { value: i, type: r, comment: o, range: a } = e.type === "block-scalar" ? Ml(s, e, n) : jl(e, s.options.strict, n), c = t ? s.directives.tagName(t.source, (p) => n(t, "TAG_RESOLVE_FAILED", p)) : null;
  let l;
  s.options.stringKeys && s.atKey ? l = s.schema[Ae] : c ? l = Vl(s.schema, i, c, t, n) : e.type === "scalar" ? l = Wl(s, i, e, n) : l = s.schema[Ae];
  let u;
  try {
    const p = l.resolve(i, (h) => n(t ?? e, "TAG_RESOLVE_FAILED", h), s.options);
    u = D(p) ? p : new v(p);
  } catch (p) {
    const h = p instanceof Error ? p.message : String(p);
    n(t ?? e, "TAG_RESOLVE_FAILED", h), u = new v(i);
  }
  return u.range = a, u.source = i, r && (u.type = r), c && (u.tag = c), l.format && (u.format = l.format), o && (u.comment = o), u;
}
function Vl(s, e, t, n, i) {
  var a;
  if (t === "!")
    return s[Ae];
  const r = [];
  for (const c of s.tags)
    if (!c.collection && c.tag === t)
      if (c.default && c.test)
        r.push(c);
      else
        return c;
  for (const c of r)
    if ((a = c.test) != null && a.test(e))
      return c;
  const o = s.knownTags[t];
  return o && !o.collection ? (s.tags.push(Object.assign({}, o, { default: !1, test: void 0 })), o) : (i(n, "TAG_RESOLVE_FAILED", `Unresolved tag: ${t}`, t !== "tag:yaml.org,2002:str"), s[Ae]);
}
function Wl({ atKey: s, directives: e, schema: t }, n, i, r) {
  const o = t.tags.find((a) => {
    var c;
    return (a.default === !0 || s && a.default === "key") && ((c = a.test) == null ? void 0 : c.test(n));
  }) || t[Ae];
  if (t.compat) {
    const a = t.compat.find((c) => {
      var l;
      return c.default && ((l = c.test) == null ? void 0 : l.test(n));
    }) ?? t[Ae];
    if (o.tag !== a.tag) {
      const c = e.tagString(o.tag), l = e.tagString(a.tag), u = `Value may be parsed as either ${c} or ${l}`;
      r(i, "TAG_RESOLVE_FAILED", u, !0);
    }
  }
  return o;
}
function Yl(s, e, t) {
  if (e) {
    t ?? (t = e.length);
    for (let n = t - 1; n >= 0; --n) {
      let i = e[n];
      switch (i.type) {
        case "space":
        case "comment":
        case "newline":
          s -= i.source.length;
          continue;
      }
      for (i = e[++n]; (i == null ? void 0 : i.type) === "space"; )
        s += i.source.length, i = e[++n];
      break;
    }
  }
  return s;
}
const Jl = { composeNode: Zr, composeEmptyNode: zn };
function Zr(s, e, t, n) {
  const i = s.atKey, { spaceBefore: r, comment: o, anchor: a, tag: c } = t;
  let l, u = !0;
  switch (e.type) {
    case "alias":
      l = Xl(s, e, n), (a || c) && n(e, "ALIAS_PROPS", "An alias node must not specify any properties");
      break;
    case "scalar":
    case "single-quoted-scalar":
    case "double-quoted-scalar":
    case "block-scalar":
      l = Qr(s, e, c, n), a && (l.anchor = a.source.substring(1));
      break;
    case "block-map":
    case "block-seq":
    case "flow-collection":
      try {
        l = Dl(Jl, s, e, t, n), a && (l.anchor = a.source.substring(1));
      } catch (p) {
        const h = p instanceof Error ? p.message : String(p);
        n(e, "RESOURCE_EXHAUSTION", h);
      }
      break;
    default: {
      const p = e.type === "error" ? e.message : `Unsupported token (type: ${e.type})`;
      n(e, "UNEXPECTED_TOKEN", p), u = !1;
    }
  }
  return l ?? (l = zn(s, e.offset, void 0, null, t, n)), a && l.anchor === "" && n(a, "BAD_ALIAS", "Anchor cannot be an empty string"), i && s.options.stringKeys && (!D(l) || typeof l.value != "string" || l.tag && l.tag !== "tag:yaml.org,2002:str") && n(c ?? e, "NON_STRING_KEY", "With stringKeys, all keys must be strings"), r && (l.spaceBefore = !0), o && (e.type === "scalar" && e.source === "" ? l.comment = o : l.commentBefore = o), s.options.keepSourceTokens && u && (l.srcToken = e), l;
}
function zn(s, e, t, n, { spaceBefore: i, comment: r, anchor: o, tag: a, end: c }, l) {
  const u = {
    type: "scalar",
    offset: Yl(e, t, n),
    indent: -1,
    source: ""
  }, p = Qr(s, u, a, l);
  return o && (p.anchor = o.source.substring(1), p.anchor === "" && l(o, "BAD_ALIAS", "Anchor cannot be an empty string")), i && (p.spaceBefore = !0), r && (p.comment = r, p.range[2] = c), p;
}
function Xl({ options: s }, { offset: e, source: t, end: n }, i) {
  const r = new vn(t.substring(1));
  r.source === "" && i(e, "BAD_ALIAS", "Alias cannot be an empty string"), r.source.endsWith(":") && i(e + t.length - 1, "BAD_ALIAS", "Alias ending in : is ambiguous", !0);
  const o = e + t.length, a = jt(n, o, s.strict, i);
  return r.range = [e, o, a.offset], a.comment && (r.comment = a.comment), r;
}
function Ql(s, e, { offset: t, start: n, value: i, end: r }, o) {
  const a = Object.assign({ _directives: e }, s), c = new Is(void 0, a), l = {
    atKey: !1,
    atRoot: !0,
    directives: c.directives,
    options: c.options,
    schema: c.schema
  }, u = ht(n, {
    indicator: "doc-start",
    next: i ?? (r == null ? void 0 : r[0]),
    offset: t,
    onError: o,
    parentIndent: 0,
    startOnNewline: !0
  });
  u.found && (c.directives.docStart = !0, i && (i.type === "block-map" || i.type === "block-seq") && !u.hasNewline && o(u.end, "MISSING_CHAR", "Block collection cannot start on same line with directives-end marker")), c.contents = i ? Zr(l, i, u, o) : zn(l, u.end, n, null, u, o);
  const p = c.contents.range[2], h = jt(r, p, !1, o);
  return h.comment && (c.comment = h.comment), c.range = [t, p, h.offset], c;
}
function Lt(s) {
  if (typeof s == "number")
    return [s, s + 1];
  if (Array.isArray(s))
    return s.length === 2 ? s : [s[0], s[1]];
  const { offset: e, source: t } = s;
  return [e, e + (typeof t == "string" ? t.length : 1)];
}
function ji(s) {
  var i;
  let e = "", t = !1, n = !1;
  for (let r = 0; r < s.length; ++r) {
    const o = s[r];
    switch (o[0]) {
      case "#":
        e += (e === "" ? "" : n ? `

` : `
`) + (o.substring(1) || " "), t = !0, n = !1;
        break;
      case "%":
        ((i = s[r + 1]) == null ? void 0 : i[0]) !== "#" && (r += 1), t = !1;
        break;
      default:
        t || (n = !0), t = !1;
    }
  }
  return { comment: e, afterEmptyLine: n };
}
class Zl {
  constructor(e = {}) {
    this.doc = null, this.atDirectives = !1, this.prelude = [], this.errors = [], this.warnings = [], this.onError = (t, n, i, r) => {
      const o = Lt(t);
      r ? this.warnings.push(new Cl(o, n, i)) : this.errors.push(new Ot(o, n, i));
    }, this.directives = new se({ version: e.version || "1.2" }), this.options = e;
  }
  decorate(e, t) {
    const { comment: n, afterEmptyLine: i } = ji(this.prelude);
    if (n) {
      const r = e.contents;
      if (t)
        e.comment = e.comment ? `${e.comment}
${n}` : n;
      else if (i || e.directives.docStart || !r)
        e.commentBefore = n;
      else if (q(r) && !r.flow && r.items.length > 0) {
        let o = r.items[0];
        G(o) && (o = o.key);
        const a = o.commentBefore;
        o.commentBefore = a ? `${n}
${a}` : n;
      } else {
        const o = r.commentBefore;
        r.commentBefore = o ? `${n}
${o}` : n;
      }
    }
    if (t) {
      for (let r = 0; r < this.errors.length; ++r)
        e.errors.push(this.errors[r]);
      for (let r = 0; r < this.warnings.length; ++r)
        e.warnings.push(this.warnings[r]);
    } else
      e.errors = this.errors, e.warnings = this.warnings;
    this.prelude = [], this.errors = [], this.warnings = [];
  }
  /**
   * Current stream status information.
   *
   * Mostly useful at the end of input for an empty stream.
   */
  streamInfo() {
    return {
      comment: ji(this.prelude).comment,
      directives: this.directives,
      errors: this.errors,
      warnings: this.warnings
    };
  }
  /**
   * Compose tokens into documents.
   *
   * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
   * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
   */
  *compose(e, t = !1, n = -1) {
    for (const i of e)
      yield* this.next(i);
    yield* this.end(t, n);
  }
  /** Advance the composer by one CST token. */
  *next(e) {
    switch (e.type) {
      case "directive":
        this.directives.add(e.source, (t, n, i) => {
          const r = Lt(e);
          r[0] += t, this.onError(r, "BAD_DIRECTIVE", n, i);
        }), this.prelude.push(e.source), this.atDirectives = !0;
        break;
      case "document": {
        const t = Ql(this.options, this.directives, e, this.onError);
        this.atDirectives && !t.directives.docStart && this.onError(e, "MISSING_CHAR", "Missing directives-end/doc-start indicator line"), this.decorate(t, !1), this.doc && (yield this.doc), this.doc = t, this.atDirectives = !1;
        break;
      }
      case "byte-order-mark":
      case "space":
        break;
      case "comment":
      case "newline":
        this.prelude.push(e.source);
        break;
      case "error": {
        const t = e.source ? `${e.message}: ${JSON.stringify(e.source)}` : e.message, n = new Ot(Lt(e), "UNEXPECTED_TOKEN", t);
        this.atDirectives || !this.doc ? this.errors.push(n) : this.doc.errors.push(n);
        break;
      }
      case "doc-end": {
        if (!this.doc) {
          const n = "Unexpected doc-end without preceding document";
          this.errors.push(new Ot(Lt(e), "UNEXPECTED_TOKEN", n));
          break;
        }
        this.doc.directives.docEnd = !0;
        const t = jt(e.end, e.offset + e.source.length, this.doc.options.strict, this.onError);
        if (this.decorate(this.doc, !0), t.comment) {
          const n = this.doc.comment;
          this.doc.comment = n ? `${n}
${t.comment}` : t.comment;
        }
        this.doc.range[2] = t.offset;
        break;
      }
      default:
        this.errors.push(new Ot(Lt(e), "UNEXPECTED_TOKEN", `Unsupported token ${e.type}`));
    }
  }
  /**
   * Call at end of input to yield any remaining document.
   *
   * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
   * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
   */
  *end(e = !1, t = -1) {
    if (this.doc)
      this.decorate(this.doc, !0), yield this.doc, this.doc = null;
    else if (e) {
      const n = Object.assign({ _directives: this.directives }, this.options), i = new Is(void 0, n);
      this.atDirectives && this.onError(t, "MISSING_CHAR", "Missing directives-end indicator line"), i.range = [0, t, t], this.decorate(i, !1), yield i;
    }
  }
}
const eo = "\uFEFF", to = "", so = "", mn = "";
function ec(s) {
  switch (s) {
    case eo:
      return "byte-order-mark";
    case to:
      return "doc-mode";
    case so:
      return "flow-error-end";
    case mn:
      return "scalar";
    case "---":
      return "doc-start";
    case "...":
      return "doc-end";
    case "":
    case `
`:
    case `\r
`:
      return "newline";
    case "-":
      return "seq-item-ind";
    case "?":
      return "explicit-key-ind";
    case ":":
      return "map-value-ind";
    case "{":
      return "flow-map-start";
    case "}":
      return "flow-map-end";
    case "[":
      return "flow-seq-start";
    case "]":
      return "flow-seq-end";
    case ",":
      return "comma";
  }
  switch (s[0]) {
    case " ":
    case "	":
      return "space";
    case "#":
      return "comment";
    case "%":
      return "directive-line";
    case "*":
      return "alias";
    case "&":
      return "anchor";
    case "!":
      return "tag";
    case "'":
      return "single-quoted-scalar";
    case '"':
      return "double-quoted-scalar";
    case "|":
    case ">":
      return "block-scalar-header";
  }
  return null;
}
function ge(s) {
  switch (s) {
    case void 0:
    case " ":
    case `
`:
    case "\r":
    case "	":
      return !0;
    default:
      return !1;
  }
}
const Ui = new Set("0123456789ABCDEFabcdef"), tc = new Set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-#;/?:@&=+$_.!~*'()"), ts = new Set(",[]{}"), sc = new Set(` ,[]{}
\r	`), en = (s) => !s || sc.has(s);
class nc {
  constructor() {
    this.atEnd = !1, this.blockScalarIndent = -1, this.blockScalarKeep = !1, this.buffer = "", this.flowKey = !1, this.flowLevel = 0, this.indentNext = 0, this.indentValue = 0, this.lineEndPos = null, this.next = null, this.pos = 0;
  }
  /**
   * Generate YAML tokens from the `source` string. If `incomplete`,
   * a part of the last line may be left as a buffer for the next call.
   *
   * @returns A generator of lexical tokens
   */
  *lex(e, t = !1) {
    if (e) {
      if (typeof e != "string")
        throw TypeError("source is not a string");
      this.buffer = this.buffer ? this.buffer + e : e, this.lineEndPos = null;
    }
    this.atEnd = !t;
    let n = this.next ?? "stream";
    for (; n && (t || this.hasChars(1)); )
      n = yield* this.parseNext(n);
  }
  atLineEnd() {
    let e = this.pos, t = this.buffer[e];
    for (; t === " " || t === "	"; )
      t = this.buffer[++e];
    return !t || t === "#" || t === `
` ? !0 : t === "\r" ? this.buffer[e + 1] === `
` : !1;
  }
  charAt(e) {
    return this.buffer[this.pos + e];
  }
  continueScalar(e) {
    let t = this.buffer[e];
    if (this.indentNext > 0) {
      let n = 0;
      for (; t === " "; )
        t = this.buffer[++n + e];
      if (t === "\r") {
        const i = this.buffer[n + e + 1];
        if (i === `
` || !i && !this.atEnd)
          return e + n + 1;
      }
      return t === `
` || n >= this.indentNext || !t && !this.atEnd ? e + n : -1;
    }
    if (t === "-" || t === ".") {
      const n = this.buffer.substr(e, 3);
      if ((n === "---" || n === "...") && ge(this.buffer[e + 3]))
        return -1;
    }
    return e;
  }
  getLine() {
    let e = this.lineEndPos;
    return (typeof e != "number" || e !== -1 && e < this.pos) && (e = this.buffer.indexOf(`
`, this.pos), this.lineEndPos = e), e === -1 ? this.atEnd ? this.buffer.substring(this.pos) : null : (this.buffer[e - 1] === "\r" && (e -= 1), this.buffer.substring(this.pos, e));
  }
  hasChars(e) {
    return this.pos + e <= this.buffer.length;
  }
  setNext(e) {
    return this.buffer = this.buffer.substring(this.pos), this.pos = 0, this.lineEndPos = null, this.next = e, null;
  }
  peek(e) {
    return this.buffer.substr(this.pos, e);
  }
  *parseNext(e) {
    switch (e) {
      case "stream":
        return yield* this.parseStream();
      case "line-start":
        return yield* this.parseLineStart();
      case "block-start":
        return yield* this.parseBlockStart();
      case "doc":
        return yield* this.parseDocument();
      case "flow":
        return yield* this.parseFlowCollection();
      case "quoted-scalar":
        return yield* this.parseQuotedScalar();
      case "block-scalar":
        return yield* this.parseBlockScalar();
      case "plain-scalar":
        return yield* this.parsePlainScalar();
    }
  }
  *parseStream() {
    let e = this.getLine();
    if (e === null)
      return this.setNext("stream");
    if (e[0] === eo && (yield* this.pushCount(1), e = e.substring(1)), e[0] === "%") {
      let t = e.length, n = e.indexOf("#");
      for (; n !== -1; ) {
        const r = e[n - 1];
        if (r === " " || r === "	") {
          t = n - 1;
          break;
        } else
          n = e.indexOf("#", n + 1);
      }
      for (; ; ) {
        const r = e[t - 1];
        if (r === " " || r === "	")
          t -= 1;
        else
          break;
      }
      const i = (yield* this.pushCount(t)) + (yield* this.pushSpaces(!0));
      return yield* this.pushCount(e.length - i), this.pushNewline(), "stream";
    }
    if (this.atLineEnd()) {
      const t = yield* this.pushSpaces(!0);
      return yield* this.pushCount(e.length - t), yield* this.pushNewline(), "stream";
    }
    return yield to, yield* this.parseLineStart();
  }
  *parseLineStart() {
    const e = this.charAt(0);
    if (!e && !this.atEnd)
      return this.setNext("line-start");
    if (e === "-" || e === ".") {
      if (!this.atEnd && !this.hasChars(4))
        return this.setNext("line-start");
      const t = this.peek(3);
      if ((t === "---" || t === "...") && ge(this.charAt(3)))
        return yield* this.pushCount(3), this.indentValue = 0, this.indentNext = 0, t === "---" ? "doc" : "stream";
    }
    return this.indentValue = yield* this.pushSpaces(!1), this.indentNext > this.indentValue && !ge(this.charAt(1)) && (this.indentNext = this.indentValue), yield* this.parseBlockStart();
  }
  *parseBlockStart() {
    const [e, t] = this.peek(2);
    if (!t && !this.atEnd)
      return this.setNext("block-start");
    if ((e === "-" || e === "?" || e === ":") && ge(t)) {
      const n = (yield* this.pushCount(1)) + (yield* this.pushSpaces(!0));
      return this.indentNext = this.indentValue + 1, this.indentValue += n, "block-start";
    }
    return "doc";
  }
  *parseDocument() {
    yield* this.pushSpaces(!0);
    const e = this.getLine();
    if (e === null)
      return this.setNext("doc");
    let t = yield* this.pushIndicators();
    switch (e[t]) {
      case "#":
        yield* this.pushCount(e.length - t);
      // fallthrough
      case void 0:
        return yield* this.pushNewline(), yield* this.parseLineStart();
      case "{":
      case "[":
        return yield* this.pushCount(1), this.flowKey = !1, this.flowLevel = 1, "flow";
      case "}":
      case "]":
        return yield* this.pushCount(1), "doc";
      case "*":
        return yield* this.pushUntil(en), "doc";
      case '"':
      case "'":
        return yield* this.parseQuotedScalar();
      case "|":
      case ">":
        return t += yield* this.parseBlockScalarHeader(), t += yield* this.pushSpaces(!0), yield* this.pushCount(e.length - t), yield* this.pushNewline(), yield* this.parseBlockScalar();
      default:
        return yield* this.parsePlainScalar();
    }
  }
  *parseFlowCollection() {
    let e, t, n = -1;
    do
      e = yield* this.pushNewline(), e > 0 ? (t = yield* this.pushSpaces(!1), this.indentValue = n = t) : t = 0, t += yield* this.pushSpaces(!0);
    while (e + t > 0);
    const i = this.getLine();
    if (i === null)
      return this.setNext("flow");
    if ((n !== -1 && n < this.indentNext && i[0] !== "#" || n === 0 && (i.startsWith("---") || i.startsWith("...")) && ge(i[3])) && !(n === this.indentNext - 1 && this.flowLevel === 1 && (i[0] === "]" || i[0] === "}")))
      return this.flowLevel = 0, yield so, yield* this.parseLineStart();
    let r = 0;
    for (; i[r] === ","; )
      r += yield* this.pushCount(1), r += yield* this.pushSpaces(!0), this.flowKey = !1;
    switch (r += yield* this.pushIndicators(), i[r]) {
      case void 0:
        return "flow";
      case "#":
        return yield* this.pushCount(i.length - r), "flow";
      case "{":
      case "[":
        return yield* this.pushCount(1), this.flowKey = !1, this.flowLevel += 1, "flow";
      case "}":
      case "]":
        return yield* this.pushCount(1), this.flowKey = !0, this.flowLevel -= 1, this.flowLevel ? "flow" : "doc";
      case "*":
        return yield* this.pushUntil(en), "flow";
      case '"':
      case "'":
        return this.flowKey = !0, yield* this.parseQuotedScalar();
      case ":": {
        const o = this.charAt(1);
        if (this.flowKey || ge(o) || o === ",")
          return this.flowKey = !1, yield* this.pushCount(1), yield* this.pushSpaces(!0), "flow";
      }
      // fallthrough
      default:
        return this.flowKey = !1, yield* this.parsePlainScalar();
    }
  }
  *parseQuotedScalar() {
    const e = this.charAt(0);
    let t = this.buffer.indexOf(e, this.pos + 1);
    if (e === "'")
      for (; t !== -1 && this.buffer[t + 1] === "'"; )
        t = this.buffer.indexOf("'", t + 2);
    else
      for (; t !== -1; ) {
        let r = 0;
        for (; this.buffer[t - 1 - r] === "\\"; )
          r += 1;
        if (r % 2 === 0)
          break;
        t = this.buffer.indexOf('"', t + 1);
      }
    const n = this.buffer.substring(0, t);
    let i = n.indexOf(`
`, this.pos);
    if (i !== -1) {
      for (; i !== -1; ) {
        const r = this.continueScalar(i + 1);
        if (r === -1)
          break;
        i = n.indexOf(`
`, r);
      }
      i !== -1 && (t = i - (n[i - 1] === "\r" ? 2 : 1));
    }
    if (t === -1) {
      if (!this.atEnd)
        return this.setNext("quoted-scalar");
      t = this.buffer.length;
    }
    return yield* this.pushToIndex(t + 1, !1), this.flowLevel ? "flow" : "doc";
  }
  *parseBlockScalarHeader() {
    this.blockScalarIndent = -1, this.blockScalarKeep = !1;
    let e = this.pos;
    for (; ; ) {
      const t = this.buffer[++e];
      if (t === "+")
        this.blockScalarKeep = !0;
      else if (t > "0" && t <= "9")
        this.blockScalarIndent = Number(t) - 1;
      else if (t !== "-")
        break;
    }
    return yield* this.pushUntil((t) => ge(t) || t === "#");
  }
  *parseBlockScalar() {
    let e = this.pos - 1, t = 0, n;
    e: for (let r = this.pos; n = this.buffer[r]; ++r)
      switch (n) {
        case " ":
          t += 1;
          break;
        case `
`:
          e = r, t = 0;
          break;
        case "\r": {
          const o = this.buffer[r + 1];
          if (!o && !this.atEnd)
            return this.setNext("block-scalar");
          if (o === `
`)
            break;
        }
        // fallthrough
        default:
          break e;
      }
    if (!n && !this.atEnd)
      return this.setNext("block-scalar");
    if (t >= this.indentNext) {
      this.blockScalarIndent === -1 ? this.indentNext = t : this.indentNext = this.blockScalarIndent + (this.indentNext === 0 ? 1 : this.indentNext);
      do {
        const r = this.continueScalar(e + 1);
        if (r === -1)
          break;
        e = this.buffer.indexOf(`
`, r);
      } while (e !== -1);
      if (e === -1) {
        if (!this.atEnd)
          return this.setNext("block-scalar");
        e = this.buffer.length;
      }
    }
    let i = e + 1;
    for (n = this.buffer[i]; n === " "; )
      n = this.buffer[++i];
    if (n === "	") {
      for (; n === "	" || n === " " || n === "\r" || n === `
`; )
        n = this.buffer[++i];
      e = i - 1;
    } else if (!this.blockScalarKeep)
      do {
        let r = e - 1, o = this.buffer[r];
        o === "\r" && (o = this.buffer[--r]);
        const a = r;
        for (; o === " "; )
          o = this.buffer[--r];
        if (o === `
` && r >= this.pos && r + 1 + t > a)
          e = r;
        else
          break;
      } while (!0);
    return yield mn, yield* this.pushToIndex(e + 1, !0), yield* this.parseLineStart();
  }
  *parsePlainScalar() {
    const e = this.flowLevel > 0;
    let t = this.pos - 1, n = this.pos - 1, i;
    for (; i = this.buffer[++n]; )
      if (i === ":") {
        const r = this.buffer[n + 1];
        if (ge(r) || e && ts.has(r))
          break;
        t = n;
      } else if (ge(i)) {
        let r = this.buffer[n + 1];
        if (i === "\r" && (r === `
` ? (n += 1, i = `
`, r = this.buffer[n + 1]) : t = n), r === "#" || e && ts.has(r))
          break;
        if (i === `
`) {
          const o = this.continueScalar(n + 1);
          if (o === -1)
            break;
          n = Math.max(n, o - 2);
        }
      } else {
        if (e && ts.has(i))
          break;
        t = n;
      }
    return !i && !this.atEnd ? this.setNext("plain-scalar") : (yield mn, yield* this.pushToIndex(t + 1, !0), e ? "flow" : "doc");
  }
  *pushCount(e) {
    return e > 0 ? (yield this.buffer.substr(this.pos, e), this.pos += e, e) : 0;
  }
  *pushToIndex(e, t) {
    const n = this.buffer.slice(this.pos, e);
    return n ? (yield n, this.pos += n.length, n.length) : (t && (yield ""), 0);
  }
  *pushIndicators() {
    let e = 0;
    e: for (; ; ) {
      switch (this.charAt(0)) {
        case "!":
          e += yield* this.pushTag(), e += yield* this.pushSpaces(!0);
          continue e;
        case "&":
          e += yield* this.pushUntil(en), e += yield* this.pushSpaces(!0);
          continue e;
        case "-":
        // this is an error
        case "?":
        // this is an error outside flow collections
        case ":": {
          const t = this.flowLevel > 0, n = this.charAt(1);
          if (ge(n) || t && ts.has(n)) {
            t ? this.flowKey && (this.flowKey = !1) : this.indentNext = this.indentValue + 1, e += yield* this.pushCount(1), e += yield* this.pushSpaces(!0);
            continue e;
          }
        }
      }
      break e;
    }
    return e;
  }
  *pushTag() {
    if (this.charAt(1) === "<") {
      let e = this.pos + 2, t = this.buffer[e];
      for (; !ge(t) && t !== ">"; )
        t = this.buffer[++e];
      return yield* this.pushToIndex(t === ">" ? e + 1 : e, !1);
    } else {
      let e = this.pos + 1, t = this.buffer[e];
      for (; t; )
        if (tc.has(t))
          t = this.buffer[++e];
        else if (t === "%" && Ui.has(this.buffer[e + 1]) && Ui.has(this.buffer[e + 2]))
          t = this.buffer[e += 3];
        else
          break;
      return yield* this.pushToIndex(e, !1);
    }
  }
  *pushNewline() {
    const e = this.buffer[this.pos];
    return e === `
` ? yield* this.pushCount(1) : e === "\r" && this.charAt(1) === `
` ? yield* this.pushCount(2) : 0;
  }
  *pushSpaces(e) {
    let t = this.pos - 1, n;
    do
      n = this.buffer[++t];
    while (n === " " || e && n === "	");
    const i = t - this.pos;
    return i > 0 && (yield this.buffer.substr(this.pos, i), this.pos = t), i;
  }
  *pushUntil(e) {
    let t = this.pos, n = this.buffer[t];
    for (; !e(n); )
      n = this.buffer[++t];
    return yield* this.pushToIndex(t, !1);
  }
}
class ic {
  constructor() {
    this.lineStarts = [], this.addNewLine = (e) => this.lineStarts.push(e), this.linePos = (e) => {
      let t = 0, n = this.lineStarts.length;
      for (; t < n; ) {
        const r = t + n >> 1;
        this.lineStarts[r] < e ? t = r + 1 : n = r;
      }
      if (this.lineStarts[t] === e)
        return { line: t + 1, col: 1 };
      if (t === 0)
        return { line: 0, col: e };
      const i = this.lineStarts[t - 1];
      return { line: t, col: e - i + 1 };
    };
  }
}
function $e(s, e) {
  for (let t = 0; t < s.length; ++t)
    if (s[t].type === e)
      return !0;
  return !1;
}
function zi(s) {
  for (let e = 0; e < s.length; ++e)
    switch (s[e].type) {
      case "space":
      case "comment":
      case "newline":
        break;
      default:
        return e;
    }
  return -1;
}
function no(s) {
  switch (s == null ? void 0 : s.type) {
    case "alias":
    case "scalar":
    case "single-quoted-scalar":
    case "double-quoted-scalar":
    case "flow-collection":
      return !0;
    default:
      return !1;
  }
}
function ss(s) {
  switch (s.type) {
    case "document":
      return s.start;
    case "block-map": {
      const e = s.items[s.items.length - 1];
      return e.sep ?? e.start;
    }
    case "block-seq":
      return s.items[s.items.length - 1].start;
    /* istanbul ignore next should not happen */
    default:
      return [];
  }
}
function it(s) {
  var t;
  if (s.length === 0)
    return [];
  let e = s.length;
  e: for (; --e >= 0; )
    switch (s[e].type) {
      case "doc-start":
      case "explicit-key-ind":
      case "map-value-ind":
      case "seq-item-ind":
      case "newline":
        break e;
    }
  for (; ((t = s[++e]) == null ? void 0 : t.type) === "space"; )
    ;
  return s.splice(e, s.length);
}
function hs(s, e) {
  if (e.length < 1e5)
    Array.prototype.push.apply(s, e);
  else
    for (let t = 0; t < e.length; ++t)
      s.push(e[t]);
}
function qi(s) {
  if (s.start.type === "flow-seq-start")
    for (const e of s.items)
      e.sep && !e.value && !$e(e.start, "explicit-key-ind") && !$e(e.sep, "map-value-ind") && (e.key && (e.value = e.key), delete e.key, no(e.value) ? e.value.end ? hs(e.value.end, e.sep) : e.value.end = e.sep : hs(e.start, e.sep), delete e.sep);
}
class rc {
  /**
   * @param onNewLine - If defined, called separately with the start position of
   *   each new line (in `parse()`, including the start of input).
   */
  constructor(e) {
    this.atNewLine = !0, this.atScalar = !1, this.indent = 0, this.offset = 0, this.onKeyLine = !1, this.stack = [], this.source = "", this.type = "", this.lexer = new nc(), this.onNewLine = e;
  }
  /**
   * Parse `source` as a YAML stream.
   * If `incomplete`, a part of the last line may be left as a buffer for the next call.
   *
   * Errors are not thrown, but yielded as `{ type: 'error', message }` tokens.
   *
   * @returns A generator of tokens representing each directive, document, and other structure.
   */
  *parse(e, t = !1) {
    this.onNewLine && this.offset === 0 && this.onNewLine(0);
    for (const n of this.lexer.lex(e, t))
      yield* this.next(n);
    t || (yield* this.end());
  }
  /**
   * Advance the parser by the `source` of one lexical token.
   */
  *next(e) {
    if (this.source = e, this.atScalar) {
      this.atScalar = !1, yield* this.step(), this.offset += e.length;
      return;
    }
    const t = ec(e);
    if (t)
      if (t === "scalar")
        this.atNewLine = !1, this.atScalar = !0, this.type = "scalar";
      else {
        switch (this.type = t, yield* this.step(), t) {
          case "newline":
            this.atNewLine = !0, this.indent = 0, this.onNewLine && this.onNewLine(this.offset + e.length);
            break;
          case "space":
            this.atNewLine && e[0] === " " && (this.indent += e.length);
            break;
          case "explicit-key-ind":
          case "map-value-ind":
          case "seq-item-ind":
            this.atNewLine && (this.indent += e.length);
            break;
          case "doc-mode":
          case "flow-error-end":
            return;
          default:
            this.atNewLine = !1;
        }
        this.offset += e.length;
      }
    else {
      const n = `Not a YAML token: ${e}`;
      yield* this.pop({ type: "error", offset: this.offset, message: n, source: e }), this.offset += e.length;
    }
  }
  /** Call at end of input to push out any remaining constructions */
  *end() {
    for (; this.stack.length > 0; )
      yield* this.pop();
  }
  get sourceToken() {
    return {
      type: this.type,
      offset: this.offset,
      indent: this.indent,
      source: this.source
    };
  }
  *step() {
    const e = this.peek(1);
    if (this.type === "doc-end" && (e == null ? void 0 : e.type) !== "doc-end") {
      for (; this.stack.length > 0; )
        yield* this.pop();
      this.stack.push({
        type: "doc-end",
        offset: this.offset,
        source: this.source
      });
      return;
    }
    if (!e)
      return yield* this.stream();
    switch (e.type) {
      case "document":
        return yield* this.document(e);
      case "alias":
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return yield* this.scalar(e);
      case "block-scalar":
        return yield* this.blockScalar(e);
      case "block-map":
        return yield* this.blockMap(e);
      case "block-seq":
        return yield* this.blockSequence(e);
      case "flow-collection":
        return yield* this.flowCollection(e);
      case "doc-end":
        return yield* this.documentEnd(e);
    }
    yield* this.pop();
  }
  peek(e) {
    return this.stack[this.stack.length - e];
  }
  *pop(e) {
    const t = e ?? this.stack.pop();
    if (!t)
      yield { type: "error", offset: this.offset, source: "", message: "Tried to pop an empty stack" };
    else if (this.stack.length === 0)
      yield t;
    else {
      const n = this.peek(1);
      switch (t.type === "block-scalar" ? t.indent = "indent" in n ? n.indent : 0 : t.type === "flow-collection" && n.type === "document" && (t.indent = 0), t.type === "flow-collection" && qi(t), n.type) {
        case "document":
          n.value = t;
          break;
        case "block-scalar":
          n.props.push(t);
          break;
        case "block-map": {
          const i = n.items[n.items.length - 1];
          if (i.value) {
            n.items.push({ start: [], key: t, sep: [] }), this.onKeyLine = !0;
            return;
          } else if (i.sep)
            i.value = t;
          else {
            Object.assign(i, { key: t, sep: [] }), this.onKeyLine = !i.explicitKey;
            return;
          }
          break;
        }
        case "block-seq": {
          const i = n.items[n.items.length - 1];
          i.value ? n.items.push({ start: [], value: t }) : i.value = t;
          break;
        }
        case "flow-collection": {
          const i = n.items[n.items.length - 1];
          !i || i.value ? n.items.push({ start: [], key: t, sep: [] }) : i.sep ? i.value = t : Object.assign(i, { key: t, sep: [] });
          return;
        }
        /* istanbul ignore next should not happen */
        default:
          yield* this.pop(), yield* this.pop(t);
      }
      if ((n.type === "document" || n.type === "block-map" || n.type === "block-seq") && (t.type === "block-map" || t.type === "block-seq")) {
        const i = t.items[t.items.length - 1];
        i && !i.sep && !i.value && i.start.length > 0 && zi(i.start) === -1 && (t.indent === 0 || i.start.every((r) => r.type !== "comment" || r.indent < t.indent)) && (n.type === "document" ? n.end = i.start : n.items.push({ start: i.start }), t.items.splice(-1, 1));
      }
    }
  }
  *stream() {
    switch (this.type) {
      case "directive-line":
        yield { type: "directive", offset: this.offset, source: this.source };
        return;
      case "byte-order-mark":
      case "space":
      case "comment":
      case "newline":
        yield this.sourceToken;
        return;
      case "doc-mode":
      case "doc-start": {
        const e = {
          type: "document",
          offset: this.offset,
          start: []
        };
        this.type === "doc-start" && e.start.push(this.sourceToken), this.stack.push(e);
        return;
      }
    }
    yield {
      type: "error",
      offset: this.offset,
      message: `Unexpected ${this.type} token in YAML stream`,
      source: this.source
    };
  }
  *document(e) {
    if (e.value)
      return yield* this.lineEnd(e);
    switch (this.type) {
      case "doc-start": {
        zi(e.start) !== -1 ? (yield* this.pop(), yield* this.step()) : e.start.push(this.sourceToken);
        return;
      }
      case "anchor":
      case "tag":
      case "space":
      case "comment":
      case "newline":
        e.start.push(this.sourceToken);
        return;
    }
    const t = this.startBlockValue(e);
    t ? this.stack.push(t) : yield {
      type: "error",
      offset: this.offset,
      message: `Unexpected ${this.type} token in YAML document`,
      source: this.source
    };
  }
  *scalar(e) {
    if (this.type === "map-value-ind") {
      const t = ss(this.peek(2)), n = it(t);
      let i;
      e.end ? (i = e.end, i.push(this.sourceToken), delete e.end) : i = [this.sourceToken];
      const r = {
        type: "block-map",
        offset: e.offset,
        indent: e.indent,
        items: [{ start: n, key: e, sep: i }]
      };
      this.onKeyLine = !0, this.stack[this.stack.length - 1] = r;
    } else
      yield* this.lineEnd(e);
  }
  *blockScalar(e) {
    switch (this.type) {
      case "space":
      case "comment":
      case "newline":
        e.props.push(this.sourceToken);
        return;
      case "scalar":
        if (e.source = this.source, this.atNewLine = !0, this.indent = 0, this.onNewLine) {
          let t = this.source.indexOf(`
`) + 1;
          for (; t !== 0; )
            this.onNewLine(this.offset + t), t = this.source.indexOf(`
`, t) + 1;
        }
        yield* this.pop();
        break;
      /* istanbul ignore next should not happen */
      default:
        yield* this.pop(), yield* this.step();
    }
  }
  *blockMap(e) {
    var n;
    const t = e.items[e.items.length - 1];
    switch (this.type) {
      case "newline":
        if (this.onKeyLine = !1, t.value) {
          const i = "end" in t.value ? t.value.end : void 0, r = Array.isArray(i) ? i[i.length - 1] : void 0;
          (r == null ? void 0 : r.type) === "comment" ? i == null || i.push(this.sourceToken) : e.items.push({ start: [this.sourceToken] });
        } else t.sep ? t.sep.push(this.sourceToken) : t.start.push(this.sourceToken);
        return;
      case "space":
      case "comment":
        if (t.value)
          e.items.push({ start: [this.sourceToken] });
        else if (t.sep)
          t.sep.push(this.sourceToken);
        else {
          if (this.atIndentedComment(t.start, e.indent)) {
            const i = e.items[e.items.length - 2], r = (n = i == null ? void 0 : i.value) == null ? void 0 : n.end;
            if (Array.isArray(r)) {
              hs(r, t.start), r.push(this.sourceToken), e.items.pop();
              return;
            }
          }
          t.start.push(this.sourceToken);
        }
        return;
    }
    if (this.indent >= e.indent) {
      const i = !this.onKeyLine && this.indent === e.indent, r = i && (t.sep || t.explicitKey) && this.type !== "seq-item-ind";
      let o = [];
      if (r && t.sep && !t.value) {
        const a = [];
        for (let c = 0; c < t.sep.length; ++c) {
          const l = t.sep[c];
          switch (l.type) {
            case "newline":
              a.push(c);
              break;
            case "space":
              break;
            case "comment":
              l.indent > e.indent && (a.length = 0);
              break;
            default:
              a.length = 0;
          }
        }
        a.length >= 2 && (o = t.sep.splice(a[1]));
      }
      switch (this.type) {
        case "anchor":
        case "tag":
          r || t.value ? (o.push(this.sourceToken), e.items.push({ start: o }), this.onKeyLine = !0) : t.sep ? t.sep.push(this.sourceToken) : t.start.push(this.sourceToken);
          return;
        case "explicit-key-ind":
          !t.sep && !t.explicitKey ? (t.start.push(this.sourceToken), t.explicitKey = !0) : r || t.value ? (o.push(this.sourceToken), e.items.push({ start: o, explicitKey: !0 })) : this.stack.push({
            type: "block-map",
            offset: this.offset,
            indent: this.indent,
            items: [{ start: [this.sourceToken], explicitKey: !0 }]
          }), this.onKeyLine = !0;
          return;
        case "map-value-ind":
          if (t.explicitKey)
            if (t.sep)
              if (t.value)
                e.items.push({ start: [], key: null, sep: [this.sourceToken] });
              else if ($e(t.sep, "map-value-ind"))
                this.stack.push({
                  type: "block-map",
                  offset: this.offset,
                  indent: this.indent,
                  items: [{ start: o, key: null, sep: [this.sourceToken] }]
                });
              else if (no(t.key) && !$e(t.sep, "newline")) {
                const a = it(t.start), c = t.key, l = t.sep;
                l.push(this.sourceToken), delete t.key, delete t.sep, this.stack.push({
                  type: "block-map",
                  offset: this.offset,
                  indent: this.indent,
                  items: [{ start: a, key: c, sep: l }]
                });
              } else o.length > 0 ? t.sep = t.sep.concat(o, this.sourceToken) : t.sep.push(this.sourceToken);
            else if ($e(t.start, "newline"))
              Object.assign(t, { key: null, sep: [this.sourceToken] });
            else {
              const a = it(t.start);
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start: a, key: null, sep: [this.sourceToken] }]
              });
            }
          else
            t.sep ? t.value || r ? e.items.push({ start: o, key: null, sep: [this.sourceToken] }) : $e(t.sep, "map-value-ind") ? this.stack.push({
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: [], key: null, sep: [this.sourceToken] }]
            }) : t.sep.push(this.sourceToken) : Object.assign(t, { key: null, sep: [this.sourceToken] });
          this.onKeyLine = !0;
          return;
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar": {
          const a = this.flowScalar(this.type);
          r || t.value ? (e.items.push({ start: o, key: a, sep: [] }), this.onKeyLine = !0) : t.sep ? this.stack.push(a) : (Object.assign(t, { key: a, sep: [] }), this.onKeyLine = !0);
          return;
        }
        default: {
          const a = this.startBlockValue(e);
          if (a) {
            if (a.type === "block-seq") {
              if (!t.explicitKey && t.sep && !$e(t.sep, "newline")) {
                yield* this.pop({
                  type: "error",
                  offset: this.offset,
                  message: "Unexpected block-seq-ind on same line with key",
                  source: this.source
                });
                return;
              }
            } else i && e.items.push({ start: o });
            this.stack.push(a);
            return;
          }
        }
      }
    }
    yield* this.pop(), yield* this.step();
  }
  *blockSequence(e) {
    var n;
    const t = e.items[e.items.length - 1];
    switch (this.type) {
      case "newline":
        if (t.value) {
          const i = "end" in t.value ? t.value.end : void 0, r = Array.isArray(i) ? i[i.length - 1] : void 0;
          (r == null ? void 0 : r.type) === "comment" ? i == null || i.push(this.sourceToken) : e.items.push({ start: [this.sourceToken] });
        } else
          t.start.push(this.sourceToken);
        return;
      case "space":
      case "comment":
        if (t.value)
          e.items.push({ start: [this.sourceToken] });
        else {
          if (this.atIndentedComment(t.start, e.indent)) {
            const i = e.items[e.items.length - 2], r = (n = i == null ? void 0 : i.value) == null ? void 0 : n.end;
            if (Array.isArray(r)) {
              hs(r, t.start), r.push(this.sourceToken), e.items.pop();
              return;
            }
          }
          t.start.push(this.sourceToken);
        }
        return;
      case "anchor":
      case "tag":
        if (t.value || this.indent <= e.indent)
          break;
        t.start.push(this.sourceToken);
        return;
      case "seq-item-ind":
        if (this.indent !== e.indent)
          break;
        t.value || $e(t.start, "seq-item-ind") ? e.items.push({ start: [this.sourceToken] }) : t.start.push(this.sourceToken);
        return;
    }
    if (this.indent > e.indent) {
      const i = this.startBlockValue(e);
      if (i) {
        this.stack.push(i);
        return;
      }
    }
    yield* this.pop(), yield* this.step();
  }
  *flowCollection(e) {
    const t = e.items[e.items.length - 1];
    if (this.type === "flow-error-end") {
      let n;
      do
        yield* this.pop(), n = this.peek(1);
      while ((n == null ? void 0 : n.type) === "flow-collection");
    } else if (e.end.length === 0) {
      switch (this.type) {
        case "comma":
        case "explicit-key-ind":
          !t || t.sep ? e.items.push({ start: [this.sourceToken] }) : t.start.push(this.sourceToken);
          return;
        case "map-value-ind":
          !t || t.value ? e.items.push({ start: [], key: null, sep: [this.sourceToken] }) : t.sep ? t.sep.push(this.sourceToken) : Object.assign(t, { key: null, sep: [this.sourceToken] });
          return;
        case "space":
        case "comment":
        case "newline":
        case "anchor":
        case "tag":
          !t || t.value ? e.items.push({ start: [this.sourceToken] }) : t.sep ? t.sep.push(this.sourceToken) : t.start.push(this.sourceToken);
          return;
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar": {
          const i = this.flowScalar(this.type);
          !t || t.value ? e.items.push({ start: [], key: i, sep: [] }) : t.sep ? this.stack.push(i) : Object.assign(t, { key: i, sep: [] });
          return;
        }
        case "flow-map-end":
        case "flow-seq-end":
          e.end.push(this.sourceToken);
          return;
      }
      const n = this.startBlockValue(e);
      n ? this.stack.push(n) : (yield* this.pop(), yield* this.step());
    } else {
      const n = this.peek(2);
      if (n.type === "block-map" && (this.type === "map-value-ind" && n.indent === e.indent || this.type === "newline" && !n.items[n.items.length - 1].sep))
        yield* this.pop(), yield* this.step();
      else if (this.type === "map-value-ind" && n.type !== "flow-collection") {
        const i = ss(n), r = it(i);
        qi(e);
        const o = e.end.splice(1, e.end.length);
        o.push(this.sourceToken);
        const a = {
          type: "block-map",
          offset: e.offset,
          indent: e.indent,
          items: [{ start: r, key: e, sep: o }]
        };
        this.onKeyLine = !0, this.stack[this.stack.length - 1] = a;
      } else
        yield* this.lineEnd(e);
    }
  }
  flowScalar(e) {
    if (this.onNewLine) {
      let t = this.source.indexOf(`
`) + 1;
      for (; t !== 0; )
        this.onNewLine(this.offset + t), t = this.source.indexOf(`
`, t) + 1;
    }
    return {
      type: e,
      offset: this.offset,
      indent: this.indent,
      source: this.source
    };
  }
  startBlockValue(e) {
    switch (this.type) {
      case "alias":
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return this.flowScalar(this.type);
      case "block-scalar-header":
        return {
          type: "block-scalar",
          offset: this.offset,
          indent: this.indent,
          props: [this.sourceToken],
          source: ""
        };
      case "flow-map-start":
      case "flow-seq-start":
        return {
          type: "flow-collection",
          offset: this.offset,
          indent: this.indent,
          start: this.sourceToken,
          items: [],
          end: []
        };
      case "seq-item-ind":
        return {
          type: "block-seq",
          offset: this.offset,
          indent: this.indent,
          items: [{ start: [this.sourceToken] }]
        };
      case "explicit-key-ind": {
        this.onKeyLine = !0;
        const t = ss(e), n = it(t);
        return n.push(this.sourceToken), {
          type: "block-map",
          offset: this.offset,
          indent: this.indent,
          items: [{ start: n, explicitKey: !0 }]
        };
      }
      case "map-value-ind": {
        this.onKeyLine = !0;
        const t = ss(e), n = it(t);
        return {
          type: "block-map",
          offset: this.offset,
          indent: this.indent,
          items: [{ start: n, key: null, sep: [this.sourceToken] }]
        };
      }
    }
    return null;
  }
  atIndentedComment(e, t) {
    return this.type !== "comment" || this.indent <= t ? !1 : e.every((n) => n.type === "newline" || n.type === "space");
  }
  *documentEnd(e) {
    this.type !== "doc-mode" && (e.end ? e.end.push(this.sourceToken) : e.end = [this.sourceToken], this.type === "newline" && (yield* this.pop()));
  }
  *lineEnd(e) {
    switch (this.type) {
      case "comma":
      case "doc-start":
      case "doc-end":
      case "flow-seq-end":
      case "flow-map-end":
      case "map-value-ind":
        yield* this.pop(), yield* this.step();
        break;
      case "newline":
        this.onKeyLine = !1;
      // fallthrough
      case "space":
      case "comment":
      default:
        e.end ? e.end.push(this.sourceToken) : e.end = [this.sourceToken], this.type === "newline" && (yield* this.pop());
    }
  }
}
function oc(s) {
  const e = s.prettyErrors !== !1;
  return { lineCounter: s.lineCounter || e && new ic() || null, prettyErrors: e };
}
function ac(s, e = {}) {
  const { lineCounter: t, prettyErrors: n } = oc(e), i = new rc(t == null ? void 0 : t.addNewLine), r = new Zl(e);
  let o = null;
  for (const a of r.compose(i.parse(s), !0, s.length))
    if (!o)
      o = a;
    else if (o.options.logLevel !== "silent") {
      o.errors.push(new Ot(a.range.slice(0, 2), "MULTIPLE_DOCS", "Source contains multiple documents; please use YAML.parseAllDocuments()"));
      break;
    }
  return n && t && (o.errors.forEach(Bi(s, t)), o.warnings.forEach(Bi(s, t))), o;
}
function lc(s, e, t) {
  let n;
  const i = ac(s, t);
  if (!i)
    return null;
  if (i.warnings.forEach((r) => Or(i.options.logLevel, r)), i.errors.length > 0) {
    if (i.options.logLevel !== "silent")
      throw i.errors[0];
    i.errors = [];
  }
  return i.toJS(Object.assign({ reviver: n }, t));
}
async function cc(s, e, t, n) {
  var d, g, m, y, A;
  const i = (d = s.assessments) == null ? void 0 : d[t], r = s.mode === "scorm12" || s.mode === "scorm2004" || s.mode === "standalone" || s.mode === "xapi" || s.mode === "cmi5";
  if (i) {
    const k = ((g = s.answerKeys) == null ? void 0 : g[t]) ?? {}, L = ((m = s.assessmentConfigs) == null ? void 0 : m[t]) ?? {
      maxAttempts: 1,
      shuffleChoices: !1,
      showFeedback: "never"
    };
    return {
      assessment: i,
      answerKey: k,
      payload: {
        ...i,
        config: L,
        feedback: (y = s.assessmentFeedback) == null ? void 0 : y[t]
      }
    };
  }
  if (r)
    throw new Error(
      `Assessment "${t}" is not embedded in this package. Rebuild the course with lxpack build.`
    );
  const o = await fetch(bn(e, n));
  if (!o.ok) throw new Error(`Failed to load assessment: ${n}`);
  const a = await o.text(), c = lc(a), l = {};
  for (const k of c.questions ?? []) {
    const L = (A = k.choices) == null ? void 0 : A.find(
      (I) => "correct" in I && I.correct === !0
    );
    L && (l[k.id] = L.id);
  }
  const u = {
    id: c.id ?? t,
    title: c.title,
    passingScore: c.passingScore ?? 0.7,
    questions: (c.questions ?? []).map((k) => ({
      id: k.id,
      prompt: k.prompt,
      choices: k.choices.map((L) => ({ id: L.id, text: L.text }))
    }))
  }, p = {
    maxAttempts: c.maxAttempts ?? 1,
    shuffleChoices: c.shuffleChoices ?? !1,
    showFeedback: c.showFeedback ?? "never"
  }, h = {};
  for (const k of c.questions ?? [])
    k.explanation && (h[k.id] = k.explanation);
  return {
    assessment: u,
    answerKey: l,
    payload: {
      ...u,
      config: p,
      feedback: Object.keys(h).length ? h : void 0
    }
  };
}
function uc(s, e, t, n) {
  const i = window.__LXPACK_COMPONENTS__;
  if (i) {
    i.mount(s, e, t ?? {}, n);
    return;
  }
  s.innerHTML = `
    <article class="lxpack-component lxpack-error">
      <p>Component "${De(e)}" requires the LXPack components bundle.</p>
    </article>
  `;
}
function fc(s, e, t) {
  return t === "number" ? Number(s) === Number(e) : t === "boolean" ? typeof s != "boolean" || typeof e != "boolean" ? !1 : s === e : t === "string" ? String(s) === String(e) : s === e;
}
const hc = [
  (s, e) => {
    var t, n;
    if ("variable" in s && ((t = s.variable) != null && t.eq)) {
      const [i, r] = s.variable.eq, o = (n = e.getVariableType) == null ? void 0 : n.call(e, i);
      return fc(e.getVariable(i), r, o);
    }
    return null;
  },
  (s, e) => {
    var t;
    return "assessment" in s && ((t = s.assessment) != null && t.passed) ? e.isAssessmentPassed(s.assessment.passed) : null;
  },
  (s, e) => {
    var t;
    return "interaction" in s && ((t = s.interaction) != null && t.done) ? e.isInteractionDone(s.interaction.done) : null;
  },
  (s, e) => "all" in s && s.all ? s.all.every((t) => gn(t, e)) : null,
  (s, e) => "any" in s && s.any ? s.any.some((t) => gn(t, e)) : null
];
function gn(s, e) {
  for (const t of hc) {
    const n = t(s, e);
    if (n !== null)
      return n;
  }
  return !1;
}
function io(s, e) {
  const t = s.flow;
  if (!(t != null && t.length)) return null;
  for (const n of t)
    if (gn(n.when, e))
      return n.goto;
  return null;
}
function ro(s) {
  const e = s.lessons.map((t) => t.id);
  for (const t of s.assessments ?? [])
    e.push(t.id);
  return e;
}
function oo(s, e, t) {
  const n = ro(s), i = n.indexOf(e);
  return i < 0 ? null : n[i + t] ?? null;
}
function Ki(s, e, t) {
  const n = io(s, t);
  return n && n !== e ? n : oo(s, e, 1);
}
function Gi(s, e) {
  return oo(s, e, -1);
}
const ao = 4096;
function Pe(s) {
  var t;
  const e = {
    c: s.currentLessonId,
    l: s.completedLessons,
    a: s.assessmentScores,
    s: s.suspendData
  };
  return (t = e.l) != null && t.length || delete e.l, (!e.a || !Object.keys(e.a).length) && delete e.a, (!e.s || !Object.keys(e.s).length) && delete e.s, e;
}
function Hi(s, e) {
  return {
    currentLessonId: s.c ?? e.currentLessonId,
    completedLessons: Array.isArray(s.l) ? s.l : e.completedLessons,
    assessmentScores: s.a && typeof s.a == "object" ? s.a : e.assessmentScores,
    suspendData: s.s && typeof s.s == "object" ? s.s : e.suspendData
  };
}
function pc(s) {
  if (!s || typeof s != "object") return !1;
  const e = s;
  return "currentLessonId" in e || "completedLessons" in e || "assessmentScores" in e;
}
function dc(s, e) {
  return {
    currentLessonId: s.currentLessonId ?? e.currentLessonId,
    completedLessons: Array.isArray(s.completedLessons) ? s.completedLessons : e.completedLessons,
    assessmentScores: s.assessmentScores && typeof s.assessmentScores == "object" ? s.assessmentScores : e.assessmentScores,
    suspendData: s.suspendData && typeof s.suspendData == "object" ? s.suspendData : e.suspendData
  };
}
function mc(s) {
  return s.c === void 0 && (!s.l || s.l.length === 0) && (!s.a || Object.keys(s.a).length === 0) && (!s.s || Object.keys(s.s).length === 0);
}
function Ns(s, e) {
  try {
    const t = JSON.parse(s);
    if (t === null || typeof t != "object")
      return { progress: e, parsed: !1 };
    if (pc(t))
      return {
        progress: dc(t, e),
        parsed: !0
      };
    const n = t;
    return mc(n) ? { progress: Hi(n, e), parsed: !0 } : { progress: Hi(n, e), parsed: !0 };
  } catch {
    return { progress: e, parsed: !1 };
  }
}
function ve(s, e) {
  return JSON.stringify(Pe(s)).length <= e;
}
function gc(s, e, t) {
  const n = { ...s.suspendData }, i = Object.keys(n).filter((r) => r.startsWith("interaction_")).filter((r) => {
    if (!(t != null && t.size)) return !0;
    const o = r.slice(12);
    return !t.has(o);
  }).sort();
  for (const r of i) {
    delete n[r];
    const o = { ...s, suspendData: n };
    if (ve(o, e))
      return o;
  }
  return { ...s, suspendData: n };
}
function yc(s) {
  return s.startsWith("interaction_") || s.startsWith("v:") || s.startsWith("assessment_attempts_") || s.startsWith("assessment_passing_");
}
function bc(s, e) {
  const t = { ...s.suspendData }, n = Object.keys(t).filter((r) => !yc(r)).sort();
  for (const r of n) {
    delete t[r];
    const o = { ...s, suspendData: t };
    if (ve(o, e))
      return o;
  }
  const i = Object.keys(t).filter((r) => r.startsWith("v:")).sort();
  for (const r of i) {
    delete t[r];
    const o = { ...s, suspendData: t };
    if (ve(o, e))
      return o;
  }
  return { ...s, suspendData: t };
}
function Vi(s) {
  const e = {};
  for (const [t, n] of Object.entries(s.suspendData))
    (t.startsWith("assessment_attempts_") || t.startsWith("assessment_passing_")) && (e[t] = n);
  return e;
}
function wc(s, e) {
  const t = {};
  for (const [n, i] of Object.entries(s.suspendData)) {
    if (n.startsWith("v:")) {
      t[n] = i;
      continue;
    }
    if (n.startsWith("interaction_")) {
      if (e != null && e.size) {
        const r = n.slice(12);
        if (!e.has(r)) continue;
      }
      t[n] = i;
    }
  }
  return t;
}
function Wi(...s) {
  return Object.assign({}, ...s);
}
function kc(s) {
  const e = /* @__PURE__ */ new Set();
  for (const t of Object.keys(s))
    t.startsWith("interaction_") && e.add(t.slice(12));
  return e;
}
function Sc(s, e, t) {
  const n = wc(s, t);
  let i = {
    currentLessonId: s.currentLessonId,
    completedLessons: [...s.completedLessons],
    assessmentScores: { ...s.assessmentScores },
    suspendData: Wi(
      Vi(s),
      n
    )
  };
  if (ve(i, e))
    return JSON.stringify(Pe(i));
  for (; i.completedLessons.length > 0; )
    if (i.completedLessons.pop(), ve(i, e))
      return JSON.stringify(Pe(i));
  const r = Object.keys(i.assessmentScores);
  for (; r.length > 0; )
    if (delete i.assessmentScores[r.pop()], ve(i, e))
      return JSON.stringify(Pe(i));
  i = {
    currentLessonId: s.currentLessonId,
    completedLessons: [],
    assessmentScores: {},
    suspendData: Wi(
      Vi(s),
      n
    )
  };
  const o = JSON.stringify(Pe(i));
  if (o.length <= e)
    return o;
  const a = JSON.stringify({
    c: s.currentLessonId.slice(0, Math.max(0, e - 20))
  });
  return a.length <= e ? a : JSON.stringify({ c: "" });
}
function lo(s, e = ao, t) {
  if (ve(s, e))
    return JSON.stringify(Pe(s));
  let n = gc(
    s,
    e,
    t == null ? void 0 : t.preserveInteractionIds
  );
  return ve(n, e) || (n = bc(n, e), ve(n, e)) ? JSON.stringify(Pe(n)) : (console.warn(
    `[lxpack] suspend_data exceeds ${e} chars; using minimal progress snapshot`
  ), Sc(
    s,
    e,
    t == null ? void 0 : t.preserveInteractionIds
  ));
}
function Pt(s, e = ao) {
  if (s.length <= e) return s;
  console.warn(
    `[lxpack] suspend_data exceeds ${e} chars; using minimal progress snapshot`
  );
  try {
    const t = {
      currentLessonId: "",
      completedLessons: [],
      assessmentScores: {},
      suspendData: {}
    }, { progress: n } = Ns(s, t), i = kc(
      n.suspendData
    );
    return lo(n, e, {
      preserveInteractionIds: i.size > 0 ? i : void 0
    });
  } catch {
    return JSON.stringify({ c: "" });
  }
}
function Ac(s) {
  return Oo(s);
}
const Tc = "v:";
function qn(s) {
  return `${Tc}${s}`;
}
function Yi(s, e) {
  for (const [t, n] of Object.entries(s.variables ?? {})) {
    const i = qn(t);
    e[i] === void 0 && (e[i] = n.default);
  }
}
function Ji(s, e) {
  return s[qn(e)];
}
function Ec(s, e, t) {
  s[qn(e)] = t;
}
function co(s) {
  return s === !0 ? !0 : typeof s == "object" && s !== null ? s.complete === !0 : !1;
}
const uo = {
  maxAttempts: 1,
  shuffleChoices: !1,
  showFeedback: "never"
}, ue = "0", Se = "301", ps = "302", Xi = "lxpack_scorm12_preview";
function _c(s = 500) {
  let e = window, t = 0;
  for (; e && t < s; ) {
    try {
      const n = e.API;
      if (n && typeof n.LMSInitialize == "function")
        return n;
    } catch {
    }
    try {
      if (e.parent && e.parent !== e)
        e = e.parent;
      else if (e.opener && !e.opener.closed)
        e = e.opener;
      else
        break;
    } catch {
      break;
    }
    t++;
  }
  return null;
}
class Lc {
  constructor(e) {
    N(this, "api");
    N(this, "initialized", !1);
    N(this, "terminated", !1);
    N(this, "lastError", ue);
    this.api = e;
  }
  LMSInitialize() {
    if (this.initialized)
      return this.lastError = Se, "false";
    const e = this.api.LMSInitialize("");
    return e === "true" && (this.initialized = !0, this.terminated = !1, this.lastError = ue), e;
  }
  LMSFinish() {
    if (!this.initialized || this.terminated)
      return this.lastError = ps, "false";
    const e = this.api.LMSFinish("");
    return e === "true" && (this.terminated = !0, this.lastError = ue), e;
  }
  LMSGetValue(e) {
    return !this.initialized || this.terminated ? (this.lastError = Se, "") : (this.lastError = ue, this.api.LMSGetValue(e));
  }
  LMSSetValue(e, t) {
    if (!this.initialized || this.terminated)
      return this.lastError = Se, "false";
    this.lastError = ue;
    const n = e === "cmi.suspend_data" ? ds(t) : t;
    return this.api.LMSSetValue(e, n);
  }
  LMSCommit() {
    return !this.initialized || this.terminated ? (this.lastError = Se, "false") : (this.lastError = ue, this.api.LMSCommit(""));
  }
  LMSGetLastError() {
    return this.lastError;
  }
  LMSGetErrorString(e) {
    const t = e ?? this.lastError;
    return t === Se ? "Not initialized" : t === ps ? "Already terminated" : this.api.LMSGetErrorString(t);
  }
  LMSGetDiagnostic(e) {
    return this.api.LMSGetDiagnostic(e ?? this.lastError);
  }
  setLessonStatus(e) {
    this.LMSSetValue("cmi.core.lesson_status", e);
  }
  setScore(e, t = 100) {
    this.LMSSetValue("cmi.core.score.raw", String(e)), this.LMSSetValue("cmi.core.score.max", String(t)), this.LMSSetValue("cmi.core.score.min", "0");
  }
  setSuspendData(e) {
    const t = ds(e);
    this.LMSSetValue("cmi.suspend_data", t);
  }
  setLessonLocation(e) {
    this.LMSSetValue("cmi.core.lesson_location", e);
  }
}
class tn {
  constructor(e = {}) {
    N(this, "data", {
      lessonStatus: "not attempted",
      scoreRaw: 0,
      scoreMin: 0,
      scoreMax: 100,
      suspendData: "",
      lessonLocation: "",
      entry: "ab-initio",
      exit: "",
      sessionTime: "00:00:00"
    });
    N(this, "initialized", !1);
    N(this, "terminated", !1);
    N(this, "lastError", ue);
    N(this, "persistToStorage");
    this.persistToStorage = e.persistToStorage ?? !1, e.initialData && (this.data = { ...this.data, ...e.initialData }), this.persistToStorage && this.loadFromStorage();
  }
  LMSInitialize() {
    return this.initialized ? (this.lastError = Se, "false") : (this.initialized = !0, this.terminated = !1, this.lastError = ue, "true");
  }
  LMSFinish() {
    return !this.initialized || this.terminated ? (this.lastError = ps, "false") : (this.data.exit = "suspend", this.terminated = !0, this.saveToStorage(), this.lastError = ue, "true");
  }
  LMSGetValue(e) {
    if (!this.initialized || this.terminated)
      return this.lastError = Se, "";
    switch (this.lastError = ue, e) {
      case "cmi.core.lesson_status":
        return this.data.lessonStatus;
      case "cmi.core.score.raw":
        return String(this.data.scoreRaw);
      case "cmi.core.score.min":
        return String(this.data.scoreMin);
      case "cmi.core.score.max":
        return String(this.data.scoreMax);
      case "cmi.suspend_data":
        return this.data.suspendData;
      case "cmi.core.lesson_location":
        return this.data.lessonLocation;
      case "cmi.core.student_id":
        return "lxpack-learner";
      case "cmi.core.student_name":
        return "LXPack Learner";
      case "cmi.core.entry":
        return this.data.entry;
      case "cmi.core.exit":
        return this.data.exit;
      case "cmi.core.session_time":
        return this.data.sessionTime;
      default:
        return "";
    }
  }
  LMSSetValue(e, t) {
    if (!this.initialized || this.terminated)
      return this.lastError = Se, "false";
    switch (this.lastError = ue, e) {
      case "cmi.core.lesson_status":
        this.data.lessonStatus = t;
        break;
      case "cmi.core.score.raw":
        this.data.scoreRaw = Number(t);
        break;
      case "cmi.core.score.min":
        this.data.scoreMin = Number(t);
        break;
      case "cmi.core.score.max":
        this.data.scoreMax = Number(t);
        break;
      case "cmi.suspend_data":
        this.data.suspendData = ds(t);
        break;
      case "cmi.core.lesson_location":
        this.data.lessonLocation = t;
        break;
      case "cmi.core.exit":
        this.data.exit = t;
        break;
      case "cmi.core.session_time":
        this.data.sessionTime = t;
        break;
      default:
        return "false";
    }
    return this.saveToStorage(), "true";
  }
  LMSCommit() {
    return !this.initialized || this.terminated ? (this.lastError = Se, "false") : (this.saveToStorage(), this.lastError = ue, "true");
  }
  LMSGetLastError() {
    return this.lastError;
  }
  LMSGetErrorString(e) {
    const t = e ?? this.lastError;
    return t === Se ? "Not initialized" : t === ps ? "Already terminated" : "No error";
  }
  LMSGetDiagnostic() {
    return "";
  }
  setLessonStatus(e) {
    this.data.lessonStatus = e, this.saveToStorage();
  }
  setScore(e, t = 100) {
    this.data.scoreRaw = e, this.data.scoreMax = t, this.data.scoreMin = 0, this.saveToStorage();
  }
  setSuspendData(e) {
    this.data.suspendData = ds(e), this.saveToStorage();
  }
  setLessonLocation(e) {
    this.data.lessonLocation = e, this.saveToStorage();
  }
  loadFromStorage() {
    try {
      const e = localStorage.getItem(Xi);
      e && (this.data = { ...this.data, ...JSON.parse(e) });
    } catch {
    }
  }
  saveToStorage() {
    if (this.persistToStorage)
      try {
        localStorage.setItem(Xi, JSON.stringify(this.data));
      } catch {
      }
  }
}
function ds(s) {
  return Pt(s);
}
function fo(s) {
  if (s === "preview")
    return new tn({ persistToStorage: !0 });
  if (s === "scorm12") {
    const e = _c();
    return e ? new Lc(e) : (console.warn(
      "[lxpack] No LMS SCORM API found; using in-memory simulator (progress will not persist to LMS)"
    ), new tn({ persistToStorage: !1 }));
  }
  return new tn({ persistToStorage: !1 });
}
function Ic(s = "preview") {
  const e = fo(s);
  if (s === "preview") {
    const t = window;
    t.API = e;
  }
  return e;
}
const Nc = "0", Qi = "lxpack_scorm2004_preview";
function Oc(s = 500) {
  let e = window, t = 0;
  for (; e && t < s; ) {
    try {
      const n = e.API_1484_11;
      if (n && typeof n.Initialize == "function")
        return n;
    } catch {
    }
    try {
      if (e.parent && e.parent !== e)
        e = e.parent;
      else if (e.opener && !e.opener.closed)
        e = e.opener;
      else
        break;
    } catch {
      break;
    }
    t++;
  }
  return null;
}
class Zi {
  constructor(e) {
    N(this, "initialized", !1);
    N(this, "terminated", !1);
    N(this, "data", {
      "cmi.completion_status": "unknown",
      "cmi.success_status": "unknown",
      "cmi.score.scaled": "",
      "cmi.suspend_data": "",
      "cmi.location": "",
      "cmi.entry": "ab-initio"
    });
    N(this, "persistToStorage");
    if (this.persistToStorage = (e == null ? void 0 : e.persistToStorage) ?? !1, this.persistToStorage)
      try {
        const t = localStorage.getItem(Qi);
        t && (this.data = { ...this.data, ...JSON.parse(t) });
      } catch {
      }
  }
  save() {
    if (this.persistToStorage)
      try {
        localStorage.setItem(Qi, JSON.stringify(this.data));
      } catch {
      }
  }
  Initialize() {
    return this.initialized ? "false" : (this.initialized = !0, this.terminated = !1, "true");
  }
  Terminate() {
    return !this.initialized || this.terminated ? "false" : (this.terminated = !0, this.save(), "true");
  }
  GetValue(e) {
    return !this.initialized || this.terminated ? "" : this.data[e] ?? "";
  }
  SetValue(e, t) {
    return !this.initialized || this.terminated ? "false" : (this.data[e] = e === "cmi.suspend_data" ? Pt(t) : t, this.save(), "true");
  }
  Commit() {
    return !this.initialized || this.terminated ? "false" : (this.save(), "true");
  }
  GetLastError() {
    return Nc;
  }
  GetErrorString() {
    return "No error";
  }
  GetDiagnostic() {
    return "";
  }
  setSuspendData(e) {
    this.data["cmi.suspend_data"] = Pt(e);
  }
  setLocation(e) {
    this.data["cmi.location"] = e;
  }
  setCompletionStatus(e) {
    this.data["cmi.completion_status"] = e;
  }
  setSuccessStatus(e) {
    this.data["cmi.success_status"] = e;
  }
  setScoreScaled(e) {
    this.data["cmi.score.scaled"] = String(Math.max(0, Math.min(1, e)));
  }
}
class vc {
  constructor(e) {
    N(this, "api");
    this.api = e;
  }
  Initialize() {
    return this.api.Initialize("");
  }
  Terminate() {
    return this.api.Terminate("");
  }
  GetValue(e) {
    return this.api.GetValue(e);
  }
  SetValue(e, t) {
    const n = e === "cmi.suspend_data" ? Pt(t) : t;
    return this.api.SetValue(e, n);
  }
  Commit() {
    return this.api.Commit("");
  }
  GetLastError() {
    return this.api.GetLastError();
  }
  GetErrorString(e) {
    return this.api.GetErrorString(e);
  }
  GetDiagnostic(e) {
    return this.api.GetDiagnostic(e);
  }
  setSuspendData(e) {
    this.api.SetValue("cmi.suspend_data", Pt(e));
  }
  setLocation(e) {
    this.api.SetValue("cmi.location", e);
  }
  setCompletionStatus(e) {
    this.api.SetValue("cmi.completion_status", e);
  }
  setSuccessStatus(e) {
    this.api.SetValue("cmi.success_status", e);
  }
  setScoreScaled(e) {
    this.api.SetValue("cmi.score.scaled", String(Math.max(0, Math.min(1, e))));
  }
}
function ho(s) {
  if (s === "preview")
    return new Zi({ persistToStorage: !0 });
  const e = Oc();
  return e ? new vc(e) : (console.warn(
    "[lxpack] No SCORM 2004 API found; using in-memory simulator"
  ), new Zi({ persistToStorage: !1 }));
}
function xc(s = "preview") {
  const e = ho(
    s === "preview" ? "preview" : "scorm2004"
  );
  if (s === "preview") {
    const t = window;
    t.API_1484_11 = e;
  }
  return e;
}
class er {
  constructor(e) {
    this.connection = e;
  }
  init() {
    this.connection.LMSInitialize();
  }
  restoreProgress(e) {
    const t = this.connection.LMSGetValue("cmi.suspend_data");
    if (t) {
      const { progress: i, parsed: r } = Ns(t, e);
      if (r) return i;
      console.warn(
        "[lxpack] suspend_data could not be parsed; using lesson_location only"
      );
      const o = this.connection.LMSGetValue("cmi.core.lesson_location");
      return o ? { ...e, currentLessonId: o } : e;
    }
    const n = this.connection.LMSGetValue("cmi.core.lesson_location");
    return n ? { ...e, currentLessonId: n } : e;
  }
  persist(e, t) {
    this.connection.setSuspendData(t), this.connection.LMSCommit();
  }
  setLocation(e) {
    this.connection.setLessonLocation(e);
  }
  applyCompletion(e) {
    this.connection.setScore(e.scorePercent), e.anyAssessmentFailed ? this.connection.setLessonStatus("failed") : e.ratio >= e.completionThreshold && e.allLessonsComplete && e.allAssessmentsPassed ? this.connection.setLessonStatus(
      e.hasAssessments ? "passed" : "completed"
    ) : e.hasLearnerProgress ? this.connection.setLessonStatus("incomplete") : this.connection.setLessonStatus("incomplete");
  }
  terminate() {
    this.connection.LMSFinish();
  }
}
class tr {
  constructor(e) {
    this.connection = e;
  }
  init() {
    this.connection.Initialize();
  }
  restoreProgress(e) {
    const t = this.connection.GetValue("cmi.suspend_data");
    if (t) {
      const { progress: i, parsed: r } = Ns(t, e);
      if (r) return i;
      console.warn(
        "[lxpack] suspend_data could not be parsed; using cmi.location only"
      );
      const o = this.connection.GetValue("cmi.location");
      return o ? { ...e, currentLessonId: o } : e;
    }
    const n = this.connection.GetValue("cmi.location");
    return n ? { ...e, currentLessonId: n } : e;
  }
  persist(e, t) {
    this.connection.setSuspendData(t), this.connection.Commit();
  }
  setLocation(e) {
    this.connection.setLocation(e);
  }
  applyCompletion(e) {
    this.connection.setScoreScaled(e.ratio), e.anyAssessmentFailed ? (this.connection.setSuccessStatus("failed"), this.connection.setCompletionStatus("incomplete")) : e.ratio >= e.completionThreshold && e.allLessonsComplete && e.allAssessmentsPassed ? (this.connection.setSuccessStatus("passed"), this.connection.setCompletionStatus("completed")) : e.ratio > 0 || e.hasAssessments && !e.allAssessmentsPassed && !e.anyAssessmentFailed ? (this.connection.setCompletionStatus("incomplete"), this.connection.setSuccessStatus("unknown")) : (this.connection.setCompletionStatus("incomplete"), this.connection.setSuccessStatus("unknown"));
  }
  terminate() {
    this.connection.Terminate();
  }
}
class sn {
  constructor(e) {
    this.storageKey = e;
  }
  init() {
  }
  restoreProgress(e) {
    try {
      const t = localStorage.getItem(this.storageKey);
      if (t) {
        const { progress: n, parsed: i } = Ns(t, e);
        if (i) return n;
      }
    } catch {
    }
    return e;
  }
  persist(e, t) {
    try {
      localStorage.setItem(this.storageKey, t);
    } catch {
    }
  }
  setLocation(e) {
  }
  applyCompletion(e) {
  }
  terminate() {
  }
}
function Cc(s, e) {
  const t = `${s}::${e}`;
  let n = 0;
  for (let i = 0; i < t.length; i++)
    n = (n << 5) - n + t.charCodeAt(i), n |= 0;
  return `lxpack_progress_${Math.abs(n)}`;
}
function Rc(s, e, t = "local") {
  return s === "scorm12" ? new er(fo("scorm12")) : s === "scorm2004" ? new tr(ho("scorm2004")) : s === "preview" ? t === "scorm12" ? new er(Ic("preview")) : t === "scorm2004" ? new tr(xc("preview")) : new sn(e) : s === "standalone" || s === "xapi" || s === "cmi5" ? new sn(e) : new sn(e);
}
function $c(s, e, t) {
  let n = 0;
  for (const i of s.questions) {
    const r = t.querySelector(
      `input[name="q-${i.id}"]:checked`
    ), o = e[i.id];
    r && o && r.value === o && n++;
  }
  return s.questions.length ? n / s.questions.length : 0;
}
function sr(s) {
  const e = [...s];
  for (let t = e.length - 1; t > 0; t--) {
    const n = Math.floor(Math.random() * (t + 1));
    [e[t], e[n]] = [e[n], e[t]];
  }
  return e;
}
function Os(s, e) {
  const t = s[`assessment_attempts_${e}`];
  let n = 0;
  return typeof t == "number" ? n = t : typeof t == "string" && t !== "" && !Number.isNaN(Number(t)) && (n = Number(t)), !Number.isFinite(n) || n < 0 ? 0 : Math.floor(n);
}
function Pc(s, e) {
  const t = Os(s, e) + 1;
  return s[`assessment_attempts_${e}`] = t, t;
}
class Dc {
  constructor(e, t, n) {
    N(this, "progress");
    N(this, "passedAssessments", /* @__PURE__ */ new Set());
    this.manifest = t, this.defaultPassingScores = n, this.progress = e, this.syncPassedAssessments();
  }
  getAssessmentPassingScore(e) {
    const t = this.progress.suspendData[`assessment_passing_${e}`];
    return typeof t == "number" ? t : e in this.defaultPassingScores ? this.defaultPassingScores[e] : 0.7;
  }
  syncPassedAssessments() {
    this.passedAssessments.clear();
    for (const [e, t] of Object.entries(this.progress.assessmentScores))
      t >= this.getAssessmentPassingScore(e) && this.passedAssessments.add(e);
  }
  applyAssessmentResult(e, t, n) {
    this.progress.assessmentScores[e] = t, this.progress.suspendData[`assessment_passing_${e}`] = n, t >= n ? this.passedAssessments.add(e) : this.passedAssessments.delete(e);
  }
  recordAssessmentAttempt(e) {
    return Pc(this.progress.suspendData, e);
  }
  getAssessmentAttemptCount(e) {
    return Os(this.progress.suspendData, e);
  }
  completeLesson(e) {
    new Set(this.manifest.lessons.map((n) => n.id)).has(e) && (this.progress.completedLessons.includes(e) || this.progress.completedLessons.push(e));
  }
  setCurrentLesson(e) {
    this.progress.currentLessonId = e;
  }
  isLessonComplete(e) {
    return this.progress.completedLessons.includes(e);
  }
  isAssessmentPassed(e) {
    return this.passedAssessments.has(e);
  }
  getAssessmentPassingScoreForTrack(e) {
    return this.getAssessmentPassingScore(e);
  }
}
function Mc(s, e) {
  var t;
  if (s.lessons.some((n) => n.id === e))
    return { id: e, kind: "lesson" };
  if ((t = s.assessments) != null && t.some((n) => n.id === e))
    return { id: e, kind: "assessment" };
}
function nr(s, e) {
  var g, m, y, A;
  const { manifest: t, completionThreshold: n, passedAssessments: i, scopeActivity: r } = e;
  if (r)
    return Bc(
      s,
      t,
      r,
      n,
      e,
      i
    );
  const o = t.lessons.length, a = ((g = t.assessments) == null ? void 0 : g.length) ?? 0, c = o + a, l = s.completedLessons.filter(
    (k) => t.lessons.some((L) => L.id === k)
  ).length, u = c === 0 ? 0 : (l + i.size) / c, p = t.lessons.every(
    (k) => s.completedLessons.includes(k.id)
  ), h = !((m = t.assessments) != null && m.length) || t.assessments.every((k) => i.has(k.id)), d = (y = t.assessments) == null ? void 0 : y.some((k) => {
    var I;
    if (!(k.id in s.assessmentScores) || i.has(k.id)) return !1;
    const L = ((I = e.assessmentConfigs[k.id]) == null ? void 0 : I.maxAttempts) ?? 1;
    return Os(s.suspendData, k.id) >= L;
  });
  return {
    ratio: u,
    scorePercent: Math.round(u * 100),
    allLessonsComplete: p,
    allAssessmentsPassed: h,
    anyAssessmentFailed: !!d,
    hasAssessments: (((A = t.assessments) == null ? void 0 : A.length) ?? 0) > 0,
    hasLearnerProgress: yn(s, i),
    completionThreshold: n
  };
}
function yn(s, e) {
  return s.completedLessons.length > 0 || e.size > 0 || Object.keys(s.assessmentScores).length > 0;
}
function Bc(s, e, t, n, i, r) {
  var h, d;
  if (t.kind === "lesson") {
    const g = s.completedLessons.includes(t.id), m = g ? 1 : 0;
    return {
      ratio: m,
      scorePercent: Math.round(m * 100),
      allLessonsComplete: g,
      allAssessmentsPassed: !0,
      anyAssessmentFailed: !1,
      hasAssessments: !1,
      hasLearnerProgress: yn(s, r),
      completionThreshold: n
    };
  }
  const o = t.id, a = r.has(o), c = o in s.assessmentScores, l = ((h = i.assessmentConfigs[o]) == null ? void 0 : h.maxAttempts) ?? 1, u = c && !a && Os(s.suspendData, o) >= l, p = a ? 1 : 0;
  return {
    ratio: p,
    scorePercent: Math.round(p * 100),
    allLessonsComplete: !0,
    allAssessmentsPassed: a,
    anyAssessmentFailed: u,
    hasAssessments: !!((d = e.assessments) != null && d.some((g) => g.id === o)),
    hasLearnerProgress: yn(s, r),
    completionThreshold: n
  };
}
class Fc {
  onLaunched() {
  }
  onExperienced(e) {
  }
  onInteraction(e, t) {
  }
  onAssessmentSubmitted(e, t, n) {
  }
  onLessonCompleted(e) {
  }
  onTerminated() {
  }
}
var Ve = "http://adlnet.gov/expapi/verbs", jc = {
  id: `${Ve}/launched`,
  display: { "en-US": "launched" }
}, Uc = {
  id: `${Ve}/experienced`,
  display: { "en-US": "experienced" }
}, zc = {
  id: `${Ve}/answered`,
  display: { "en-US": "answered" }
}, qc = {
  id: `${Ve}/completed`,
  display: { "en-US": "completed" }
}, Kc = {
  id: `${Ve}/passed`,
  display: { "en-US": "passed" }
}, Gc = {
  id: `${Ve}/failed`,
  display: { "en-US": "failed" }
}, Hc = {
  id: `${Ve}/interacted`,
  display: { "en-US": "interacted" }
};
function Vc(s, e) {
  return `${s.replace(/\/$/, "")}/activities/${e}`;
}
function po(s, e) {
  return {
    objectType: "Activity",
    id: s,
    definition: {
      name: { "en-US": e },
      type: "http://adlnet.gov/expapi/activities/course"
    }
  };
}
function Ut(s, e) {
  const t = e.kind === "assessment" ? "http://adlnet.gov/expapi/activities/assessment" : "http://adlnet.gov/expapi/activities/module";
  return {
    objectType: "Activity",
    id: Vc(s, e.id),
    definition: {
      name: { "en-US": e.title },
      type: t
    }
  };
}
function Wc() {
  return typeof crypto < "u" && crypto.randomUUID ? crypto.randomUUID() : `urn:uuid:${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function bt(s, e, t, n) {
  const i = {
    registration: s.registration,
    contextActivities: {
      parent: [po(s.courseIri, s.courseTitle)]
    },
    ...n == null ? void 0 : n.context
  };
  return {
    id: Wc(),
    actor: s.actor,
    verb: e,
    object: t,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    ...n,
    context: i
  };
}
function Yc(s) {
  return bt(
    s,
    jc,
    po(s.courseIri, s.courseTitle)
  );
}
function Jc(s, e) {
  return bt(s, Uc, Ut(s.courseIri, e));
}
function Xc(s, e) {
  return bt(s, qc, Ut(s.courseIri, e), {
    result: { completion: !0 }
  });
}
function Qc(s, e, t, n) {
  return bt(s, zc, Ut(s.courseIri, e), {
    result: {
      score: { scaled: Math.max(0, Math.min(1, t)) },
      success: n,
      completion: !0
    }
  });
}
function Zc(s, e, t) {
  return bt(
    s,
    t ? Kc : Gc,
    Ut(s.courseIri, e),
    { result: { success: t, completion: !0 } }
  );
}
function ir(s, e, t) {
  const n = {
    id: e,
    title: e,
    kind: "lesson"
  }, i = {};
  if ((t == null ? void 0 : t.simulation) != null && typeof t.simulation == "object")
    i["https://lxpack.dev/xapi/extensions/simulation"] = t.simulation;
  else if (t != null)
    for (const [r, o] of Object.entries(t))
      r !== "type" && r !== "simulation" && (i[r] = o);
  return bt(s, Hc, Ut(s.courseIri, n), {
    result: Object.keys(i).length ? { extensions: i } : void 0
  });
}
function eu(s) {
  try {
    const e = decodeURIComponent(s), t = JSON.parse(e);
    if (t && typeof t == "object") return t;
  } catch {
    try {
      const e = atob(s.replace(/-/g, "+").replace(/_/g, "/")), t = JSON.parse(e);
      if (t && typeof t == "object") return t;
    } catch {
      return;
    }
  }
}
function tu(s, e) {
  const t = new URLSearchParams(), n = s.startsWith("?") ? s.slice(1) : s;
  if (n)
    for (const [r, o] of new URLSearchParams(n))
      t.set(r, o);
  const i = e.replace(/^#/, "");
  if (i)
    for (const [r, o] of new URLSearchParams(i))
      t.set(r, o);
  return t;
}
function su(s, e = "") {
  const t = tu(s, e), n = t.get("endpoint") ?? void 0, i = t.get("auth") ?? void 0, r = t.get("registration") ?? void 0, o = t.get("activityId") ?? void 0, a = t.get("fetch") ?? void 0;
  let c;
  const l = t.get("actor");
  return l && (c = eu(l)), {
    endpoint: n ?? void 0,
    auth: i ?? void 0,
    actor: c,
    registration: r ?? void 0,
    activityId: o ?? void 0,
    fetch: a ?? void 0
  };
}
function nu() {
  const s = globalThis.location;
  return s ? su(s.search, s.hash) : {};
}
function iu() {
  return {
    objectType: "Agent",
    name: "LXPack Preview Learner",
    mbox: "mailto:preview@lxpack.local"
  };
}
var ms = class extends Error {
  constructor(s) {
    super(s), this.name = "Cmi5FetchError";
  }
}, ru = "lxpack_cmi5_auth:";
function mo(s) {
  return `${ru}${s}`;
}
function ou(s) {
  if (!(typeof sessionStorage > "u"))
    try {
      return sessionStorage.getItem(mo(s)) ?? void 0;
    } catch {
      return;
    }
}
function au(s, e) {
  if (!(typeof sessionStorage > "u"))
    try {
      sessionStorage.setItem(mo(s), e);
    } catch {
    }
}
function lu(s) {
  const e = s["auth-token"] ?? s.authToken;
  if (typeof e == "string" && e.length > 0)
    return e;
  const t = s["error-code"] ?? s.errorCode, n = s["error-text"] ?? s.errorText;
  throw t || n ? new ms(
    `cmi5 fetch URL returned an error${t ? ` (${t})` : ""}: ${n ?? "unknown"}`
  ) : new ms(
    "cmi5 fetch response did not include auth-token"
  );
}
async function cu(s, e) {
  const t = ou(s);
  if (t)
    return t;
  const n = await fetch(s, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...e == null ? void 0 : e.headers
    },
    ...e,
    body: void 0
  });
  if (!n.ok)
    throw new ms(
      `cmi5 fetch URL returned HTTP ${n.status}`
    );
  if (!(n.headers.get("content-type") ?? "").includes("application/json"))
    throw new ms(
      "cmi5 fetch response must have Content-Type application/json"
    );
  const r = await n.json(), o = lu(r);
  return au(s, o), o;
}
function uu(s, e) {
  return {
    ...s,
    auth: s.auth ?? e
  };
}
async function fu(s, e) {
  if (!s.fetch || s.auth)
    return s;
  const t = await cu(s.fetch, e);
  return uu(s, t);
}
var hu = class {
  constructor(s) {
    N(this, "options");
    N(this, "queue", []);
    N(this, "flushing", !1);
    this.options = s;
  }
  enqueue(s) {
    var e, t, n;
    (t = (e = this.options).onStatement) == null || t.call(e, s), !(this.options.mock || !((n = this.options.credentials) != null && n.endpoint)) && (this.queue.push(s), this.flush());
  }
  async flush(s) {
    var t, n, i;
    if (this.flushing || !((t = this.options.credentials) != null && t.endpoint)) return;
    this.flushing = !0;
    const e = pu(this.options.credentials.endpoint);
    for (; this.queue.length > 0; ) {
      const r = this.queue.shift();
      try {
        await du(
          e,
          this.options.credentials.auth,
          r,
          { keepalive: s == null ? void 0 : s.keepalive }
        );
      } catch (o) {
        this.queue.unshift(r), (i = (n = this.options).onError) == null || i.call(n, o, r);
        break;
      }
    }
    this.flushing = !1;
  }
  /** Best-effort flush for page unload (uses fetch keepalive when available). */
  flushTerminal() {
    this.flush({ keepalive: !0 });
  }
};
function pu(s) {
  const e = s.replace(/\/$/, "");
  return e.endsWith("/statements") ? e : `${e}/statements`;
}
async function du(s, e, t, n) {
  const i = {
    "Content-Type": "application/json",
    "X-Experience-API-Version": "1.0.3"
  };
  e && (i.Authorization = e.startsWith("Basic ") ? e : `Basic ${e}`);
  const r = await fetch(s, {
    method: "POST",
    headers: i,
    body: JSON.stringify(t),
    keepalive: n == null ? void 0 : n.keepalive
  });
  if (!r.ok)
    throw new Error(`LRS returned ${r.status}: ${await r.text()}`);
}
class mu {
  constructor(e, t, n) {
    N(this, "session", null);
    N(this, "queue", null);
    N(this, "bootstrapPromise");
    N(this, "options");
    N(this, "activities");
    N(this, "lastExperienced");
    N(this, "launched", !1);
    this.options = n, this.activities = new Map(
      vo(e).map((r) => [r.id, r])
    );
    const i = (n == null ? void 0 : n.launchParams) ?? (globalThis.location != null ? nu() : {});
    this.bootstrapPromise = this.bootstrapSession(
      e,
      t,
      i,
      n
    );
  }
  async bootstrapSession(e, t, n, i) {
    var r, o;
    try {
      const a = await fu(n), c = a.actor ?? iu();
      if (a.fetch && !a.endpoint) {
        console.error(
          "[lxpack cmi5] Launch endpoint query parameter is required when using fetch"
        );
        return;
      }
      this.session = {
        actor: c,
        registration: a.registration,
        courseIri: t,
        courseTitle: ((o = (r = e.tracking) == null ? void 0 : r.xapi) == null ? void 0 : o.displayName) ?? e.title
      }, this.queue = new hu({
        mock: (i == null ? void 0 : i.mockLrs) ?? !a.endpoint,
        credentials: a.endpoint ? { endpoint: a.endpoint, auth: a.auth } : void 0,
        onError: (l) => {
          console.warn("[lxpack xAPI] LRS error:", l);
        }
      });
    } catch (a) {
      const c = a instanceof Error ? a.message : String(a);
      console.error(`[lxpack cmi5] Session bootstrap failed: ${c}`);
    }
  }
  async ensureReady() {
    return await this.bootstrapPromise, this.session !== null && this.queue !== null;
  }
  emit(e) {
    var t, n;
    (n = (t = this.options) == null ? void 0 : t.onStatement) == null || n.call(t, e), this.ensureReady().then((i) => {
      !i || !this.queue || this.queue.enqueue(e);
    });
  }
  onLaunched() {
    this.launched || this.ensureReady().then((e) => {
      !e || !this.session || (this.launched = !0, this.emit(Yc(this.session)));
    });
  }
  onExperienced(e) {
    if (this.lastExperienced === e) return;
    this.lastExperienced = e;
    const t = this.activities.get(e);
    t && this.ensureReady().then((n) => {
      !n || !this.session || this.emit(Jc(this.session, t));
    });
  }
  onInteraction(e, t) {
    this.ensureReady().then((n) => {
      if (!n || !this.session) return;
      if (((t == null ? void 0 : t.simulation) != null || typeof (t == null ? void 0 : t.type) == "string" && t.type === "simulation") && (t != null && t.simulation) && typeof t.simulation == "object") {
        this.emit(
          ir(this.session, e, {
            simulation: t.simulation
          })
        );
        return;
      }
      this.emit(ir(this.session, e, t));
    });
  }
  onAssessmentSubmitted(e, t, n) {
    this.ensureReady().then((i) => {
      if (!i || !this.session) return;
      const r = this.activities.get(e);
      r && (this.emit(Qc(this.session, r, t, n)), this.emit(Zc(this.session, r, n)));
    });
  }
  onLessonCompleted(e) {
    this.ensureReady().then((t) => {
      if (!t || !this.session) return;
      const n = this.activities.get(e);
      n && this.emit(Xc(this.session, n));
    });
  }
  onTerminated() {
    this.ensureReady().then((e) => {
      !e || !this.queue || this.queue.flushTerminal();
    });
  }
}
function gu(s) {
  var a, c, l, u, p;
  const e = s.activityIri ?? ((c = (a = s.manifest.tracking) == null ? void 0 : a.xapi) == null ? void 0 : c.activityIri);
  if (!(s.mode === "xapi" || s.mode === "cmi5" || s.mode === "preview" && !!((l = s.xapi) != null && l.previewLog && e)) || !e)
    return new Fc();
  const i = ((u = s.xapi) == null ? void 0 : u.previewLog) ?? s.mode === "preview" ? (h) => {
    if (typeof console < "u" && console.debug && console.debug("[lxpack xAPI]", h.verb.id, h.object.id), typeof localStorage < "u")
      try {
        const d = "lxpack_xapi_preview_statements", g = JSON.parse(localStorage.getItem(d) ?? "[]");
        g.push(h), localStorage.setItem(d, JSON.stringify(g.slice(-200)));
      } catch {
      }
  } : void 0, r = new mu(s.manifest, e, {
    mockLrs: ((p = s.xapi) == null ? void 0 : p.mockLrs) ?? s.mode === "preview",
    onStatement: i
  });
  let o = !1;
  return {
    onLaunched: () => {
      o || (o = !0, r.onLaunched());
    },
    onExperienced: (h) => r.onExperienced(h),
    onInteraction: (h, d) => r.onInteraction(h, d),
    onAssessmentSubmitted: (h, d, g) => r.onAssessmentSubmitted(h, d, g),
    onLessonCompleted: (h) => r.onLessonCompleted(h),
    onTerminated: () => r.onTerminated()
  };
}
class yu {
  constructor(e) {
    N(this, "manifest");
    N(this, "state");
    N(this, "bridge");
    N(this, "analytics");
    N(this, "completionThreshold");
    N(this, "assessmentConfigs");
    N(this, "defaultPassingScores");
    N(this, "terminated", !1);
    N(this, "flowInteractionIds");
    N(this, "completionScope");
    var o, a, c;
    this.manifest = e.manifest, this.flowInteractionIds = Ac(this.manifest), this.completionThreshold = ((a = (o = e.manifest.tracking) == null ? void 0 : o.completion) == null ? void 0 : a.threshold) ?? 0.9;
    const t = Cc(
      e.manifest.title,
      e.manifest.version
    );
    this.bridge = Rc(
      e.mode,
      t,
      e.previewScormMode ?? "local"
    ), this.analytics = gu(e), this.defaultPassingScores = {};
    for (const [l, u] of Object.entries(e.assessments ?? {}))
      this.defaultPassingScores[l] = u.passingScore;
    this.assessmentConfigs = e.assessmentConfigs ?? {}, e.mode === "scorm2004" && e.activityId && (this.completionScope = Mc(
      this.manifest,
      e.activityId
    ));
    const n = e.activityId ?? ((c = e.manifest.lessons[0]) == null ? void 0 : c.id) ?? "", i = e.progress ?? {
      currentLessonId: n,
      completedLessons: [],
      assessmentScores: {},
      suspendData: {}
    };
    Yi(this.manifest, i.suspendData), this.bridge.init();
    const r = this.bridge.restoreProgress(i);
    this.state = new Dc(
      r,
      this.manifest,
      this.defaultPassingScores
    ), Yi(this.manifest, this.state.progress.suspendData), this.state.syncPassedAssessments(), e.activityId && this.state.setCurrentLesson(e.activityId), this.analytics.onLaunched(), this.analytics.onExperienced(this.state.progress.currentLessonId);
  }
  getAPI() {
    return {
      track: (e) => this.track(e),
      completeLesson: (e) => this.completeLesson(e),
      getProgress: () => this.getProgress(),
      setVariable: (e, t) => {
        this.manifest.variables && e in this.manifest.variables ? Ec(this.state.progress.suspendData, e, t) : this.state.progress.suspendData[e] = t, this.persist();
      },
      getVariable: (e) => this.manifest.variables && e in this.manifest.variables ? Ji(this.state.progress.suspendData, e) : this.state.progress.suspendData[e],
      submitAssessment: (e, t, n) => this.submitAssessment(e, t, n)
    };
  }
  track(e, t) {
    var n, i;
    if (e.type === "interaction" && e.id && (this.state.progress.suspendData[`interaction_${e.id}`] = e.data ?? !0, console.debug("[lxpack] interaction:", e.id, e.data), this.analytics.onInteraction(
      e.id,
      e.data
    )), e.type === "simulation" && e.id && this.analytics.onInteraction(e.id, {
      type: "simulation",
      simulation: e.data ?? {}
    }), e.type === "assessment" && e.id) {
      const r = typeof ((n = e.data) == null ? void 0 : n.passingScore) == "number" ? Number(e.data.passingScore) : this.state.getAssessmentPassingScoreForTrack(e.id), o = ((i = e.data) == null ? void 0 : i.score) != null ? Number(e.data.score) : void 0;
      if (o != null && !Number.isNaN(o)) {
        this.submitAssessment(e.id, o, r);
        return;
      }
    }
    (t == null ? void 0 : t.persist) !== !1 && this.persist();
  }
  recordAssessmentAttempt(e) {
    return this.state.recordAssessmentAttempt(e);
  }
  getAssessmentAttemptCount(e) {
    return this.state.getAssessmentAttemptCount(e);
  }
  submitAssessment(e, t, n) {
    if (!this.canAcceptAssessmentSubmission(e))
      return;
    this.state.recordAssessmentAttempt(e), this.state.applyAssessmentResult(e, t, n);
    const i = this.isAssessmentPassed(e);
    this.analytics.onAssessmentSubmitted(e, t, i), this.updateCompletion(), this.persist();
  }
  getMaxAttempts(e) {
    const t = this.assessmentConfigs[e];
    return (t == null ? void 0 : t.maxAttempts) ?? uo.maxAttempts;
  }
  canAcceptAssessmentSubmission(e) {
    if (this.isAssessmentPassed(e))
      return !1;
    const t = this.getMaxAttempts(e);
    return this.getAssessmentAttemptCount(e) < t;
  }
  /**
   * Marks an html lesson as interaction-complete for flow `interaction.done` conditions.
   * Does not emit analytics (the preceding `track()` call already did).
   */
  markInteractionLessonDone(e) {
    const t = this.manifest.lessons.find((n) => n.id === e);
    !t || t.type !== "html" || (this.state.progress.suspendData[`interaction_${e}`] = !0, this.persist());
  }
  completeLesson(e) {
    this.state.completeLesson(e), this.analytics.onLessonCompleted(e), this.updateCompletion(), this.persist();
  }
  setCurrentLesson(e) {
    this.state.setCurrentLesson(e), this.bridge.setLocation(e), this.analytics.onExperienced(e), this.persist();
  }
  getProgress() {
    const e = this.state.progress;
    return {
      ...e,
      completedLessons: [...e.completedLessons],
      assessmentScores: { ...e.assessmentScores },
      suspendData: { ...e.suspendData }
    };
  }
  getManifest() {
    return this.manifest;
  }
  isLessonComplete(e) {
    return this.state.isLessonComplete(e);
  }
  isAssessmentPassed(e) {
    return this.state.isAssessmentPassed(e);
  }
  getTotalUnits() {
    var t;
    const e = ((t = this.manifest.assessments) == null ? void 0 : t.length) ?? 0;
    return this.manifest.lessons.length + e;
  }
  completionEvaluatorOptions() {
    return {
      manifest: this.manifest,
      completionThreshold: this.completionThreshold,
      assessmentConfigs: this.assessmentConfigs,
      defaultPassingScores: this.defaultPassingScores,
      passedAssessments: this.state.passedAssessments,
      scopeActivity: this.completionScope
    };
  }
  getCompletionRatio() {
    return nr(
      this.state.progress,
      this.completionEvaluatorOptions()
    ).ratio;
  }
  updateCompletion() {
    const e = nr(
      this.state.progress,
      this.completionEvaluatorOptions()
    );
    this.bridge.applyCompletion(e);
  }
  persist() {
    const e = lo(this.state.progress, void 0, {
      preserveInteractionIds: this.flowInteractionIds
    });
    this.bridge.persist(this.state.progress, e);
  }
  getFlowContext() {
    return {
      getVariable: (e) => Ji(this.state.progress.suspendData, e),
      getVariableType: (e) => {
        var t, n;
        return (n = (t = this.manifest.variables) == null ? void 0 : t[e]) == null ? void 0 : n.type;
      },
      isAssessmentPassed: (e) => this.isAssessmentPassed(e),
      isInteractionDone: (e) => {
        const t = this.state.progress.suspendData[`interaction_${e}`];
        return co(t);
      }
    };
  }
  resolveFlowNavigation() {
    return io(this.manifest, this.getFlowContext());
  }
  terminate() {
    this.terminated || (this.terminated = !0, this.analytics.onTerminated(), this.bridge.terminate());
  }
}
function bu() {
  const s = window.__LXPACK_CONFIG__;
  if (!s)
    throw new Error("LXPack runtime config not found");
  return s;
}
function wu(s) {
  var i;
  const e = document.getElementById("lxpack-app");
  if (!e) throw new Error("#lxpack-app element not found");
  const t = ((i = s.runtime) == null ? void 0 : i.theme) ?? "modern";
  e.className = `lxpack-theme-${t.replace(/[^a-zA-Z0-9_-]/g, "")}`;
  const n = s.description ? `<p class="lxpack-description">${De(s.description)}</p>` : "";
  return e.innerHTML = `
    <div class="lxpack-layout">
      <header class="lxpack-header">
        <h1 class="lxpack-title">${De(s.title)}</h1>
        <p class="lxpack-version">v${De(s.version)}</p>
        ${n}
      </header>
      <div class="lxpack-body">
        <nav class="lxpack-nav" aria-label="Course navigation"></nav>
        <main class="lxpack-content" id="lxpack-content"></main>
      </div>
      <footer class="lxpack-footer">
        <div class="lxpack-progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
          <div class="lxpack-progress-fill" id="lxpack-progress-fill"></div>
        </div>
        <div class="lxpack-nav-buttons">
          <button type="button" id="lxpack-prev" disabled>Previous</button>
          <button type="button" id="lxpack-next">Next</button>
          <button type="button" id="lxpack-complete" class="lxpack-complete-btn">Mark complete</button>
        </div>
      </footer>
    </div>
  `, e;
}
function ku(s) {
  const e = document.getElementById("lxpack-progress-fill"), t = document.querySelector(".lxpack-progress-bar"), n = Math.round(s * 100);
  e && (e.style.width = `${n}%`), t && t.setAttribute("aria-valuenow", String(n));
}
function ce(s) {
  const e = document.createElement("div");
  return e.textContent = s, e.innerHTML;
}
function Su(s, e, t, n, i) {
  const { config: r, feedback: o, ...a } = e, c = { ...uo, ...r }, u = n.getProgress().assessmentScores[a.id], p = n.isAssessmentPassed(a.id), h = n.getAssessmentAttemptCount(a.id), d = u !== void 0 ? Math.max(h, 1) : h, g = c.maxAttempts - d;
  if (h >= c.maxAttempts && u === void 0) {
    s.innerHTML = `
      <article class="lxpack-assessment lxpack-assessment-result">
        <h2>${ce(a.title ?? a.id)}</h2>
        <p class="lxpack-error">
          No attempts remaining (maximum: ${c.maxAttempts}).
          ${h > 0 ? ` · Attempts used: ${h}` : ""}
        </p>
      </article>
    `;
    return;
  }
  if (u !== void 0 && (p || g <= 0)) {
    s.innerHTML = `
      <article class="lxpack-assessment lxpack-assessment-result">
        <h2>${ce(a.title ?? a.id)}</h2>
        <p class="${p ? "lxpack-success-text" : "lxpack-error"}">
          Score: ${Math.round(u * 100)}% —
          ${p ? "Passed" : "Not passed"}
          (required: ${Math.round(a.passingScore * 100)}%)
          ${h > 1 ? ` · Attempts: ${h}` : ""}
        </p>
      </article>
    `;
    return;
  }
  let m = a.questions;
  c.shuffleChoices && (m = sr(m).map((w) => ({
    ...w,
    choices: sr(w.choices)
  })));
  const y = m.map(
    (w, S) => `
      <fieldset class="lxpack-question" data-question-id="${ce(w.id)}">
        <legend>${S + 1}. ${ce(w.prompt)}</legend>
        ${w.choices.map(
      (E) => `
          <label class="lxpack-choice">
            <input type="radio" name="q-${ce(w.id)}" value="${ce(E.id)}" />
            ${ce(E.text)}
          </label>
        `
    ).join("")}
        ${c.showFeedback === "immediate" && (o != null && o[w.id]) ? `<p class="lxpack-hint lxpack-feedback-immediate" hidden data-feedback-for="${ce(w.id)}">${ce(o[w.id])}</p>` : ""}
      </fieldset>
    `
  ).join(""), A = Math.max(0, c.maxAttempts - d);
  s.innerHTML = `
    <article class="lxpack-assessment">
      <h2>${ce(a.title ?? a.id)}</h2>
      ${c.maxAttempts > 1 ? `<p class="lxpack-hint">Attempts remaining: ${A}</p>` : ""}
      <form id="lxpack-assessment-form">
        ${y}
        <button type="submit" class="lxpack-complete-btn">Submit assessment</button>
      </form>
      <div id="lxpack-assessment-feedback" class="lxpack-assessment-feedback" hidden></div>
    </article>
  `;
  const k = s.querySelector("#lxpack-assessment-form"), L = s.querySelector(
    "#lxpack-assessment-feedback"
  );
  c.showFeedback === "immediate" && k.querySelectorAll('input[type="radio"]').forEach((w) => {
    w.addEventListener("change", () => {
      const E = w.name.replace(/^q-/, ""), T = k.querySelector(
        `[data-feedback-for="${E}"]`
      );
      T && (T.hidden = !1);
    });
  });
  let I = !1;
  k.addEventListener("submit", (w) => {
    var M;
    if (w.preventDefault(), I) return;
    I = !0;
    const S = k.querySelector(
      'button[type="submit"]'
    );
    S && (S.disabled = !0);
    const E = $c(a, t, k), T = E >= a.passingScore;
    if (n.submitAssessment(a.id, E, a.passingScore), c.showFeedback === "end" || c.showFeedback === "immediate") {
      L.hidden = !1;
      const J = c.showFeedback === "end" && o ? Object.entries(o).filter(([, B]) => B).map(([B, U]) => `<p><strong>${ce(B)}:</strong> ${ce(U)}</p>`).join("") : "";
      L.innerHTML = `
        <p class="${T ? "lxpack-success-text" : "lxpack-error"}">
          Score: ${Math.round(E * 100)}% —
          ${T ? "Passed!" : "Not passed."}
          (required: ${Math.round(a.passingScore * 100)}%)
        </p>
        ${J}
      `;
    }
    !T && n.getAssessmentAttemptCount(a.id) < c.maxAttempts || (M = k.querySelector("button[type=submit]")) == null || M.remove(), i();
  });
}
const Au = {
  markdown: async (s, e) => {
    const t = s;
    if (!t.file) {
      e.contentEl.innerHTML = '<p class="lxpack-error">Invalid lesson configuration</p>';
      return;
    }
    await Xa(e.contentEl, e.baseUrl, t.file);
  },
  html: async (s, e) => {
    const t = s;
    if (!t.path) {
      e.contentEl.innerHTML = '<p class="lxpack-error">Invalid lesson configuration</p>';
      return;
    }
    Qa(e.contentEl, e.baseUrl, t.path);
  },
  component: async (s, e) => {
    const t = s;
    uc(
      e.contentEl,
      t.component,
      t.props,
      e.baseUrl
    );
  }
};
async function Tu(s, e, t, n, i, r) {
  var l, u;
  if (i.kind === "lesson") {
    const p = Au[i.lesson.type];
    await p(i.lesson, { contentEl: t, baseUrl: n });
    return;
  }
  const { assessment: o, answerKey: a, payload: c } = await cc(
    s,
    n,
    i.id,
    i.file
  );
  Su(
    t,
    c ?? {
      ...o,
      config: ((l = s.assessmentConfigs) == null ? void 0 : l[i.id]) ?? {
        maxAttempts: 1,
        shuffleChoices: !1,
        showFeedback: "never"
      },
      feedback: (u = s.assessmentFeedback) == null ? void 0 : u[i.id]
    },
    a,
    e,
    r
  );
}
function rr() {
  const s = bu(), e = new yu({
    manifest: s.manifest,
    baseUrl: s.baseUrl,
    mode: s.mode,
    activityId: s.activityId,
    activityIri: s.activityIri,
    xapi: s.xapi,
    progress: s.progress,
    assessments: s.assessments,
    answerKeys: s.answerKeys,
    assessmentConfigs: s.assessmentConfigs,
    assessmentFeedback: s.assessmentFeedback
  }), t = e.getAPI();
  window.lxpack = t, wu(s.manifest);
  const n = document.querySelector(".lxpack-nav"), i = document.getElementById("lxpack-content"), r = document.getElementById("lxpack-prev"), o = document.getElementById("lxpack-next"), a = document.getElementById(
    "lxpack-complete"
  ), c = s.mode === "scorm2004" && !!s.activityId, l = pa(s.manifest), u = c ? l.filter((w) => w.id === s.activityId) : l, p = c ? u.map((w) => w.id) : ro(s.manifest);
  function h(w) {
    const S = u.findIndex((E) => E.id === w);
    return S >= 0 ? S : (w && console.warn(
      `[lxpack] Stored lesson id "${w}" is not in this course; opening the first activity`
    ), 0);
  }
  let d = h(e.getProgress().currentLessonId), g = 0;
  function m() {
    var S;
    const w = e.resolveFlowNavigation();
    if (w && w !== ((S = u[d]) == null ? void 0 : S.id)) {
      const E = u.findIndex((T) => T.id === w);
      if (E >= 0)
        return k(E), !0;
      c && console.warn(
        `[lxpack] Flow goto "${w}" is not available in this SCORM launch activity`
      );
    }
    return !1;
  }
  function y(w, S) {
    var J, B, U;
    if (!!!((J = s.manifest.flow) != null && J.length)) return !0;
    const T = ((B = u[d]) == null ? void 0 : B.id) ?? "";
    return w === T || e.resolveFlowNavigation() === w ? !0 : T ? !!(Ki(
      s.manifest,
      T,
      e.getFlowContext()
    ) === w || S != null && S.allowLinearPrevious && Gi(s.manifest, T) === w) : w === ((U = u[0]) == null ? void 0 : U.id);
  }
  function A() {
    const w = /* @__PURE__ */ new Set();
    for (const S of s.manifest.assessments ?? [])
      e.isAssessmentPassed(S.id) && w.add(S.id);
    return w;
  }
  async function k(w) {
    var U, F;
    const S = u[w];
    if (!S) return;
    const E = ++g;
    e.setCurrentLesson(S.id), d = w;
    try {
      await Tu(s, e, i, s.baseUrl, S, () => {
        k(d);
      });
    } catch (le) {
      if (E !== g) return;
      const Te = le instanceof Error ? le.message : String(le);
      i.innerHTML = `<p class="lxpack-error">${De(Te)}</p>`;
    }
    if (E !== g) return;
    da(
      n,
      u,
      S.id,
      e.getProgress().completedLessons,
      A(),
      (le) => {
        if (!y(le)) return;
        const Te = u.findIndex((We) => We.id === le);
        Te >= 0 && k(Te);
      },
      (le) => y(le, { allowLinearPrevious: !0 })
    ), ku(e.getCompletionRatio());
    const T = ((U = u[w]) == null ? void 0 : U.id) ?? "", C = !!((F = s.manifest.flow) != null && F.length), M = p.indexOf(T) <= 0, J = p.indexOf(T) >= p.length - 1 && !C;
    r.disabled = M, o.disabled = J && !C;
    const B = S.kind === "lesson";
    a.hidden = !B, B && (a.textContent = e.isLessonComplete(S.id) ? "Completed" : "Mark complete", a.disabled = e.isLessonComplete(S.id));
  }
  r.addEventListener("click", () => {
    var E;
    const w = (E = u[d]) == null ? void 0 : E.id;
    if (!w) return;
    const S = Gi(s.manifest, w);
    if (S && y(S)) {
      const T = u.findIndex((C) => C.id === S);
      if (T >= 0) {
        k(T);
        return;
      }
    }
    d > 0 && k(d - 1);
  }), o.addEventListener("click", () => {
    var E;
    const w = (E = u[d]) == null ? void 0 : E.id;
    if (!w) return;
    const S = Ki(
      s.manifest,
      w,
      e.getFlowContext()
    );
    if (S) {
      const T = u.findIndex((C) => C.id === S);
      if (T >= 0) {
        k(T);
        return;
      }
    }
    d < u.length - 1 && k(d + 1);
  }), a.addEventListener("click", () => {
    const w = u[d];
    (w == null ? void 0 : w.kind) === "lesson" && (e.completeLesson(w.id), m() || k(d));
  });
  const L = t.track.bind(t);
  t.track = (w) => {
    if (L(w), w.type === "interaction") {
      const S = u[d];
      co(w.data) && (S == null ? void 0 : S.kind) === "lesson" && S.lesson.type === "html" && e.markInteractionLessonDone(S.id);
    }
    (w.type === "interaction" || w.type === "assessment") && m();
  };
  const I = () => e.terminate();
  window.addEventListener("beforeunload", I), window.addEventListener("pagehide", I), k(d);
}
function Eu() {
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", rr) : rr();
}
Eu();
export {
  Eu as bootstrapClient,
  pa as buildNavItems,
  rr as init,
  cc as loadAssessment,
  Su as renderAssessment,
  uc as renderComponentLesson,
  Qa as renderHtmlInteraction,
  Xa as renderMarkdown,
  da as renderNav,
  $c as scoreAssessment
};
