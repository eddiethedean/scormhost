const l = /* @__PURE__ */ new Map();
function a(t, n) {
  l.set(t, n);
}
function g(t) {
  return l.get(t);
}
function r(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function u() {
  a("callout", (t, n) => {
    const c = String(n.variant ?? "info"), e = String(n.body ?? "");
    t.innerHTML = `
      <aside class="lxpack-callout lxpack-callout-${r(c)}" role="note">
        <p>${r(e)}</p>
      </aside>
    `;
  }), a("image-card", (t, n, c) => {
    const e = String(n.title ?? ""), i = String(n.src ?? ""), o = String(n.caption ?? ""), s = i.startsWith("http") ? i : `${c.replace(/\/$/, "")}/${i}`;
    t.innerHTML = `
      <figure class="lxpack-image-card">
        <img src="${r(s)}" alt="${r(e)}" />
        ${o ? `<figcaption>${r(o)}</figcaption>` : ""}
      </figure>
    `;
  }), a("checklist", (t, n) => {
    const e = (Array.isArray(n.items) ? n.items : []).map((i) => `<li>${r(String(i))}</li>`).join("");
    t.innerHTML = `<ul class="lxpack-checklist">${e}</ul>`;
  });
}
u();
window.__LXPACK_COMPONENTS__ = {
  mount(t, n, c, e) {
    const i = g(n);
    if (!i) {
      t.innerHTML = `<p class="lxpack-error">Unknown component: ${n}</p>`;
      return;
    }
    i(t, c, e);
  }
};
